#!/usr/bin/env python3
"""Independent miner graph entry point; publication packaging, no research data."""
import argparse
import json
import os
import subprocess
import sys
import time
import uuid
from pathlib import Path

sys.dont_write_bytecode = True
ROOT = Path(__file__).resolve().parent
sys.path.insert(0, str(ROOT / 'src'))
sys.path.insert(0, str(ROOT / 'engine'))
from session import (guarded, environment, save, charge_start, charge_finish, cost, stop_child, process_tree_cpu, measure_phase)
from build import check_build, sha
from graph import compile_graph


def devices():
    rows = []
    for p in sorted(Path('/sys/bus/pci/devices').glob('*')):
        try:
            if int((p/'class').read_text(), 16) >> 16 != 3:
                continue
            vendor = (p/'vendor').read_text().strip()
            rows.append({'pci': p.name, 'vendor': vendor,
                         'device': (p/'device').read_text().strip(),
                         'backend': 'cuda' if vendor == '0x10de' else 'vulkan',
                         'driver': (p/'driver').resolve().name,
                         'status': 'SYSFS_DISCOVERED_CAPABILITIES_CHECKED_AT_RUN'})
        except (OSError, ValueError):
            continue
    return rows


def run_graph(args, fd):
    start = time.monotonic(); cpu_start = process_tree_cpu(); phases = {}
    with measure_phase(phases, "build_integrity_hashes"): check_build()
    out = ROOT/'results'/('graph-'+time.strftime('%Y%m%dT%H%M%SZ',time.gmtime())+'-'+args.pci.replace(':','_')+'-'+uuid.uuid4().hex[:8])
    out.mkdir()
    with measure_phase(phases, 'graph_compile'): plan = compile_graph(args.graph, args.backend, out/'plan.bin', output_compression=args.compress)
    with measure_phase(phases, 'input_program_hashes_before'): hashes = {name: sha(name) for name in plan['files']}
    save(out/'GRAPH.json', plan['graph'])
    limit = min(args.timeout, 7200-cost()['worker_envelope_seconds']-30)
    if limit <= 0: raise RuntimeError('CAMPAIGN_BUDGET_EXHAUSTED')
    command = [str(ROOT/'build/science-engine'),args.backend,args.pci,str(out/'plan.bin'),str(out)]
    save(out/'RUN.json', {'argv':command,'files':hashes,'plan_sha256':plan['plan_sha256'],
                         'build_manifest_sha256':sha(ROOT/'BUILD_MANIFEST.json'),
                         'node_order':plan['node_order'],'dispatches':plan['dispatches'],'execution':plan['execution'],
                         'timeout_seconds':limit,'scope':'GENERIC_GRAPH_NO_DOMAIN_VALIDATION'})
    charge_start('short_GPU_trials',out,limit)
    env=environment();env['NGC_SHARED_LOCK_FD']=str(fd)
    proc=None;rc=1;begin=time.monotonic();worker_cpu_start=process_tree_cpu()
    try:
        with (out/'native.log').open('w') as log:
            proc=subprocess.Popen(command,env=env,pass_fds=(fd,),stdout=log,stderr=subprocess.STDOUT,start_new_session=True)
            try:rc=proc.wait(timeout=limit)
            except (KeyboardInterrupt,subprocess.TimeoutExpired):stop_child(proc);rc=124;raise
        if rc:raise RuntimeError('GRAPH_FAILED:'+str(out/'native.log'))
    finally:
        if proc and proc.poll() is None:stop_child(proc)
        phases['native_process_and_teardown']=dict(wall_seconds=time.monotonic()-begin,cpu_seconds=process_tree_cpu()-worker_cpu_start)
        charge_finish(out,time.monotonic()-begin,rc)
    with measure_phase(phases, 'input_program_hashes_after'):
        for name,expected in hashes.items():
            if sha(name)!=expected:raise RuntimeError('GRAPH_INPUT_OR_PROGRAM_CHANGED:'+name)
    with measure_phase(phases, 'output_hashes'):
        outputs={p.name:sha(p) for pattern in ('*.raw','*.qgc') for p in out.glob(pattern)}
    result={'status':'EXECUTED_NOT_DOMAIN_VALIDATED','output':str(out),
            'end_to_end_seconds':time.monotonic()-start,'outputs':outputs,
            'process_tree_cpu_seconds':process_tree_cpu()-cpu_start,'phase_costs':phases,
            'cpu_scope':'run_graph window; self + reaped descendants; native phase included, not additive'}
    save(out/'COMPLETION.json',result);print(json.dumps(result),flush=True)
    return out


def main():
    parser=argparse.ArgumentParser(description='Új, független tudományos motor: CUDA és Vulkan, betölthető munkafolyamatok.')
    sub=parser.add_subparsers(dest='command',required=True)
    sub.add_parser('devices',help='GPU-k listázása sysfs-ből; nem indít számítást')
    build_parser=sub.add_parser('build',help='Saját motor és munkafolyamatok soros fordítása')
    build_parser.add_argument('--core-only',action='store_true',help='Kompatibilitási kapcsoló; a csomag mindig csak a motort építi')
    run=sub.add_parser('run',help='Tetszőleges v1/v2 JSON-gráf futtatása')
    run.add_argument('--device',required=True,help='PCI-cím, auto, vagy all (egymás után)')
    run.add_argument('--backend',choices=('auto','cuda','vulkan'),default='auto')
    run.add_argument('--graph',type=Path,required=True)
    run.add_argument('--compress',choices=('raw','qgc1'),default=None,help='Általános gráfkimeneti adatút; raw vagy GPU-s QGC1 tömörítés')
    run.add_argument('--timeout',type=float,default=180)
    args=parser.parse_args()
    if args.command=='devices':print(json.dumps(devices(),indent=2));return
    if args.command=='build':
        from build import build
        for name in ('home','cache','tmp','logs','results','build'):(ROOT/name).mkdir(exist_ok=True)
        os.environ.update(environment())
        return guarded('core_build',lambda fd:build(None,core_only=True),cpu_only=True)
    if not 0<args.timeout<=600:raise ValueError('TIMEOUT_RANGE_0_TO_600')
    if args.compress is not None and not args.graph:raise ValueError('COMPRESSION_REQUIRES_GENERIC_GRAPH_OUTPUT_PATH')
    rows=devices()
    if args.device=='all':selected=rows
    elif args.device=='auto':selected=sorted(rows,key=lambda r:r['backend']!='cuda')[:1]
    else:selected=[r for r in rows if r['pci']==args.device]
    if not selected:raise ValueError('DEVICE_NOT_FOUND')
    requested_backend=args.backend
    os.environ.update(environment())
    # One admission and finite serial dispatch. Never queue a retry on a busy rig.
    def execute(fd):
        # Selection metadata only; each run validates its full build before
        # hardware entry. Avoid hashing the same files twice on every launch.
        manifest=json.loads((ROOT/'BUILD_MANIFEST.json').read_text())
        for row in selected:
            args.pci=row['pci'];args.backend=row['backend'] if requested_backend=='auto' else requested_backend
            if requested_backend=='auto' and args.backend=='cuda' and not manifest['cuda']:
                args.backend='vulkan'
            run_graph(args,fd)
    guarded('astro',execute)


if __name__=='__main__':
    try:main()
    except KeyboardInterrupt:print('INTERRUPTED',file=sys.stderr);sys.exit(130)
    except Exception as error:print(str(error),file=sys.stderr);sys.exit(1)
