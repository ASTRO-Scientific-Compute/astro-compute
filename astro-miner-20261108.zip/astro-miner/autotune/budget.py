"""Independent resource ceilings; no conversion between budget units.

Time is reserved at the watchdog upper bound before launch. Unknown outcomes
retain that reservation and block further launches until explicitly reconciled.
Session/candidate reservations are never refunded, including failed attempts.
Memory means backend-owned buffer allocations (including Vulkan staging and
allocation padding), not driver/context memory or other applications' VRAM.
"""
import contextlib
import fcntl
import json
import math
import time
import uuid
from pathlib import Path

TOTALS = ('sessions', 'candidate_evaluations', 'worker_seconds', 'gpu_seconds')


def finite(value, positive=False):
    if isinstance(value, bool) or not isinstance(value, (int, float)):
        raise ValueError('INVALID_RESOURCE_VALUE')
    if not math.isfinite(value) or value < 0 or (positive and value == 0):
        raise ValueError('INVALID_RESOURCE_VALUE')
    return value


class Budget:
    def __init__(self, path):
        self.path = Path(path)

    @contextlib.contextmanager
    def locked(self):
        with self.path.with_suffix('.lock').open('a+') as lock:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX)
            yield json.loads(self.path.read_text())

    def save(self, ledger):
        temp = self.path.with_suffix('.new')
        temp.write_text(json.dumps(ledger, indent=2) + '\n')
        temp.replace(self.path)

    @staticmethod
    def check(ledger, request, pci):
        if ledger.get('launch_status') != 'OPEN':
            raise RuntimeError('AUTOTUNE_CAMPAIGN_CLOSED: no new GPU allowance')
        if ledger.get('version') != 2:
            raise RuntimeError('INDEPENDENT_RESOURCE_BUDGETS_REQUIRED')
        resources = ledger['resources']
        if any(r['status'] in ('RESERVED', 'UNKNOWN') for r in ledger.get('resource_reservations', [])):
            raise RuntimeError('UNSETTLED_RESOURCE_RESERVATION')
        for key in TOTALS:
            cap = finite(resources['limits'][key], positive=True)
            used = finite(resources['charged'][key])
            amount = finite(request[key], positive=True)
            if key in ('sessions', 'candidate_evaluations') and type(request[key]) is not int:
                raise ValueError('INTEGER_COUNT_REQUIRED')
            if used + amount > cap:
                raise RuntimeError('AUTOTUNE_BUDGET_EXHAUSTED:' + key)
        cap = resources['memory_limits_bytes'][pci]
        if type(cap) is not int or cap <= 0:
            raise ValueError('EXPLICIT_DEVICE_MEMORY_LIMIT_REQUIRED')
        if type(request['memory_bytes']) is not int or not 0 < request['memory_bytes'] <= cap:
            raise RuntimeError('AUTOTUNE_BUDGET_EXHAUSTED:memory_bytes')

    def preflight(self, request, pci):
        with self.locked() as ledger:
            self.check(ledger, request, pci)

    def memory_limit(self, pci):
        with self.locked() as ledger:
            if ledger.get('launch_status') != 'OPEN':
                raise RuntimeError('AUTOTUNE_CAMPAIGN_CLOSED: no new GPU allowance')
            return ledger['resources']['memory_limits_bytes'][pci]

    def reserve(self, request, pci, label):
        with self.locked() as ledger:
            self.check(ledger, request, pci)
            token = uuid.uuid4().hex
            for key in TOTALS:
                ledger['resources']['charged'][key] += request[key]
            ledger.setdefault('resource_reservations', []).append(dict(
                token=token, pci=pci, label=label, requested=request,
                status='RESERVED', utc_unix_ns=time.time_ns()))
            self.save(ledger)
            return token

    def settle(self, token, *, worker_seconds, gpu_seconds, peak_bytes, evidence):
        actual = dict(worker_seconds=finite(worker_seconds), gpu_seconds=finite(gpu_seconds))
        if type(peak_bytes) is not int or peak_bytes < 0:
            raise ValueError('INVALID_MEMORY_EVIDENCE')
        with self.locked() as ledger:
            row = next(r for r in ledger['resource_reservations'] if r['token'] == token)
            if row['status'] != 'RESERVED':
                raise RuntimeError('RESERVATION_ALREADY_SETTLED_OR_UNKNOWN')
            exceeded = any(actual[k] > row['requested'][k] for k in actual)
            exceeded |= peak_bytes > row['requested']['memory_bytes']
            for key, value in actual.items():
                ledger['resources']['charged'][key] += value - row['requested'][key]
            peaks = ledger['resources'].setdefault('observed_peak_bytes', {})
            peaks[row['pci']] = max(peaks.get(row['pci'], 0), peak_bytes)
            row.update(status='EXCEEDED' if exceeded else 'SETTLED', measured=actual,
                       peak_bytes=peak_bytes, evidence=str(evidence))
            if exceeded:
                ledger['launch_status'] = 'CLOSED_RESOURCE_BOUND_EXCEEDED'
            self.save(ledger)
            if exceeded:
                raise RuntimeError('RESOURCE_BOUND_EXCEEDED_CAMPAIGN_CLOSED')

    def unknown(self, token, error):
        with self.locked() as ledger:
            row = next(r for r in ledger['resource_reservations'] if r['token'] == token)
            if row['status'] == 'RESERVED':
                row.update(status='UNKNOWN', error=str(error))
                ledger['launch_status'] = 'CLOSED_UNCERTAIN_RESOURCE_USAGE'
                self.save(ledger)
