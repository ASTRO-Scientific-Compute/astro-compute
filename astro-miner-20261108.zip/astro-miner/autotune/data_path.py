"""Workload-neutral objectives. Measured boundaries, explicit network estimates.

CPU seconds and summed GPU intervals are resource costs, not elapsed phases.
Compression, transfer, checking and persistence are already inside local E2E.
Only verified, lossless complete work may reach this scorer. Scientific and bit
gates remain the caller's responsibility and cannot be relaxed by an objective.
"""
import hashlib
import json
import math


def number(value, name, *, positive=False, integer=False):
    if (isinstance(value, bool) or not isinstance(value, (int, float))
        or not math.isfinite(value) or value < 0 or (positive and value == 0)
        or (integer and type(value) is not int)):
        raise ValueError('DATA_PATH_VALUE:' + name)
    return value


def context(config=None):
    """Explicit rates/conditions form part of the profile identity; no probes."""
    value = dict(config or {'objective':'local'})
    allowed = {'objective', 'network', 'prices'}
    if set(value)-allowed or value.get('objective') not in ('local','network'):
        raise ValueError('DATA_PATH_OBJECTIVE')
    if value['objective'] == 'network':
        network = value.get('network', {})
        required = {'payload_bytes_per_second', 'request_latency_seconds',
                    'receiver_finalize_seconds', 'condition_id'}
        if set(network) != required or not isinstance(network['condition_id'], str) or not network['condition_id']:
            raise ValueError('NETWORK_CONDITIONS_REQUIRED')
        number(network['payload_bytes_per_second'], 'bandwidth', positive=True)
        number(network['request_latency_seconds'], 'request_latency')
        number(network['receiver_finalize_seconds'], 'receiver_finalize')
    elif 'network' in value:
        raise ValueError('LOCAL_OBJECTIVE_HAS_NO_NETWORK')
    if 'prices' in value:
        prices = value['prices']
        if set(prices) != {'currency','cpu_second','gpu_second','stored_byte','network_byte'} or not isinstance(prices['currency'],str) or not prices['currency']:
            raise ValueError('EXPLICIT_PRICE_SCOPE_REQUIRED')
        for key in set(prices)-{'currency'}: number(prices[key], key)
    # Detach caller-owned nested dictionaries; reject non-JSON conditions.
    return json.loads(json.dumps(value, allow_nan=False))


def identity(config=None):
    value = context(config)
    return value['objective']+'_'+hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest()[:16]


def evaluate(measurement, config=None):
    """Use observed local boundary; optionally schedule a single network link.

    transfer_batches explicitly declare payload bytes, requests and measured
    release times since the local start. Uploads serialize on one shared link,
    overlap the remaining local work, and finish after the last receiver check.
    Without release evidence, upload begins only after local completion. This
    is a model, never proof that overlapping upload has been implemented.
    """
    config = context(config)
    local = number(measurement['full_e2e_seconds'], 'full_e2e_seconds', positive=True)
    result = dict(objective=config['objective'], local_measured_seconds=local,
                  seconds=local, timing_status='MEASURED_LOCAL_E2E',
                  monetary_cost=None, cost_status='UNKNOWN_NO_PRICE_MODEL',
                  energy_joules=measurement.get('energy_joules'))
    if config['objective'] == 'network':
        total = number(measurement['network_payload_bytes'], 'network_payload_bytes', integer=True)
        network = config['network']
        batches = measurement.get('transfer_batches')
        if batches is None:
            batches = [dict(bytes=total, requests=1, ready_seconds=local)]
            schedule = 'UPLOAD_AFTER_VERIFIED_LOCAL_COMPLETION'
        else:
            if not batches or measurement.get('transfer_release_status') != 'MEASURED_VERIFIED_IMMUTABLE_OUTPUT':
                raise ValueError('VERIFIED_TRANSFER_RELEASE_EVIDENCE_REQUIRED')
            schedule = 'MODELED_SINGLE_LINK_WITH_MEASURED_VERIFIED_RELEASES'
        transferred = 0; link_end = 0.; previous = 0.
        for batch in batches:
            size = number(batch['bytes'], 'batch_bytes', integer=True)
            requests = number(batch['requests'], 'requests', positive=True, integer=True)
            ready = number(batch['ready_seconds'], 'ready_seconds')
            if ready < previous or ready > local: raise ValueError('TRANSFER_RELEASE_OUTSIDE_LOCAL_ENVELOPE')
            link_end = max(link_end,ready) + size/network['payload_bytes_per_second'] + requests*network['request_latency_seconds']
            transferred += size; previous = ready
        if transferred != total: raise ValueError('NETWORK_PAYLOAD_ACCOUNTING_MISMATCH')
        result.update(seconds=max(local,link_end+network['receiver_finalize_seconds']),
            timing_status='ESTIMATED_NETWORK_E2E_NOT_MEASURED', schedule=schedule,
            network_payload_bytes=total, estimated_link_completion_seconds=link_end,
            network_conditions=network)
    if 'prices' in config:
        prices = config['prices']
        cpu = measurement.get('full_host_cpu_seconds',measurement.get('full_process_tree_cpu_seconds'))
        gpu = measurement.get('gpu_kernel_seconds',measurement.get('gpu_marker_seconds'))
        stored = measurement.get('stored_bytes')
        network_bytes = measurement.get('network_payload_bytes') if config['objective']=='network' else 0
        values = [cpu,gpu,stored,network_bytes]
        if all(v is not None for v in values):
            keys = ['cpu_second','gpu_second','stored_byte','network_byte']
            result.update(monetary_cost=sum(number(v,k)*prices[k] for v,k in zip(values,keys)),
                currency=prices['currency'],cost_status='ESTIMATE_FROM_EXPLICIT_UNIT_PRICES',
                cost_scope='CPU seconds + summed GPU intervals + stored bytes once + sent payload bytes; excludes energy and recurring storage rental')
        else:
            result['cost_status']='UNKNOWN_MISSING_RESOURCE_MEASUREMENT'
    return result


def search_policy(adapter):
    policy = dict(getattr(adapter,'search_policy',lambda:dict(batched=True,screen_repetitions=24,finalists=3,refine_repetitions=256))())
    # A combined process has no attributable per-candidate complete data path.
    # Counts must be preflighted by the caller; never hide the extra sessions.
    policy.update(batched=False,screening_metric='complete_data_path')
    return policy
