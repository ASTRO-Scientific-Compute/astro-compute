"""Namespaced composition of independent graphs; math stays in adapters."""
import copy
import json
import re
from pathlib import Path


def compose_independent(graphs, destination, *, repetitions, execution_mode=None):
    combined = dict(version=1, iterations=repetitions, buffers={}, kernels={}, nodes=[], outputs={},
                    description='Independent graphs, serialized baseline; GPU overlap NOT PROVEN')
    if execution_mode is not None:
        if execution_mode not in ('serial', 'concurrent') or not 2 <= len(graphs) <= 8:
            raise ValueError('MIX_EXECUTION_CONTRACT')
        combined.update(version=2, execution=dict(mode=execution_mode, lanes=len(graphs)),
                        description='Disjoint independent graph lanes; hardware overlap requires measured evidence')
    mapping = {}
    for lane, (prefix, source) in enumerate(graphs):
        if not re.fullmatch(r'[A-Za-z0-9_]+', prefix) or '__' in prefix or prefix in mapping:
            raise ValueError('INVALID_OR_DUPLICATE_GRAPH_NAMESPACE')
        source = Path(source).resolve()
        graph = json.loads(source.read_text())
        if graph['version'] != 1 or graph.get('iterations', 1) != repetitions:
            raise ValueError('COMPOSITION_REQUIRES_MATCHED_ITERATION_SEMANTICS')
        def name(value): return prefix + '__' + value
        for key, value in graph['buffers'].items():
            row = copy.deepcopy(value)
            if row.get('input'): row['input'] = str((source.parent / row['input']).resolve())
            combined['buffers'][name(key)] = row
        for key, value in graph['kernels'].items():
            row = copy.deepcopy(value)
            for backend in ('cuda', 'vulkan'):
                if backend in row:
                    row[backend]['path'] = str((source.parent / row[backend]['path']).resolve())
            combined['kernels'][name(key)] = row
        for value in graph['nodes']:
            row = copy.deepcopy(value)
            row['id'] = name(row['id']); row['kernel'] = name(row['kernel'])
            if execution_mode is not None: row['lane'] = lane
            row['after'] = [name(dep) for dep in row.get('after', [])]
            for binding in row['bind']: binding['buffer'] = name(binding['buffer'])
            combined['nodes'].append(row)
        mapping[prefix] = {}
        for key, value in graph['outputs'].items():
            row = copy.deepcopy(value); row['buffer'] = name(row['buffer'])
            combined['outputs'][name(key)] = row
            mapping[prefix][key + '.raw'] = name(key) + '.raw'
    if not graphs: raise ValueError('EMPTY_COMPOSITION')
    destination = Path(destination)
    destination.write_text(json.dumps(combined, indent=2) + '\n')
    return mapping


def weighted_throughput(completed_work, elapsed, standalone_rates, weights):
    """Dimensionless weighted speedup; never add beats/s to trajectories/s.

    Caller must first pass every graph's scientific and internal gates. Rates
    must use the identical work unit, dataset and device as the mixed run.
    A positive score alone proves neither kernel overlap nor resource overlap.
    """
    import math
    keys = set(completed_work)
    if keys != set(standalone_rates) or keys != set(weights) or not keys:
        raise ValueError('MIX_METRIC_KEYS')
    values = [elapsed, *completed_work.values(), *standalone_rates.values(), *weights.values()]
    if any(not math.isfinite(v) or v <= 0 for v in values):
        raise ValueError('MIX_METRIC_VALUE')
    return sum(weights[k] * completed_work[k] / elapsed / standalone_rates[k] for k in keys) / sum(weights.values())
