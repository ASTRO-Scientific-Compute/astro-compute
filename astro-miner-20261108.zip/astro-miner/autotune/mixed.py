"""Domain-neutral independent-graph comparison adapter and timing evidence.

Member adapters retain all mathematics and scientific acceptance rules. One
bundle counts as len(members) graph evaluations, even within one GPU session.
"""
import collections
import json
import math
import os
import shutil
from pathlib import Path
from .graphs import compose_independent
from .optimizer import save


class MixedAdapter:
    execution_context = 'mixed_serial_vs_concurrent_v1'

    def __init__(self, members, frozen_profile_files=()):
        self.members = members
        if not 2 <= len(members) <= 8:
            raise ValueError('MIX_MEMBER_COUNT')
        self.name = 'mixed_' + '_'.join(prefix for prefix, _, _ in members)
        self.max_parallelism = len(members)
        self.frozen_profile_files = list(frozen_profile_files)
        for _, adapter, config in members:
            if config not in adapter.candidates() or not adapter.preserves_operation_order(config):
                raise ValueError('MIX_MEMBER_CONFIG_NOT_ORDER_PRESERVING')
            # Canonical per-member ZERO BIT needs an explicit adapter checker.
            # Do not silently weaken a future strict contract through composition.
            if adapter.numerical_contract()['reference_zero_bit_required']:
                raise ValueError('MIX_CANONICAL_REFERENCE_ADAPTER_REQUIRED')

    def candidates(self):
        return [dict(id=mode, mode=mode) for mode in ('serial', 'concurrent')]

    def preserves_operation_order(self, config):
        return config in self.candidates()

    def evaluation_count(self, configs):
        return len(configs) * len(self.members)

    def numerical_contract(self):
        return dict(allow_reassociation=False, reference_zero_bit_required=False,
                    repeat_zero_bit_required=True, work_units_per_repeat=1,
                    work_unit='one complete fixed bundle; every member must pass its own gate',
                    cross_mode_zero_bit_required=True,
                    lane_order=[n for n,_,_ in self.members], batch_ratio=[1]*len(self.members),
                    selection_policy='fixed three E2E samples/mode; same work; all members accepted; cross-mode and repeated hashes identical',
                    members={n:dict(config=c, contract=a.numerical_contract()) for n,a,c in self.members})

    def fingerprint_files(self):
        files = {Path(__file__), *self.frozen_profile_files}
        for _, adapter, _ in self.members:
            files.update(adapter.fingerprint_files())
        return sorted(files)

    def graph(self, configs, repetitions, destination, *, single=False):
        if single or len(configs) != 1 or configs[0] not in self.candidates() or repetitions != 1:
            raise ValueError('MIX_REQUIRES_ONE_CONFIGURATION_ONE_COMPLETE_BUNDLE')
        config = configs[0]; destination = Path(destination); graphs = []; member_graphs = {}
        for prefix, adapter, cfg in self.members:
            folder = destination.parent / prefix; folder.mkdir()
            graph = adapter.graph([cfg], 1, folder/'graph.json')
            graphs.append((prefix, graph)); member_graphs[prefix] = str(graph)
        mapping = compose_independent(graphs, destination, repetitions=1, execution_mode=config['mode'])
        g = json.loads(destination.read_text())
        def name(value): return config['id'] + '__' + value
        g['buffers'] = {name(k):v for k,v in g['buffers'].items()}
        g['kernels'] = {name(k):v for k,v in g['kernels'].items()}
        for n in g['nodes']:
            n['id'] = name(n['id']); n['kernel'] = name(n['kernel'])
            n['after'] = [name(x) for x in n.get('after', [])]
            for b in n['bind']: b['buffer'] = name(b['buffer'])
        for o in g['outputs'].values(): o['buffer'] = name(o['buffer'])
        g['outputs'] = {name(k):v for k,v in g['outputs'].items()}
        save(destination, g)
        save(destination.with_suffix('.meta.json'), dict(config=config, member_graphs=member_graphs,
             mapping={member:{k:name(v) for k,v in rows.items()} for member,rows in mapping.items()},
             contract=self.numerical_contract()))
        return destination

    def validate(self, graph, out):
        meta = json.loads(Path(graph).with_suffix('.meta.json').read_text())
        if meta['contract'] != self.numerical_contract():
            raise ValueError('MIX_CONTRACT_CHANGED')
        checks = {}
        for prefix, adapter, _ in self.members:
            view = Path(out)/('member_'+prefix); view.mkdir(exist_ok=True)
            shutil.copy2(Path(out)/'RUN.json', view/'RUN.json')
            for original, combined in meta['mapping'][prefix].items():
                target = view/original
                if not target.exists(): os.link(Path(out)/combined, target)
            checks[prefix] = adapter.validate(meta['member_graphs'][prefix], view)
        accepted = all(c['status']=='PASS' for rows in checks.values() for c in rows.values())
        result = {meta['config']['id']:dict(status='PASS' if accepted else 'FAIL', members=checks,
                  scope='Every member keeps its separate scientific and internal contract; SIGNAL remains externally SCORED')}
        save(Path(out)/'MIX_VERIFICATION.json', result)
        return result


def interval_evidence(output):
    """GPU marker overlap only. Never infer simultaneous SM/CU instructions."""
    output = Path(output); native = json.loads((output/'native.json').read_text())
    domain = native.get('timestamp_domain', 'UNAVAILABLE')
    common = domain in ('CUDA_CONTEXT_COMMON_EVENT_ORIGIN', 'VULKAN_DEVICE_COMMON_EXT_CALIBRATED_TIMESTAMPS')
    intervals = []; lane_counts = collections.Counter()
    for line in (output/'events.tsv').read_text().splitlines():
        row = line.split('\t')
        if len(row) != 7: raise ValueError('LANE_EVENT_EVIDENCE_REQUIRED')
        duration, begin, end = map(float, row[3:6]); lane = int(row[6])
        if not all(math.isfinite(v) for v in (duration,begin,end)) or duration<0 or begin<0 or end<begin:
            raise ValueError('TIMESTAMP_INVALID_OR_WRAP_REQUIRES_REVIEW')
        if lane<0 or lane>=native['lane_count']: raise ValueError('EVENT_LANE_RANGE')
        intervals.append((begin,end,lane)); lane_counts[lane] += 1
    if not intervals: raise ValueError('EMPTY_GPU_TIMELINE')
    points = collections.defaultdict(list)
    for a,b,lane in intervals:
        points[a].append((lane,1)); points[b].append((lane,-1))
    active = collections.Counter(); previous = min(points); overlap = busy = 0.; maximum = 0
    for when, changes in sorted(points.items()):
        count = sum(v>0 for v in active.values())
        if count: busy += when-previous
        if count>1: overlap += when-previous
        maximum = max(maximum,count)
        for lane,delta in changes: active[lane] += delta
        if any(v<0 for v in active.values()): raise ValueError('TIMESTAMP_ACCOUNTING')
        previous = when
    if any(active.values()): raise ValueError('UNCLOSED_GPU_TIMELINE')
    return dict(timestamp_domain=domain, comparable_between_lanes=common,
                observed_dispatches_per_lane=dict(lane_counts),
                marker_union_ms=busy if common else None,
                cross_lane_marker_overlap_ms=overlap if common else None,
                max_overlapping_marker_lanes=maximum if common else None,
                interpretation='GPU marker intervals may include scheduling delay or preemption; overlap is not proof of simultaneous SM/CU instruction execution',
                simultaneous_instruction_execution='NOT_PROVEN', energy_joules=None)


def compare(adapter, device, runner, *, order_offset=0):
    """Six fixed measurements, no adaptive retries or extra warm-up sessions."""
    from .optimizer import fingerprint, choose, canonical_hashes, sha
    before, context = fingerprint(adapter, device)
    configs = adapter.candidates(); observations = {c['id']:[] for c in configs}
    for round_ in range(3):
        order = configs if (round_+order_offset)%2==0 else list(reversed(configs))
        for config in order:
            row = runner.run(adapter, device, [config], 1, f'mix_round{round_}')
            if row['validation'][config['id']]['status']!='PASS':
                raise RuntimeError('MIX_MEMBER_GATE_FAILED_NO_EXTRA_GPU_RUNS')
            timeline = interval_evidence(row['output'])
            expected_lanes = {0} if config['mode']=='serial' else set(range(adapter.max_parallelism))
            if set(timeline['observed_dispatches_per_lane']) != expected_lanes:
                raise RuntimeError('ACTUAL_DISPATCH_LANES_MISMATCH')
            save(Path(row['output'])/'GPU_TIMELINE.json', timeline)
            row['timeline'] = timeline
            row['output_gate'] = canonical_hashes(row)
            observations[config['id']].append(row)
    after, _ = fingerprint(adapter, device)
    if before != after: raise RuntimeError('MIX_IDENTITY_CHANGED_DURING_MEASUREMENT')
    all_rows = [r for rows in observations.values() for r in rows]
    hashes = [r['output_gate'] for r in all_rows]
    exact = bool(hashes[0]) and all(h==hashes[0] for h in hashes[1:])
    result = dict(device=device, context=context, fingerprint=before,
                  execution_context=adapter.execution_context,
                  cross_mode_and_repeat_bit_gate='ZERO_BIT' if exact else 'NOT_ZERO_BIT',
                  runs=[r['output'] for r in all_rows],
                  timing_evidence=[r['timeline'] for r in all_rows],
                  frozen_member_configs={n:c for n,_,c in adapter.members},
                  frozen_configs_scope='Previous standalone configurations are test inputs, not valid performance profiles for the changed engine',
                  batch_ratio={n:1 for n,_,_ in adapter.members},
                  learned_scope='Only serial vs concurrent for this fixed bundle; no mixed launch-geometry search',
                  energy_status='NOT_MEASURED', simultaneous_instruction_execution='NOT_PROVEN')
    if exact:
        result.update(choose([(c,observations[c['id']]) for c in configs], adapter.numerical_contract()))
        medians = {r['config']['id']:r['seconds_per_recipe'] for r in result['ranking']}
        result['matched_e2e_speedup_serial_over_concurrent'] = medians['serial']/medians['concurrent']
    else:
        result['selection_status'] = 'REJECTED_CROSS_MODE_BIT_MISMATCH'
        # Keep an explicit byte-level localization for every differing output.
        differences = []
        baseline = all_rows[0]
        for row in all_rows[1:]:
            for name, digest in row['output_gate'].items():
                if hashes[0].get(name)==digest: continue
                a=Path(baseline['output'])/(baseline['configs'][0]['id']+'__'+name)
                b=Path(row['output'])/(row['configs'][0]['id']+'__'+name)
                av,bv=a.read_bytes(),b.read_bytes(); offsets=[i for i,(x,y) in enumerate(zip(av,bv)) if x!=y]
                differences.append(dict(baseline=str(a),other=str(b),size_a=len(av),size_b=len(bv),
                                        differing_common_bytes=len(offsets),first_offsets=offsets[:32]))
        result['bit_differences'] = differences
    profile = runner.destination/(device['pci'].replace(':','_')+'_COMPARISON.json')
    save(profile, result)
    if not exact: raise RuntimeError('MIX_ZERO_BIT_GATE_FAILED:'+str(profile))
    # A distinct cache namespace; never replace a standalone profile.
    from .optimizer import P
    save(P/'autotune/mixed_profiles'/(adapter.name+'_'+device['pci'].replace(':','_')+'_'+device['backend']+'.json'), result)
    runner.persist()
    return result
