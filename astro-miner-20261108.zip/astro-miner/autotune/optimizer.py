"""Workload-neutral search, profiling and cache. Execution stays in astro.py.

Adapters supply legal candidates, ordinary v1 graphs and scientific validation.
No vendor name determines a winner. No reference answer is sent to the GPU.
"""
import collections,hashlib,json,math,os,random,statistics,subprocess,sys,time,uuid,shutil,fcntl,resource
from pathlib import Path
from .budget import Budget
from .data_path import context as objective_context, evaluate as data_path_score, identity as objective_identity, search_policy

P=Path(__file__).resolve().parents[1]
LEDGER=P/'autotune/CAMPAIGN.json'

def sha(path):
    h=hashlib.sha256()
    with Path(path).open('rb') as f:
        while b:=f.read(8*1024*1024):h.update(b)
    return h.hexdigest()

def save(path,value):
    path.parent.mkdir(parents=True,exist_ok=True)
    temp=path.with_suffix(path.suffix+'.new');temp.write_text(json.dumps(value,indent=2)+'\n');temp.replace(path)

def fingerprint(adapter,device,objective=None):
    pci=Path('/sys/bus/pci/devices')/device['pci'];hardware=dict(device)
    for f in ['vendor','device','subsystem_vendor','subsystem_device','revision','unique_id']:
        try:hardware[f]=(pci/f).read_text().strip()
        except OSError:pass
    driver=(pci/'driver').resolve().name
    driver_files=[Path('/proc/driver/nvidia/version'),Path('/sys/module')/driver/'version']
    hardware['driver_versions']={str(f):f.read_text().strip() for f in driver_files if f.exists()}
    # Kernel and userspace driver changes also invalidate a cached choice.
    hardware['kernel_release']=os.uname().release
    files=adapter.fingerprint_files()+[P/'BUILD_MANIFEST.json',P/'build/science-engine',*sorted((P/'autotune').glob('*.py'))]
    value=dict(hardware=hardware,workload=adapter.name,numerical_contract=adapter.numerical_contract(),
               execution_context=getattr(adapter,'execution_context','standalone'),optimization_objective=objective_context(objective),files={str(f):sha(f) for f in files})
    key=hashlib.sha256(json.dumps(value,sort_keys=True).encode()).hexdigest()
    return key,value

def reserve_candidates(count,label):
    raise RuntimeError('MULTI_RESOURCE_RESERVATION_REQUIRED: candidate-only admission removed')

def legal_candidates(adapter):
    contract=adapter.numerical_contract()
    if contract['reference_zero_bit_required'] and not contract.get('canonical_output_sha256'):
        raise RuntimeError('STRICT_CONTRACT_REQUIRES_CANONICAL_BINARY_REFERENCE')
    return [c for c in adapter.candidates() if contract['allow_reassociation'] or adapter.preserves_operation_order(c)]

def canonical_hashes(r):
    hashes=json.loads((Path(r['output'])/'GPU_EVIDENCE.json').read_text())['output_sha256']
    return {name.split('__',1)[-1]:value for name,value in hashes.items()}

def host_cpu():
    return sum(v.ru_utime+v.ru_stime for v in [resource.getrusage(resource.RUSAGE_SELF),resource.getrusage(resource.RUSAGE_CHILDREN)])

class Runner:
    def __init__(self,destination,max_runs=48,ledger=LEDGER,completed_runs=None,objective=None):
        self.destination=destination;destination.mkdir(parents=True,exist_ok=True)
        self.ledger=Path(ledger)
        self.objective=objective_context(objective)
        self.max_runs=max_runs;self.runs=list(completed_runs or []);self.started=time.monotonic()
        self.replayed=set()
        self.engine_sources={str(f):sha(f) for f in (P/'engine').rglob('*') if f.is_file() and '__pycache__' not in f.parts}

    def run(self,adapter,device,configs,repetitions,label,*,single=False):
        # Explicit resume may reuse verified evidence, never silently rerun it.
        # The caller supplies only audited CHECKED records; verify every input
        # and program hash again before using a previous physical measurement.
        for index,row in enumerate(self.runs):
            if index in self.replayed or not row.get('resume_evidence'):continue
            if (row.get('adapter'),row['device'],row['configs'],row['repetitions'],row['label'],row['single'])!=(adapter.name,device,configs,repetitions,label,single):continue
            if row.get('optimization_objective')!=self.objective:raise RuntimeError('RESUME_OBJECTIVE_MISMATCH')
            if label!='screen':raise RuntimeError('RECOVERY_ONLY_REUSES_SCREENING_GPU_TIMING')
            if row['status']!='CHECKED':raise RuntimeError('RESUME_RECORD_NOT_CHECKED')
            manifest=json.loads((Path(row['output'])/'RUN.json').read_text())
            if any(sha(f)!=digest for f,digest in manifest['files'].items()):raise RuntimeError('RESUME_INPUT_OR_PROGRAM_CHANGED')
            proof=json.loads((Path(row['output'])/'GPU_EVIDENCE.json').read_text())
            if any(sha(Path(row['output'])/f)!=digest for f,digest in proof['output_sha256'].items()):raise RuntimeError('RESUME_OUTPUT_CHANGED')
            expected=adapter.validate(Path(row['graph']),Path(row['output']))
            if expected!=row['validation']:
                # Verification wall times are observations, not mathematical results.
                for cfg in configs:
                    if expected[cfg['id']]['status']!=row['validation'][cfg['id']]['status']:raise RuntimeError('RESUME_CONTRACT_CHANGED')
            self.replayed.add(index)
            return row
        # The native CLI watchdog allows 60 s work + up to 30 s termination.
        # Reserve worker wall and summed GPU marker intervals independently.
        # Concurrent lanes can accumulate up to lane_count times worker wall.
        budget=Budget(self.ledger);memory=budget.memory_limit(device['pci'])
        parallelism=getattr(adapter,'max_parallelism',1)
        if type(parallelism) is not int or not 1<=parallelism<=8:raise ValueError('PARALLELISM_BOUND')
        evaluations=getattr(adapter,'evaluation_count',lambda c:len(c))(configs)
        request=dict(sessions=1,candidate_evaluations=evaluations,worker_seconds=95.,gpu_seconds=95.*parallelism,memory_bytes=memory)
        budget.preflight(request,device['pci'])
        self.reservation=None
        try:
            return self._run(adapter,device,configs,repetitions,label,single=single,budget=budget,request=request)
        except BaseException as error:
            if self.reservation:budget.unknown(self.reservation,error)
            raise

    def _run(self,adapter,device,configs,repetitions,label,*,single,budget,request):
        if len(self.runs)>=self.max_runs:raise RuntimeError('AUTOTUNE_RUN_BUDGET_EXHAUSTED')
        contract=adapter.numerical_contract()
        if not contract['allow_reassociation'] and any(not adapter.preserves_operation_order(c) for c in configs):
            raise RuntimeError('NUMERICAL_CONTRACT_FORBIDS_REASSOCIATION')
        if contract['reference_zero_bit_required'] and not contract.get('canonical_output_sha256'):
            raise RuntimeError('STRICT_CONTRACT_REQUIRES_CANONICAL_BINARY_REFERENCE')
        total_start=time.monotonic();cpu_start=host_cpu()
        number=len(self.runs);d=self.destination/f'{number:02d}_{label}_{device["pci"].replace(":","_")}'
        d.mkdir();graph=adapter.graph(configs,repetitions,d/'graph.json',single=single)
        g=json.loads(graph.read_text())
        if g.get('output_transport') or any(o.get('compression') for o in g['outputs'].values()):
            raise ValueError('COMPRESSED_TUNING_REQUIRES_RESIDENT_CHECKER_AND_TRANSPORT_EVIDENCE')
        execution=g.get('execution',{'mode':'serial','lanes':1})
        if execution.get('lanes',1)>getattr(adapter,'max_parallelism',1):raise ValueError('GRAPH_EXCEEDS_RESERVED_PARALLELISM')
        sizes={'f32':4,'f64':8,'i32':4,'u32':4}
        declared=sum(sizes[b['dtype']]*math.prod(b['shape']) for b in g['buffers'].values())
        if declared>request['memory_bytes']:raise RuntimeError('DECLARED_BUFFERS_EXCEED_MEMORY_BUDGET')
        self.reservation=budget.reserve(request,device['pci'],label)
        item=dict(adapter=adapter.name,label=label,device=device,configs=configs,graph=str(graph),repetitions=repetitions,single=single,status='STARTED')
        item.update(optimization_objective=self.objective,resource_reservation=self.reservation,resource_request=request,resource_ledger=str(self.ledger))
        self.runs.append(item);self.persist()
        env=os.environ.copy();env.update(OPENBLAS_NUM_THREADS='1',OMP_NUM_THREADS='1',PYTHONDONTWRITEBYTECODE='1')
        env['SCIENCE_BUFFER_BUDGET_BYTES']=str(request['memory_bytes'])
        cmd=[sys.executable,'-B',str(P/'astro.py'),'run','--graph',str(graph),'--device',device['pci'],'--backend',device['backend'],'--timeout','60']
        graph_done=time.monotonic();graph_cpu=host_cpu()
        started=time.monotonic();proc=subprocess.run(cmd,capture_output=True,text=True,env=env)
        item.update(cli_seconds=time.monotonic()-started,argv=cmd,returncode=proc.returncode)
        (d/'cli.stdout').write_text(proc.stdout);(d/'cli.stderr').write_text(proc.stderr)
        if proc.returncode:
            item.update(status='EXECUTION_FAILED',error=proc.stderr);self.persist()
            # Do not silently retry an ownership/driver/timeout failure.
            raise RuntimeError(proc.stderr)
        out=Path(json.loads(proc.stdout.splitlines()[-1])['output']);item['output']=str(out)
        cli_done=time.monotonic();cli_cpu=host_cpu()
        checks=adapter.validate(graph,out);item['validation']=checks
        validation_done=time.monotonic();validation_cpu=host_cpu()
        native=json.loads((out/'native.json').read_text());run=json.loads((out/'RUN.json').read_text())
        item['native']=native;events=[];totals=collections.defaultdict(float)
        for line in (out/'events.tsv').read_text().splitlines():
            v=line.split('\t');ms=float(v[3])
            if not math.isfinite(ms) or ms<0:raise ValueError('INVALID_GPU_TIMING')
            events.append(v[0]);totals[v[0].split('__',1)[0]]+=ms
        expected=collections.Counter({n['id']:g['iterations'] for n in g['nodes']})
        if collections.Counter(events)!=expected:raise ValueError('DISPATCH_EVIDENCE_MISMATCH')
        # Ignore the first complete sweep when ranking screening candidates.
        per_sweep=[];node_count=len(g['nodes']);raw=(out/'events.tsv').read_text().splitlines()
        for start in range(node_count if len(raw)>node_count else 0,len(raw),node_count):
            sums=collections.defaultdict(float)
            for line in raw[start:start+node_count]:
                v=line.split('\t');sums[v[0].split('__',1)[0]]+=float(v[3])
            per_sweep.append(dict(sums))
        scores={c['id']:statistics.median(s[c['id']] for s in per_sweep) for c in configs}
        retained=out/'program_evidence';retained.mkdir(exist_ok=True);programs=[]
        for k in g['kernels'].values():
            prog=k[device['backend']];f=Path(prog['path']);digest=sha(f)
            if run['files'][str(f)]!=digest:raise ValueError('PROGRAM_CHANGED')
            shutil.copy2(f,retained/f.name)
            programs.append(dict(**prog,sha256=digest,local_size=k['local_size']))
        shutil.copy2(P/'build/science-engine',retained/'science-engine')
        proof=dict(device=(out/'native.log').read_text().splitlines()[0],programs=programs,
                   engine_sha256=sha(P/'build/science-engine'),dispatch_count=len(events),expected_dispatch_count=sum(expected.values()),
                   output_sha256={f.name:sha(f) for f in out.glob('*.raw')},reference_answers_fed_to_gpu=False)
        save(out/'GPU_EVIDENCE.json',proof)
        if contract['reference_zero_bit_required']:
            for cfg in configs:
                actual={k.split('__',1)[1]:v for k,v in proof['output_sha256'].items() if k.startswith(cfg['id']+'__')}
                if actual!=contract['canonical_output_sha256']:
                    item['validation'][cfg['id']]['status']='FAIL'
                    item['validation'][cfg['id']]['contract_failure']='REFERENCE_NOT_ZERO_BIT'
        save(out/'NUMERICAL_CONTRACT_VERIFICATION.json',dict(contract=contract,candidates=item['validation']))
        item.update(status='CHECKED',screen_gpu_median_ms=scores,native_compute_seconds=native['compute_seconds'],
                    run_plus_validation_evidence_seconds=time.monotonic()-started,identity=proof['device'],
                    full_e2e_seconds=time.monotonic()-total_start,full_host_cpu_seconds=host_cpu()-cpu_start,
                    gpu_kernel_seconds=sum(totals.values())/1000,
                    energy_joules=None,energy_status='NOT_MEASURED',execution_context=getattr(adapter,'execution_context','standalone'),
                    phase_costs=dict(graph_prepare=dict(wall_seconds=graph_done-total_start,cpu_seconds=graph_cpu-cpu_start),
                                     cli=dict(wall_seconds=cli_done-graph_done,cpu_seconds=cli_cpu-graph_cpu),
                                     validation=dict(wall_seconds=validation_done-cli_done,cpu_seconds=validation_cpu-cli_cpu),
                                     evidence=dict(wall_seconds=time.monotonic()-validation_done,cpu_seconds=host_cpu()-validation_cpu)))
        item['stored_bytes']=sum(f.stat().st_size for f in out.glob('*.raw'))
        item['network_payload_bytes']=item['stored_bytes']+sum(f.stat().st_size for f in out.rglob('*') if f.is_file() and f.suffix!='.raw')
        item['data_path_score']=data_path_score(item,self.objective)
        costs=json.loads((P/'COST.json').read_text())
        attempt=next(a for a in costs['attempts'] if a['output']==str(out))
        if attempt['status']!='FINISHED':raise RuntimeError('WORKER_COST_NOT_CLOSED')
        budget.settle(self.reservation,worker_seconds=attempt['worker_envelope_seconds'],
                      gpu_seconds=item['gpu_kernel_seconds'],peak_bytes=native['gpu_allocated_peak_bytes'],evidence=out)
        save(d/'RESULT.json',item);self.persist()
        print(json.dumps(dict(label=label,pci=device['pci'],candidates=len(configs),passes=sum(v['status']=='PASS' for v in checks.values()),compute_seconds=native['compute_seconds'])),flush=True)
        return item

    def persist(self):
        now={str(f):sha(f) for f in (P/'engine').rglob('*') if f.is_file() and '__pycache__' not in f.parts}
        if now!=self.engine_sources:raise RuntimeError('COMMON_ENGINE_CHANGED')
        save(self.destination/'PROGRESS.json',dict(runs=self.runs,max_runs=self.max_runs,wall_seconds=time.monotonic()-self.started,engine_unchanged=True))

def ranked_valid(configs,result):
    if len(configs)!=1 or 'data_path_score' not in result:
        raise ValueError('ISOLATED_COMPLETE_DATA_PATH_SCREEN_REQUIRED')
    return [c for c in configs if result['validation'][c['id']]['status']=='PASS']

def choose(measurements,contract,objective=None):
    objective=objective_context(objective)
    rows=[]
    for cfg,runs in measurements:
        if len(runs)!=3 or not all(r['validation'][cfg['id']]['status']=='PASS' for r in runs):continue
        hashes=[canonical_hashes(r) for r in runs]
        if not hashes[0]:continue
        repeat_equal=all(h==hashes[0] for h in hashes[1:])
        if contract['repeat_zero_bit_required'] and not repeat_equal:continue
        if contract['reference_zero_bit_required'] and (not contract.get('canonical_output_sha256') or any(h!=contract['canonical_output_sha256'] for h in hashes)):continue
        units=contract['work_units_per_repeat']
        scores=[data_path_score(r,objective) for r in runs]
        values=[v['seconds']/(r['repetitions']*units) for r,v in zip(runs,scores)]
        if any(not math.isfinite(x) or x<=0 for x in values):continue
        median=statistics.median(values);mad=statistics.median(abs(x-median) for x in values)
        gpu=statistics.median(r['native_compute_seconds']/(r['repetitions']*units) for r in runs)
        host=statistics.median(r['native']['parent_cpu_seconds'] for r in runs)
        vram=max(r['native']['gpu_allocated_peak_bytes'] for r in runs)
        full_cpu=[r.get('full_host_cpu_seconds') for r in runs]
        rows.append(dict(config=cfg,optimization_objective=objective,data_path_scores=scores,seconds_per_recipe=median,correct_work_per_second=1/median,mad=mad,samples=values,
                         gpu_compute_seconds_per_work=gpu,native_host_cpu_seconds_per_batch=host,
                         full_host_cpu_seconds_per_batch=statistics.median(full_cpu) if all(x is not None for x in full_cpu) else None,
                         peak_vram_bytes=vram,energy_joules_per_work=None,energy_status='NOT_MEASURED',repeat_bit_gate='ZERO_BIT' if repeat_equal else 'NOT_ZERO_BIT',
                         e2e_scope='Includes graph preparation' if all('full_e2e_seconds' in r for r in runs) else 'Recorded CLI + scientific validation + evidence; graph preparation not separately timed'))
    rows.sort(key=lambda x:x['seconds_per_recipe'])
    if not rows:raise RuntimeError('NO_SCIENTIFICALLY_VALID_CANDIDATE')
    # Treat <3% E2E differences as a practical tie, then prefer full process-tree
    # CPU, GPU work and memory. Never claim a global or energy optimum.
    near=[r for r in rows if r['seconds_per_recipe']<=rows[0]['seconds_per_recipe']*1.03]
    winner=min(near,key=lambda r:(r['full_host_cpu_seconds_per_batch'] if r['full_host_cpu_seconds_per_batch'] is not None else float('inf'),r['gpu_compute_seconds_per_work'],r['peak_vram_bytes']))
    noisy=[r['config']['id'] for r in rows if r['mad']/r['seconds_per_recipe']>0.05]
    ranges_overlap=any(max(min(winner['samples']),min(r['samples']))<=min(max(winner['samples']),max(r['samples'])) for r in rows if r is not winner)
    uncertainty=dict(provisional=bool(objective['objective']=='network' or noisy or ranges_overlap or len(near)>1),
                     estimated_network=objective['objective']=='network',
                     high_variability_candidates=noisy,observed_e2e_ranges_overlap=ranges_overlap,
                     practical_tie=len(near)>1,
                     scope='Three observed samples only; MAD/median >5%, overlapping observed ranges or <3% practical tie marks provisional preference. Not a statistical confidence interval; no automatic extra GPU trials.')
    return dict(winner=winner['config'],ranking=rows,selection_status=('NETWORK_MODEL_SHORTLIST_PREFERENCE' if objective['objective']=='network' else 'E2E_SHORTLIST_WINNER' if len(near)==1 else 'E2E_NEAR_TIE_FULL_CPU_TIEBREAK'),
                decision_uncertainty=uncertainty,optimization_objective=objective,timing_status=rows[0]['data_path_scores'][0]['timing_status'],
                decision_policy='Minimize complete data-path time; network time is explicitly modeled; 3% tie prefers full process-tree CPU, GPU and VRAM. Monetary estimate is reported separately, never silently weighted against time.',
                work_unit=contract['work_unit'],full_search_space_e2e_optimum='INCONCLUSIVE: only screened finalists have isolated E2E repetitions')

def profile_path(adapter,device,objective=None):
    return P/'autotune/profiles'/objective_identity(objective)/(adapter.name+'_'+device['pci'].replace(':','_')+'_'+device['backend']+'.json')

def load_profile(adapter,device,objective=None):
    p=profile_path(adapter,device,objective);profile=json.loads(p.read_text());key,_=fingerprint(adapter,device,objective)
    if profile['fingerprint']!=key:raise RuntimeError('AUTOTUNE_PROFILE_STALE_RUN_TUNE')
    return profile

def tune(adapter,devices,runner):
    profiles=[]
    for device in devices:
        configs=legal_candidates(adapter);random.Random(7401).shuffle(configs)
        policy=search_policy(adapter)
        screens=[runner.run(adapter,device,batch,policy['screen_repetitions'],'screen') for batch in ([configs] if policy['batched'] else [[c] for c in configs])]
        valid=[(c,s) for s in screens for c in configs if c['id'] in s['validation'] and s['validation'][c['id']]['status']=='PASS']
        eligible=[c for c,s in sorted(valid,key=lambda cs:cs[1]['data_path_score']['seconds']/(cs[1]['repetitions']*adapter.numerical_contract()['work_units_per_repeat']))]
        if not eligible:raise RuntimeError('NO_VALID_SCREEN_CANDIDATE')
        finalists=eligible[:policy['finalists']];measurements={c['id']:[] for c in finalists}
        # Fixed three rounds, order varied in advance; no repeat-until-fast rule.
        for round_ in range(3):
            order=list(finalists);random.Random(8100+round_).shuffle(order)
            for cfg in order:
                measurements[cfg['id']].append(runner.run(adapter,device,[cfg],policy['refine_repetitions'],f'refine{round_}'))
        result=choose([(c,measurements[c['id']]) for c in finalists],adapter.numerical_contract(),runner.objective)
        key,context=fingerprint(adapter,device,runner.objective)
        result.update(workload=adapter.name,device=device,fingerprint=key,context=context,
                      native_identity=screens[0]['identity'],screening_candidates=len(configs),contract_valid_screening_candidates=len(eligible),
                      search_result=str(runner.destination),selection_metric='Median complete data-path time; measured local or explicitly modeled network; three separate runs; 3% tie rule',
                      scope='Best measured among this finite candidate grid, not a global optimum',
                      search_policy=dict(**policy,screen_drop_first=False,refine_rounds=3))
        save(profile_path(adapter,device,runner.objective),result);profiles.append(result)
    return profiles
