"""Content-addressed reuse of caller-certified lossless reference packets.

No scientific formulas and no GPU execution. Cache entries are NOT themselves
scientific certificates: the current raw result must already have passed its
own independent checker. Consumers must seal/hash the selected packet against
its pinned digest before comparing it with a fresh output. Reuse avoids encoding
and writing identical reference bytes again, including across backend identities.
The current graph/program/MathSpec still receives its own reference manifest.
"""
import hashlib
import json
from pathlib import Path


def key(raw_sha256, raw_bytes, compression):
    if len(raw_sha256)!=64 or set(raw_sha256)-set('0123456789abcdef'):
        raise ValueError('CACHE_RAW_SHA256')
    if type(raw_bytes) is not int or raw_bytes<=0 or compression.get('codec')!='qgc1':
        raise ValueError('CACHE_OUTPUT_CONTRACT')
    return json.dumps([raw_sha256,raw_bytes,compression],sort_keys=True,separators=(',',':'))


class CanonicalPacketCache:
    def __init__(self, index, trusted_sha256, encoder_sha256):
        data=Path(index).read_bytes()
        if hashlib.sha256(data).hexdigest()!=trusted_sha256:raise ValueError('UNTRUSTED_PACKET_CACHE_INDEX')
        record=json.loads(data)
        if record['schema']!='CANONICAL_PACKET_CACHE_V1' or record['encoder_sha256']!=encoder_sha256:
            raise ValueError('PACKET_CACHE_ENCODER_CHANGED')
        self.entries={};self.hits=0;self.misses=0
        for entry in record['entries']:
            k=key(entry['raw_sha256'],entry['raw_bytes'],entry['compression'])
            if k in self.entries and self.entries[k]['sha256']!=entry['sha256']:
                raise ValueError('NONCANONICAL_CACHE_COLLISION')
            if len(entry['sha256'])!=64 or set(entry['sha256'])-set('0123456789abcdef'):
                raise ValueError('CACHE_PACKET_SHA256')
            self.entries[k]=dict(entry)

    def lookup(self, raw_sha256, raw_bytes, compression):
        entry=self.entries.get(key(raw_sha256,raw_bytes,compression))
        if entry is None or not Path(entry['file']).is_file():
            self.misses+=1;return None
        if Path(entry['file']).stat().st_size!=entry['encoded_bytes']:
            raise ValueError('CACHE_PACKET_SIZE_CHANGED')
        self.hits+=1
        return dict(entry,compression=dict(entry['compression']),reuse_status='CANONICAL_REUSE_REQUIRES_SEALED_DIGEST_CHECK_BY_CONSUMER',
                    wall_seconds=0.,cpu_seconds=0.)
