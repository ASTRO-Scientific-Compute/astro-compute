#!/usr/bin/env python3
"""Finite synthetic miner benchmark: three independent u32 graphs, one GPU.

This is a runtime benchmark foundation, not a scientific workload or an
autotuner result. Every output word is compared with a CPU integer oracle.
"""
import argparse
import array
import json
import os
import sys
import time
import uuid
from pathlib import Path

ROOT = Path(__file__).resolve().parent
sys.dont_write_bytecode = True
sys.path.insert(0, str(ROOT/'src'))
from engine.resident import run_session
from engine.session import environment, process_tree_cpu


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('--device', required=True, help='Exact PCI address from astro.py devices')
    parser.add_argument('--backend', required=True, choices=['cuda', 'vulkan'])
    parser.add_argument('--mode', choices=['serial', 'concurrent'], default='serial')
    parser.add_argument('--jobs', type=int, default=4)
    parser.add_argument('--elements', type=int, default=65536)
    parser.add_argument('--rounds', type=int, default=32)
    args = parser.parse_args()
    if not 1 <= args.jobs <= 32 or not 64 <= args.elements <= 1048576 or not 1 <= args.rounds <= 256:
        parser.error('Bounds: jobs 1..32, elements 64..1048576, rounds 1..256')
    for folder in ['home', 'cache', 'tmp', 'logs', 'results']:
        (ROOT/folder).mkdir(exist_ok=True)
    os.environ.update(environment())
    start, cpu = time.monotonic(), process_tree_cpu()
    folder = ROOT/'results'/('bench-'+time.strftime('%Y%m%dT%H%M%SZ', time.gmtime())+'-'+uuid.uuid4().hex[:8])
    folder.mkdir()
    lanes = 3 if args.mode == 'concurrent' else 1
    seeds = [1, 17, 257]
    expected = {}
    oracle_start = time.monotonic()
    for lane, seed in enumerate(seeds):
        values = array.array('I')
        if values.itemsize != 4:
            raise RuntimeError('BENCH_REQUIRES_32_BIT_UNSIGNED_INT')
        for i in range(args.elements):
            value = i ^ seed
            for _ in range(args.rounds):
                value = (value * 1664525 + 1013904223) & 0xffffffff
                value ^= value >> 16
            values.append(value)
        if sys.byteorder != 'little':
            values.byteswap()
        expected[f'graph{lane}'] = values.tobytes()
    oracle_seconds = time.monotonic()-oracle_start
    graph = dict(version=2, iterations=1,
        description='Synthetic u32 benchmark only; three independent seeds',
        execution=dict(mode=args.mode, lanes=lanes),
        buffers={}, kernels={'bench': dict(bindings=1, words=3, local_size=[64, 1, 1], requires=[],
            cuda=dict(path=str(ROOT/'build/bench.ptx'), entry='bench'),
            vulkan=dict(path=str(ROOT/'build/bench.spv'), entry='main'))}, nodes=[], outputs={})
    for i, seed in enumerate(seeds):
        name = f'graph{i}'
        graph['buffers'][name] = dict(dtype='u32', shape=[args.elements])
        graph['nodes'].append(dict(id=name, kernel='bench', lane=i if lanes > 1 else 0,
            after=[], bind=[dict(buffer=name, access='write')],
            push=[args.elements, args.rounds, seed], global_size=[args.elements, 1, 1]))
        graph['outputs'][name] = dict(buffer=name)
    path = folder/'graph.json'
    path.write_text(json.dumps(graph, indent=2)+'\n')

    def validate(view, hashes):
        return {name: dict(status='PASS' if (view/(name+'.raw')).read_bytes() == value else 'FAIL',
                          scope='ALL_OUTPUT_BYTES_VS_CPU_U32_ORACLE', compared_bytes=len(value))
                for name, value in expected.items()}

    timeout = 60
    ledger = folder/'BUDGET.json'
    ledger.write_text(json.dumps(dict(version=2, launch_status='OPEN',
        resources=dict(limits=dict(sessions=1, candidate_evaluations=3*args.jobs,
            worker_seconds=timeout+30., gpu_seconds=(timeout+30.)*lanes),
            charged=dict(sessions=0, candidate_evaluations=0, worker_seconds=0., gpu_seconds=0.),
            memory_limits_bytes={args.device: 256*1024**2}), resource_reservations=[]), indent=2)+'\n')
    catalog = [dict(name='synthetic_three_graph_bundle', graph=path, evaluations=3,
                    validate=validate, repeat_zero_bit_required=True)]
    try:
        result = run_session(catalog, [0]*args.jobs, args.backend, args.device,
            folder/'session', ledger, timeout=timeout, snapshot_bytes=64*1024**2,
            resident_bytes=64*1024**2, output_bytes=16*1024**2, deferred_digest=True,
            output_compression='raw')
    finally:
        state = json.loads(ledger.read_text())
        if state['launch_status'] == 'OPEN':
            state['launch_status'] = 'CLOSED_BENCH_INVOCATION'
            ledger.write_text(json.dumps(state, indent=2)+'\n')
    wall = time.monotonic()-start
    summary = dict(status=result['status'], mode=args.mode, device=args.device,
        backend=args.backend, sessions=1, independent_synthetic_cases=3,
        workset_executions=args.jobs, repeat_executions=args.jobs-1,
        graph_evaluations=3*args.jobs, full_e2e_seconds=wall,
        full_process_tree_cpu_seconds=process_tree_cpu()-cpu,
        cpu_oracle_preparation_seconds=oracle_seconds,
        session_e2e_seconds=result['full_e2e_seconds'],
        summed_gpu_intervals_seconds=result['gpu_marker_seconds'],
        backend_peak_bytes=result['backend_peak_bytes'],
        correct_graph_evaluations_per_second=3*args.jobs/wall,
        output_bytes_per_job=3*args.elements*4, output=str(folder),
        scope='Synthetic INT32 runtime baseline; build excluded; CPU oracle preparation included; buffered writes, no fsync durability timing; no speedup or physical-overlap claim')
    (folder/'BENCH_RESULT.json').write_text(json.dumps(summary, indent=2)+'\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
