#include <cuda_runtime.h>
extern "C" __global__ void bench(unsigned int* output, unsigned int n, unsigned int rounds, unsigned int seed) {
    unsigned int i = blockIdx.x * blockDim.x + threadIdx.x;
    if (i >= n) return;
    unsigned int x = i ^ seed;
    for (unsigned int r = 0; r < rounds; ++r) {
        x = x * 1664525u + 1013904223u;
        x ^= x >> 16;
    }
    output[i] = x;
}
