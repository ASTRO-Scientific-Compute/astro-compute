#pragma once
#include <algorithm>
#include <array>
#include <chrono>
#include <cstdint>
#include <cstdlib>
#include <limits>
#include <memory>
#include <stdexcept>
#include <string>
#include <vector>

// Workload-neutral ABI: storage buffers followed by uint32 scalar words.
// CUDA entries take separate pointer/scalar arguments; Vulkan uses bindings
// 0..N-1 and a push-constant word array. Math belongs to the loaded program.
struct Buffer : std::enable_shared_from_this<Buffer> {
    size_t bytes=0;
    const void* owner=nullptr;
    uint64_t id=0;
    virtual ~Buffer()=default;
};
struct ProgramSpec {
    std::string path, entry;
    uint32_t bindings=0, words=0;
    std::array<uint32_t,3> local{64,1,1};
    bool float64=false;
};
struct Program : std::enable_shared_from_this<Program> {
    ProgramSpec spec;
    const void* owner=nullptr;
    virtual ~Program()=default;
};
struct Event {std::string name; uint64_t host_begin,host_end; double gpu_ms,gpu_begin_ms=0,gpu_end_ms=0;uint32_t lane=0;};
inline uint64_t now_ns(){return std::chrono::duration_cast<std::chrono::nanoseconds>(std::chrono::steady_clock::now().time_since_epoch()).count();}
// Explicit caller cap applies to backend-owned buffer allocations, including
// Vulkan staging/padding. Driver/context allocations are outside this metric.
inline uint64_t allocation_cap(uint64_t live_available) {
    const char* text=std::getenv("SCIENCE_BUFFER_BUDGET_BYTES");
    if(!text)return live_available;
    uint64_t value=0;
    if(!*text)throw std::runtime_error("INVALID_BUFFER_BUDGET");
    for(const char* p=text;*p;++p){
        if(*p<'0'||*p>'9'||value>(std::numeric_limits<uint64_t>::max()-(*p-'0'))/10)
            throw std::runtime_error("INVALID_BUFFER_BUDGET");
        value=value*10+(*p-'0');
    }
    if(!value)throw std::runtime_error("INVALID_BUFFER_BUDGET");
    return std::min(value,live_available);
}
struct Backend {
    std::vector<Event> events;
    uint64_t h2d=0,d2h=0,submits=0,syncs=0,allocs=0,allocated=0,peak=0,available=0;
    std::string identity;
    uint32_t lane_count=1,active_lane=0;
    int queue_family=-1;
    std::string timestamp_domain="QUEUE_LOCAL_UNCALIBRATED";
    void select_lane(uint32_t lane){if(lane>=lane_count)throw std::runtime_error("LANE_RANGE");active_lane=lane;}
    virtual ~Backend()=default;
    virtual std::shared_ptr<Buffer> allocate(size_t)=0;
    virtual std::shared_ptr<Program> load(const ProgramSpec&)=0;
    virtual void upload(Buffer&,size_t,const void*,size_t)=0;
    virtual void download(Buffer&,size_t,void*,size_t)=0;
    virtual void dispatch(Program&,const std::vector<Buffer*>&,const std::vector<uint32_t>&,
                          const std::array<uint32_t,3>&,const std::string&)=0;
    virtual void drain()=0;
    virtual void zero(Buffer&)=0;
    virtual void copy(Buffer&, Buffer&) {throw std::runtime_error("DEVICE_COPY_UNSUPPORTED");}
    virtual void reset_bindings(Program&) {}
    void bounds(Buffer& b,size_t off,size_t n) const {
        if(b.owner!=this||off>b.bytes||n>b.bytes-off)throw std::runtime_error("BUFFER_OWNER_OR_BOUNDS");
    }
    void validate(Program& p,const std::vector<Buffer*>& b,const std::vector<uint32_t>& q,
                  const std::array<uint32_t,3>& threads) const {
        if(p.owner!=this||b.size()!=p.spec.bindings||q.size()!=p.spec.words)
            throw std::runtime_error("PROGRAM_ABI_MISMATCH");
        for(auto* x:b){if(!x)throw std::runtime_error("NULL_BUFFER");bounds(*x,0,x->bytes);}
        for(auto n:threads)if(!n)throw std::runtime_error("ZERO_DISPATCH");
    }
};
std::unique_ptr<Backend> make_cuda(const std::string& pci,uint32_t lanes=1);
std::unique_ptr<Backend> make_vulkan(const std::string& pci,uint32_t lanes=1);
