"""QLab-derived GPU output transport; lossless and workload independent."""
