"""Offline tools; no GPU execution and no implicit scientific certification."""
import argparse
import json
import sys
from pathlib import Path
from .api import encode_file, check_fd


def main():
    parser=argparse.ArgumentParser(description='QLab-derived graph output compression tools')
    sub=parser.add_subparsers(dest='command', required=True)
    for name in ('encode','inspect','decode'):
        cmd=sub.add_parser(name)
        cmd.add_argument('input',type=Path)
        if name!='inspect':cmd.add_argument('output',type=Path)
        cmd.add_argument('--stride-words',type=int,default=1)
        cmd.add_argument('--transform',choices=('xor','delta'),default='xor')
        cmd.add_argument('--word-lanes',type=int,choices=(1,2),default=1)
        cmd.add_argument('--tile-words',type=int,default=1048576)
        if name!='encode':cmd.add_argument('--raw-bytes',type=int,required=True)
    cmd=sub.add_parser('enable-graph')
    cmd.add_argument('input',type=Path);cmd.add_argument('output',type=Path)
    cmd.add_argument('--tile-words',type=int,default=1048576)
    args=parser.parse_args()
    if args.command=='enable-graph':
        if args.tile_words%256 or not 256<=args.tile_words<=1048576:raise ValueError('QGC_TILE')
        graph=json.loads(args.input.read_text());base=args.input.resolve().parent
        for b in graph['buffers'].values():
            if b.get('input'):b['input']=str((base/b['input']).resolve())
        for k in graph['kernels'].values():
            for backend in ('cuda','vulkan'):
                if backend in k:k[backend]['path']=str((base/k[backend]['path']).resolve())
        graph['output_transport']=dict(compression=dict(codec='qgc1',tile_words=args.tile_words))
        with args.output.open('x') as f:json.dump(graph,f,indent=2);f.write('\n')
        print('GRAPH_WRITTEN_NOT_EXECUTED');return
    from .api import ROOT
    sys.path.insert(0, str(ROOT/'src'))
    from engine.session import guarded
    return guarded('compression_cpu', lambda fd: process_file(args), cpu_only=True)


def process_file(args):
    config=dict(codec='qgc1',stride_words=args.stride_words,transform=args.transform,tile_words=args.tile_words,word_lanes=args.word_lanes)
    if args.command=='encode':
        result=encode_file(args.input,args.output,**{k:v for k,v in config.items() if k!='codec'})
    else:
        with args.input.open('rb') as source:
            if args.command=='inspect':
                check_fd(source.fileno(),raw_bytes=args.raw_bytes,compression=config)
                result=dict(status='STRUCTURE_VALID_NOT_SCIENCE_VALIDATED',decoded_bytes=0)
            else:
                partial=args.output.with_name(args.output.name+'.partial')
                if args.output.exists():raise FileExistsError(args.output)
                created=False
                try:
                    with partial.open('xb') as target:
                        created=True
                        check_fd(source.fileno(),raw_bytes=args.raw_bytes,compression=config,decoded_fd=target.fileno())
                    partial.replace(args.output)
                except BaseException:
                    if created:partial.unlink(missing_ok=True)
                    raise
                result=dict(status='DECODED_NOT_SCIENCE_VALIDATED')
    print(json.dumps(result,indent=2))


if __name__=='__main__':main()
