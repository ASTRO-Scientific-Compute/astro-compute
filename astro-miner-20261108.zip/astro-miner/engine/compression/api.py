"""Bounded native packet I/O and exact comparison without decompression.

An encoded stream hash/grammar alone is NOT scientific validation. The exact
checker requires a caller-trusted reference manifest bound to the same inputs,
scientific programs, graph and MathSpec. Reference construction is offline.
"""
import ctypes
import hashlib
import json
import os
import time
from pathlib import Path
from engine.integrity import Integrity, require_sealed, signature

ROOT = Path(__file__).resolve().parents[2]
_LIBRARY = None


def library():
    global _LIBRARY
    if _LIBRARY is None:
        lib = ctypes.CDLL(str(ROOT/'build/libqgc1.so'))
        lib.qgc_error.restype = ctypes.c_char_p
        lib.qgc_encode_fd.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_uint32,
            ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_void_p, ctypes.c_void_p]
        lib.qgc_encode_fd.restype = ctypes.c_int
        lib.qgc_check_fd.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int,
            ctypes.c_uint64, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32, ctypes.c_uint32]
        lib.qgc_check_fd.restype = ctypes.c_int
        _LIBRARY = lib
    return _LIBRARY


def _config(stride_words, transform, tile_words, word_lanes):
    if (type(tile_words) is not int or not 256 <= tile_words <= 1048576
        or tile_words % 256 or type(stride_words) is not int
        or not 1 <= stride_words <= tile_words or transform not in ('delta','xor')
        or type(word_lanes) is not int or word_lanes not in (1,2)):
        raise ValueError('QGC_CONFIG')
    return stride_words, int(transform == 'xor'), tile_words, word_lanes


def _call(status):
    if status != 0:
        raise ValueError(library().qgc_error().decode())


def encode_file(source, destination, *, stride_words=1, transform='xor', tile_words=1048576, word_lanes=1):
    """Offline reference/storage tool; caller holds CPU admission. No science certification."""
    config = _config(stride_words, transform, tile_words, word_lanes)
    source, destination = Path(source), Path(destination)
    start, cpu = time.monotonic(), time.process_time()
    raw_sha, packet_sha = ctypes.create_string_buffer(65), ctypes.create_string_buffer(65)
    partial = destination.with_name(destination.name+'.partial')
    if destination.exists(): raise FileExistsError(destination)
    with source.open('rb') as src, partial.open('xb') as dst:
        try:
            before = signature(os.fstat(src.fileno()))
            _call(library().qgc_encode_fd(src.fileno(), dst.fileno(), *config, raw_sha, packet_sha))
            if signature(os.fstat(src.fileno())) != before or signature(source.stat()) != before:
                raise ValueError('QGC_SOURCE_CHANGED')
            size = os.fstat(dst.fileno()).st_size
        except BaseException:
            partial.unlink(missing_ok=True)
            raise
    partial.replace(destination)
    return dict(status='ENCODED_NOT_SCIENTIFICALLY_VALIDATED', raw_bytes=before[2],
        encoded_bytes=size, raw_sha256=raw_sha.value.decode(), sha256=packet_sha.value.decode(),
        compression=dict(codec='qgc1', stride_words=stride_words, transform=transform, tile_words=tile_words, word_lanes=word_lanes),
        wall_seconds=time.monotonic()-start, cpu_seconds=time.process_time()-cpu,
        memory_scope='One raw tile plus one encoded tile; no full-file decoded buffer')


def check_fd(fd, *, raw_bytes, compression, expected_fd=-1, decoded_fd=-1):
    if type(raw_bytes) is not int or raw_bytes <= 0 or raw_bytes % 4 or raw_bytes > 2**34:
        raise ValueError('QGC_RAW_SIZE')
    if compression.get('codec') != 'qgc1': raise ValueError('QGC_CODEC')
    config = _config(compression['stride_words'], compression['transform'], compression['tile_words'], compression['word_lanes'])
    _call(library().qgc_check_fd(fd, expected_fd, decoded_fd, raw_bytes, *config))


def graph_identity(graph_path, backend, mathspec_sha256, integrity):
    """Exclude transport and lane placement; bind every scientific operation.

    Program/input SHA values come from the SAME job-scoped immutable registry.
    Lane placement may differ, but node order/dependencies/arithmetic may not.
    """
    if len(mathspec_sha256) != 64 or set(mathspec_sha256)-set('0123456789abcdef'):
        raise ValueError('MATHSPEC_SHA256')
    path = Path(graph_path).resolve()
    graph = json.loads(Path(integrity.file(path).path).read_bytes())
    graph.pop('execution', None); graph.pop('output_transport', None); graph['version'] = 1
    for node in graph['nodes']: node.pop('lane', None)
    for value in graph['buffers'].values():
        if value.get('input'): value['input'] = integrity.file(path.parent/value['input']).sha256
    for value in graph['kernels'].values():
        selected = dict(value[backend]); selected['path'] = integrity.file(path.parent/selected['path']).sha256
        value.pop('cuda', None); value.pop('vulkan', None); value['selected_program'] = selected
    for value in graph['outputs'].values(): value.pop('compression', None)
    payload = dict(graph=graph, backend=backend, mathspec_sha256=mathspec_sha256)
    return hashlib.sha256(json.dumps(payload, sort_keys=True, separators=(',',':')).encode()).hexdigest()


class ExactCompressedValidator:
    """Opt-in replay checker, not an oracle for unknown or merely tolerant data.

    The adapter must supply the pinned digest of a trusted manifest with schema
    QGC_EXACT_REFERENCE_V1, identity_sha256, evidence_sha256, outputs mapping.
    Each output includes file, sha256, raw_sha256, raw_bytes and compression.
    A previous GPU output alone must never be designated a trusted reference.
    bind() runs after execution FDs are frozen; references remain host-only.
    """
    def __init__(self, manifest, trusted_manifest_sha256, graph, backend, mathspec_sha256):
        self.path = Path(manifest).resolve()
        self.trusted = trusted_manifest_sha256
        self.graph, self.backend, self.mathspec = graph, backend, mathspec_sha256
        self.snapshots = {}; self.manifest = None

    def bind(self, integrity):
        identity = graph_identity(self.graph, self.backend, self.mathspec, integrity)
        snap = integrity.file(self.path)
        if snap.sha256 != self.trusted: raise ValueError('UNTRUSTED_COMPRESSED_REFERENCE_MANIFEST')
        m = json.loads(Path(snap.path).read_bytes())
        if (m.get('schema') != 'QGC_EXACT_REFERENCE_V1' or m.get('identity_sha256') != identity
            or m.get('scientific_status') != 'INDEPENDENTLY_VALIDATED_EXACT_REFERENCE'
            or len(m.get('evidence_sha256','')) != 64
            or set(m['evidence_sha256'])-set('0123456789abcdef')):
            raise ValueError('COMPRESSED_REFERENCE_IDENTITY_OR_SCIENCE')
        evidence = integrity.file(self.path.parent/m['evidence_file'])
        if evidence.sha256 != m['evidence_sha256']: raise ValueError('REFERENCE_EVIDENCE_CHANGED')
        for name, item in m['outputs'].items():
            if len(item.get('raw_sha256','')) != 64 or set(item['raw_sha256'])-set('0123456789abcdef'):
                raise ValueError('REFERENCE_RAW_DIGEST')
            ref = integrity.file(self.path.parent/item['file'])
            if ref.sha256 != item['sha256']: raise ValueError('REFERENCE_PACKET_CHANGED')
            check_fd(ref.fd, raw_bytes=item['raw_bytes'], compression=item['compression'])
            self.snapshots[name] = ref
        self.manifest = m

    def __call__(self, directory, hashes, outputs):
        if self.manifest is None or set(outputs) != set(self.snapshots):
            raise ValueError('EXACT_REFERENCE_NOT_BOUND_OR_OUTPUT_SET')
        start, cpu = time.monotonic(), time.thread_time()
        compared = 0
        for name, output in outputs.items():
            expected = self.manifest['outputs'][name]
            if (output['compression'] is None or output['raw_bytes'] != expected['raw_bytes']
                or output['compression'] != expected['compression']):
                raise ValueError('EXACT_REFERENCE_OUTPUT_CONTRACT')
            ref = self.snapshots[name]
            with (Path(directory)/(name+'.qgc')).open('rb') as source:
                require_sealed(source.fileno(), ref.size)
                check_fd(source.fileno(), raw_bytes=output['raw_bytes'],
                         compression=output['compression'], expected_fd=ref.fd)
            compared += ref.size
        return dict(exact_reference=dict(status='PASS', proof='FULL_ENCODED_BYTE_COMPARISON_NO_DECODE',
            scientific_validation='REUSED_INDEPENDENTLY_VALIDATED_EXACT_REFERENCE',
            manifest_sha256=self.trusted, evidence_sha256=self.manifest['evidence_sha256'],
            decoded_bytes=0, compared_encoded_bytes=compared,
            wall_seconds=time.monotonic()-start, cpu_seconds=time.thread_time()-cpu,
            scope='Exact equality to a separately trusted canonical reference; not a newly calculated external numerical metric'))
