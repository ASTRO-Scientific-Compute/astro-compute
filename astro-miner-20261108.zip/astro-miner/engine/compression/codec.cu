#include <stdint.h>
using uint=uint32_t;
#define Q_SHARED __shared__
#define Q_LANE threadIdx.x
#define Q_GROUP blockIdx.x
#define Q_BARRIER __syncthreads()
#define Q_POP(v) uint(__popc(v))
#define Q_MIN(a,b) min(a,b)
#define Q_ENTRY extern "C" __global__ void qgc_encode(const uint* src,uint* tmp,uint* meta,uint* dst,uint n,uint stride,uint phase,uint source_offset,uint offset_lo,uint offset_hi,uint total_lo,uint total_hi,uint transform,uint tile_words,uint word_lanes)
#include "codec.inc"
