#pragma once
#include <algorithm>
#include <cstdint>
#include <cstring>
#include <stdexcept>
#include <vector>
namespace qgc {
constexpr uint32_t magic=0x51474331, max_tile=1048576, header=16;
inline void need(bool ok,const char* why){if(!ok)throw std::runtime_error(why);}
inline uint32_t pop(uint32_t x){return __builtin_popcount(x);}
inline void config(uint64_t total,uint64_t off,uint32_t n,uint32_t stride,uint32_t transform,uint32_t tile,uint32_t word_lanes){
    need(tile>=256&&tile<=max_tile&&tile%256==0,"QGC_TILE");
    need(total&&total<=(1ull<<32)&&off<total&&off%tile==0&&n==std::min(uint64_t(tile),total-off),"QGC_FRAME");
    need(stride&&stride<=tile&&transform<=1&&(word_lanes==1||word_lanes==2),"QGC_TRANSFORM");
}
inline std::vector<uint32_t> encode(const uint32_t* x,uint64_t total,uint64_t off,uint32_t n,uint32_t stride,uint32_t transform,uint32_t tile,uint32_t word_lanes){
    config(total,off,n,stride,transform,tile,word_lanes);uint32_t bs=(n+255)/256;
    std::vector<uint32_t> out(header+2*bs,0);
    out[0]=magic;out[1]=1;out[2]=n;out[3]=stride;out[4]=1;out[6]=256;out[7]=bs;
    out[8]=uint32_t(off);out[9]=uint32_t(off>>32);out[10]=uint32_t(total);out[11]=uint32_t(total>>32);out[12]=transform;out[13]=tile;out[14]=word_lanes;
    for(uint32_t b=0;b<bs;b++){
        uint32_t count=std::min(256u,n-b*256),r[256]{},mask=0;
        for(uint32_t j=0;j<count;j++){auto i=b*256+j,p=i>=stride?x[i-stride]:0,d=x[i]-p;auto at=word_lanes==2?j/2+(j%2)*((count+1)/2):j;r[at]=transform?(x[i]^p):((d<<1)^(0u-(d>>31)));mask|=r[at];}
        std::vector<uint32_t> packed(1,mask);
        for(uint32_t bit=0;bit<32;bit++)if((mask>>bit)&1){
            uint32_t chunks[8]{},groups=0;
            for(uint32_t g=0;g<8;g++){for(uint32_t j=0;j<32;j++)chunks[g]|=((r[32*g+j]>>bit)&1)<<j;if(chunks[g])groups|=1u<<g;}
            packed.push_back(groups);for(auto w:chunks)if(w)packed.push_back(w);
        }
        out[header+2*b+1]=out.size();
        if(packed.size()>=count){out[header+2*b]=0x80000000u|count;out.insert(out.end(),r,r+count);}
        else{out[header+2*b]=packed.size();out.insert(out.end(),packed.begin(),packed.end());}
        // Once the table plus emitted payload exceeds RAW, no later block can
        // make the packet smaller. Avoid wasted offline reference encoding.
        if(out.size()>=header+n){out.resize(header+n);out[4]=0;std::copy_n(x,n,out.begin()+header);break;}
    }
    out[5]=out.size();return out;
}
inline uint32_t check_header(const uint32_t* p,uint64_t total,uint64_t off,uint32_t n,uint32_t stride,uint32_t transform,uint32_t tile,uint32_t word_lanes){
    config(total,off,n,stride,transform,tile,word_lanes);
    need(p[0]==magic&&p[1]==1&&p[2]==n&&p[3]==stride&&p[4]<=1&&p[5]>=header&&p[5]<=header+n&&p[6]==256&&p[7]==(n+255)/256&&p[8]==uint32_t(off)&&p[9]==uint32_t(off>>32)&&p[10]==uint32_t(total)&&p[11]==uint32_t(total>>32)&&p[12]==transform&&p[13]==tile&&p[14]==word_lanes&&!p[15],"QGC_HEADER");
    if(!p[4])need(p[5]==header+n,"QGC_RAW_LENGTH");
    else need(p[5]>=header+2*p[7]&&p[5]<header+n,"QGC_PACKED_LENGTH");
    return p[5];
}
// Validate packet structure and optional decode. nullptr means NO inverse and
// no allocation proportional to decoded size. This is not a science oracle.
inline void packet(const uint32_t* p,uint32_t words,uint32_t* decoded=nullptr){
    uint32_t n=p[2],bs=p[7];need(words==p[5],"QGC_PACKET_LENGTH");
    if(!p[4]){if(decoded)std::copy_n(p+header,n,decoded);return;}
    uint32_t end=header+2*bs;
    for(uint32_t b=0;b<bs;b++){
        uint32_t tag=p[header+2*b],sz=tag&0x7fffffffu,off=p[header+2*b+1],count=std::min(256u,n-b*256);
        need(off==end&&sz&&sz<=count&&uint64_t(off)+sz<=words,"QGC_BLOCK_BOUNDS");
        if(tag>>31){need(sz==count,"QGC_RAW_BLOCK");if(decoded)std::copy_n(p+off,count,decoded+b*256);off+=sz;}
        else {
            need(sz<count,"QGC_PACKED_BLOCK");if(decoded)std::fill_n(decoded+b*256,count,0);
            auto planes=p[off++];
            for(uint32_t bit=0;bit<32;bit++)if((planes>>bit)&1){
                need(off<end+sz,"QGC_PLANES");auto mask=p[off++];need(mask&&mask<=255,"QGC_MASK");
                for(uint32_t g=0;g<8;g++)if((mask>>g)&1){
                    need(off<end+sz,"QGC_CHUNK_BOUNDS");auto w=p[off++];need(w!=0,"QGC_ZERO_CHUNK");
                    uint32_t valid=count>32*g?std::min(32u,count-32*g):0;
                    need(valid==32||(valid?w>>valid==0:w==0),"QGC_TAIL_PADDING");
                    if(decoded)for(uint32_t j=0;j<valid;j++)decoded[b*256+32*g+j]|=((w>>j)&1)<<bit;
                }
            }
        }
        need(off==end+sz,"QGC_TRAILING_BLOCK");end+=sz;
        if(decoded&&p[14]==2){uint32_t ordered[256];std::copy_n(decoded+b*256,count,ordered);for(uint32_t j=0;j<count;j++)decoded[b*256+j]=ordered[j/2+(j%2)*((count+1)/2)];}
    }
    need(end==words,"QGC_TRAILING_PACKET");
    if(decoded)for(uint32_t i=0;i<n;i++){auto z=decoded[i],prev=i>=p[3]?decoded[i-p[3]]:0;decoded[i]=p[12]?(z^prev):(((z>>1)^(0u-(z&1)))+prev);}
}
}
