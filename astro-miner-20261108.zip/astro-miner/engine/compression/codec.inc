// QGC1: adapted from QLab v02 QBC2; provenance in research/graph_compression_v1.
// Integer-only, bit-preserving. Each dispatch uses one uniform phase.
// Q_* macros are supplied by the CUDA/GLSL wrapper.
Q_SHARED uint residual[256];
Q_SHARED uint planes[256];
Q_SHARED uint plane_mask, size_words, offsets[32], masks[32];
Q_ENTRY {
    uint lane=Q_LANE, b=Q_GROUP, bs=(n+255u)/256u;
    if (phase==0u) {
        uint count=Q_MIN(256u,n-b*256u);
        for(uint j=lane;j<256u;j+=64u) {
            uint i=b*256u+j, z=0u;
            if(i<n) {
                uint x=src[source_offset+i];
                uint p=i>=stride?src[source_offset+i-stride]:0u;
                uint d=x-p;
                z=transform==1u?(x^p):((d<<1u)^(0u-(d>>31u)));
            }
            uint at=word_lanes==2u&&j<count?j/2u+(j%2u)*((count+1u)/2u):j;
            residual[at]=z;
        }
        Q_BARRIER;
        if(lane==0u){uint v=0u;for(uint j=0u;j<256u;j++)v|=residual[j];plane_mask=v;}
        Q_BARRIER;
        for(uint k=lane;k<256u;k+=64u){
            uint bit=k/8u,g=k%8u,w=0u;
            if(((plane_mask>>bit)&1u)!=0u)
                for(uint j=0u;j<32u;j++)w|=((residual[g*32u+j]>>bit)&1u)<<j;
            planes[k]=w;
        }
        Q_BARRIER;
        if(lane==0u){
            uint total=1u;
            for(uint bit=0u;bit<32u;bit++){
                uint m=0u;for(uint g=0u;g<8u;g++)if(planes[bit*8u+g]!=0u)m|=1u<<g;
                masks[bit]=m;offsets[bit]=total;if(m!=0u)total+=1u+Q_POP(m);
            }
            size_words=total;meta[2u*b]=total>=count?(0x80000000u|count):total;
            tmp[b*256u]=plane_mask;
        }
        Q_BARRIER;
        if(size_words>=count){for(uint j=lane;j<count;j+=64u)tmp[b*256u+j]=residual[j];}
        else {
            for(uint bit=lane;bit<32u;bit+=64u)if(masks[bit]!=0u)tmp[b*256u+offsets[bit]]=masks[bit];
            for(uint k=lane;k<256u;k+=64u){uint bit=k/8u,g=k%8u;
                if(planes[k]!=0u)tmp[b*256u+offsets[bit]+1u+Q_POP(masks[bit]&((1u<<g)-1u))]=planes[k];}
        }
    } else if(phase==1u) {
        if(b!=0u||lane!=0u)return;
        uint total=16u+2u*bs;
        for(uint j=0u;j<bs;j++){meta[2u*j+1u]=total;total+=meta[2u*j]&0x7fffffffu;}
        uint mode=1u;if(total>=n+16u){mode=0u;total=n+16u;}
        dst[0]=0x51474331u;dst[1]=1u;dst[2]=n;dst[3]=stride;dst[4]=mode;dst[5]=total;
        dst[6]=256u;dst[7]=bs;dst[8]=offset_lo;dst[9]=offset_hi;
        dst[10]=total_lo;dst[11]=total_hi;dst[12]=transform;dst[13]=tile_words;dst[14]=word_lanes;dst[15]=0u;
    } else {
        if(dst[4]==0u){for(uint j=lane;j<256u;j+=64u){uint i=b*256u+j;if(i<n)dst[16u+i]=src[source_offset+i];}}
        else {
            uint tag=meta[2u*b],off=meta[2u*b+1u];
            if(lane==0u){dst[16u+2u*b]=tag;dst[17u+2u*b]=off;}
            for(uint j=lane;j<(tag&0x7fffffffu);j+=64u)dst[off+j]=tmp[b*256u+j];
        }
    }
}
