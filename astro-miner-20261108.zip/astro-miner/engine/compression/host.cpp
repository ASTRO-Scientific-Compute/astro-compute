#include "codec.hpp"
#include <array>
#include <cerrno>
#include <fcntl.h>
#include <memory>
#include <sys/mman.h>
#include <sys/stat.h>
#include <unistd.h>
#include <openssl/evp.h>
namespace {
thread_local std::string error;
struct Map {
    void* data=MAP_FAILED;size_t size=0;
    explicit Map(int fd){struct stat st{};qgc::need(fstat(fd,&st)==0&&S_ISREG(st.st_mode)&&st.st_size>0,"QGC_MAP_SIZE");size=st.st_size;data=mmap(nullptr,size,PROT_READ,MAP_PRIVATE,fd,0);qgc::need(data!=MAP_FAILED,"QGC_MMAP");}
    ~Map(){if(data!=MAP_FAILED)munmap(data,size);}
};
struct Digest {
    std::unique_ptr<EVP_MD_CTX,decltype(&EVP_MD_CTX_free)> ctx{EVP_MD_CTX_new(),EVP_MD_CTX_free};
    Digest(){qgc::need(ctx&&EVP_DigestInit_ex(ctx.get(),EVP_sha256(),nullptr)==1,"QGC_SHA_INIT");}
    void add(const void* p,size_t n){qgc::need(EVP_DigestUpdate(ctx.get(),p,n)==1,"QGC_SHA_UPDATE");}
    void finish(char* out){unsigned char bytes[32];unsigned n=0;qgc::need(EVP_DigestFinal_ex(ctx.get(),bytes,&n)==1&&n==32,"QGC_SHA_FINAL");const char* hex="0123456789abcdef";for(unsigned j=0;j<32;j++){out[j*2]=hex[bytes[j]>>4];out[j*2+1]=hex[bytes[j]&15];}out[64]=0;}
};
void write_all(int fd,const void* data,size_t n){auto p=static_cast<const char*>(data);while(n){auto k=write(fd,p,n);if(k<0&&errno==EINTR)continue;qgc::need(k>0,"QGC_WRITE");p+=k;n-=k;}}
void read_at(int fd,void* data,size_t n,uint64_t off){auto p=static_cast<char*>(data);while(n){auto k=pread(fd,p,n,off);if(k<0&&errno==EINTR)continue;qgc::need(k>0,"QGC_READ");p+=k;n-=k;off+=k;}}
}
extern "C" const char* qgc_error(){return error.c_str();}
extern "C" int qgc_encode_fd(int source,int output,uint32_t stride,uint32_t transform,uint32_t tile,uint32_t word_lanes,char* raw_sha,char* packet_sha){
    try{
        struct stat st{};qgc::need(fstat(source,&st)==0&&st.st_size>0&&st.st_size%4==0,"QGC_RAW_SIZE");
        uint64_t total=st.st_size/4;qgc::config(total,0,std::min(uint64_t(tile),total),stride,transform,tile,word_lanes);
        std::vector<uint32_t> buffer(std::min(uint64_t(tile),total));Digest raw,packed;
        for(uint64_t off=0;off<total;off+=tile){
            uint32_t n=std::min(uint64_t(tile),total-off);read_at(source,buffer.data(),4ull*n,off*4);raw.add(buffer.data(),4ull*n);
            auto packet=qgc::encode(buffer.data(),total,off,n,stride,transform,tile,word_lanes);
            packed.add(packet.data(),packet.size()*4);write_all(output,packet.data(),packet.size()*4);
        }
        raw.finish(raw_sha);packed.finish(packet_sha);error.clear();return 0;
    }catch(const std::exception& e){error=e.what();return -1;}
}
// expected >= 0 compares EVERY encoded byte with a separately trusted canonical
// stream. Structure-only mode returns success of structure, never science PASS.
// decoded >= 0 is explicitly offline export, never called by online validation.
extern "C" int qgc_check_fd(int source,int expected,int decoded,uint64_t raw_bytes,uint32_t stride,uint32_t transform,uint32_t tile,uint32_t word_lanes){
    try{
        qgc::need(raw_bytes&&raw_bytes%4==0,"QGC_RAW_SIZE");uint64_t total=raw_bytes/4;
        qgc::config(total,0,std::min(uint64_t(tile),total),stride,transform,tile,word_lanes);
        Map m(source);qgc::need(m.size%4==0,"QGC_ALIGNMENT");
        // The reference was structurally validated once when sealed/bound by
        // the caller. Exact byte equality carries that property to this output.
        // Avoid repeating its bitplane walk for every completed GPU job.
        if(expected>=0){
            qgc::need(decoded<0,"QGC_EXACT_CHECK_MUST_NOT_DECODE");Map ref(expected);
            qgc::need(ref.size==m.size,"QGC_EXACT_SIZE_MISMATCH");
            qgc::need(std::memcmp(m.data,ref.data,m.size)==0,"QGC_EXACT_BYTES_MISMATCH");
            error.clear();return 0;
        }
        std::vector<uint32_t> decoded_frame;if(decoded>=0)decoded_frame.resize(std::min(uint64_t(tile),total));
        auto p=static_cast<const uint32_t*>(m.data);uint64_t pos=0;
        for(uint64_t off=0;off<total;off+=tile){
            qgc::need(pos+16<=m.size/4,"QGC_TRUNCATED_HEADER");auto n=uint32_t(std::min(uint64_t(tile),total-off));
            auto words=qgc::check_header(p+pos,total,off,n,stride,transform,tile,word_lanes);
            qgc::need(words<=m.size/4-pos,"QGC_TRUNCATED_PAYLOAD");
            qgc::packet(p+pos,words,decoded>=0?decoded_frame.data():nullptr);
            if(decoded>=0)write_all(decoded,decoded_frame.data(),n*4ull);
            pos+=words;
        }
        qgc::need(pos==m.size/4,"QGC_TRAILING_STREAM");error.clear();return 0;
    }catch(const std::exception& e){error=e.what();return -1;}
}
