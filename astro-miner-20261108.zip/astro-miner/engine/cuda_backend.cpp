#include "backend.hpp"
#include <cuda.h>
#include <sstream>
#include <cstdio>

static void ck(CUresult r){if(r!=CUDA_SUCCESS){const char* s=nullptr;cuGetErrorString(r,&s);throw std::runtime_error(s?s:"CUDA_ERROR");}}
struct Context {
    CUcontext context{};
    ~Context(){if(context)cuCtxDestroy(context);}
};
struct CB : Buffer {
    std::shared_ptr<Context> context;
    CUdeviceptr ptr{};
    ~CB(){if(ptr)cuMemFree(ptr);}
};
struct CP : Program {
    std::shared_ptr<Context> context;
    CUmodule module{};
    CUfunction function{};
    ~CP(){if(module)cuModuleUnload(module);}
};
struct CUDA : Backend {
    std::shared_ptr<Context> context=std::make_shared<Context>();
    CUdevice device{}; std::vector<CUstream> streams; CUevent origin{};
    CUstream stream(){return streams.at(active_lane);}
    uint64_t next_id=0;
    std::array<int,3> max_local{}, max_grid{}; int max_threads=0;
    struct Pending {CUevent a{},b{};uint64_t host;std::string name;uint32_t lane;};
    std::vector<Pending> pending;
    std::vector<std::pair<CUevent,CUevent>> event_pool;
    std::vector<std::shared_ptr<Buffer>> live_buffers;
    std::vector<std::weak_ptr<CB>> allocations;
    std::vector<std::shared_ptr<Program>> live_programs;
    explicit CUDA(const std::string& pci,uint32_t lanes){
        if(!lanes||lanes>8)throw std::runtime_error("LANE_RANGE");lane_count=lanes;
        ck(cuInit(0));ck(cuDeviceGetByPCIBusId(&device,pci.c_str()));
        ck(cuCtxCreate(&context->context,CU_CTX_SCHED_BLOCKING_SYNC,device));
        size_t free,total;ck(cuMemGetInfo(&free,&total));available=free>512ull*1024*1024?free-512ull*1024*1024:0;
        available=allocation_cap(available);
        char name[256]{};CUuuid uuid{};ck(cuDeviceGetName(name,256,device));ck(cuDeviceGetUuid(&uuid,device));
        std::ostringstream o;o<<name<<" pci="<<pci<<" uuid=";for(auto b:uuid.bytes){char z[3];snprintf(z,3,"%02x",(unsigned char)b);o<<z;}identity=o.str();
        const CUdevice_attribute local[]={CU_DEVICE_ATTRIBUTE_MAX_BLOCK_DIM_X,CU_DEVICE_ATTRIBUTE_MAX_BLOCK_DIM_Y,CU_DEVICE_ATTRIBUTE_MAX_BLOCK_DIM_Z};
        const CUdevice_attribute grid[]={CU_DEVICE_ATTRIBUTE_MAX_GRID_DIM_X,CU_DEVICE_ATTRIBUTE_MAX_GRID_DIM_Y,CU_DEVICE_ATTRIBUTE_MAX_GRID_DIM_Z};
        for(int i=0;i<3;i++){ck(cuDeviceGetAttribute(&max_local[i],local[i],device));ck(cuDeviceGetAttribute(&max_grid[i],grid[i],device));}
        ck(cuDeviceGetAttribute(&max_threads,CU_DEVICE_ATTRIBUTE_MAX_THREADS_PER_BLOCK,device));
        int concurrent=0;ck(cuDeviceGetAttribute(&concurrent,CU_DEVICE_ATTRIBUTE_CONCURRENT_KERNELS,device));
        if(lanes>1&&!concurrent)throw std::runtime_error("CONCURRENT_KERNELS_UNAVAILABLE");
        streams.resize(lanes);for(auto& s:streams)ck(cuStreamCreate(&s,CU_STREAM_NON_BLOCKING));
        ck(cuEventCreate(&origin,CU_EVENT_DEFAULT));ck(cuEventRecord(origin,streams[0]));
        for(size_t i=1;i<streams.size();i++)ck(cuStreamWaitEvent(streams[i],origin,0));
        timestamp_domain="CUDA_CONTEXT_COMMON_EVENT_ORIGIN";
    }
    ~CUDA(){try{drain();}catch(...){}for(auto p:event_pool){cuEventDestroy(p.first);cuEventDestroy(p.second);}for(auto p:pending){cuEventDestroy(p.a);cuEventDestroy(p.b);}cuEventDestroy(origin);for(auto s:streams)cuStreamDestroy(s);}
    std::shared_ptr<Buffer> allocate(size_t n) override {
        allocated=0;for(auto it=allocations.begin();it!=allocations.end();){if(auto b=it->lock()){allocated+=b->bytes;++it;}else it=allocations.erase(it);}
        if(!n||n>available||allocated>available-n)throw std::runtime_error("GPU_MEMORY_BUDGET_EXCEEDED");
        auto b=std::make_shared<CB>();b->context=context;b->owner=this;b->id=++next_id;b->bytes=n;ck(cuMemAlloc(&b->ptr,n));
        allocated+=n;peak=std::max(peak,allocated);allocs++;allocations.push_back(b);return b;
    }
    std::shared_ptr<Program> load(const ProgramSpec& spec) override {
        uint64_t total=1;for(int i=0;i<3;i++){if(!spec.local[i]||spec.local[i]>uint32_t(max_local[i]))throw std::runtime_error("WORKGROUP_LIMIT");total*=spec.local[i];}
        if(total>uint32_t(max_threads)||spec.words>32||!spec.bindings||spec.bindings>32)throw std::runtime_error("PROGRAM_LIMIT");
        auto p=std::make_shared<CP>();p->context=context;p->owner=this;p->spec=spec;
        ck(cuModuleLoad(&p->module,spec.path.c_str()));ck(cuModuleGetFunction(&p->function,p->module,spec.entry.c_str()));
        int limit;ck(cuFuncGetAttribute(&limit,CU_FUNC_ATTRIBUTE_MAX_THREADS_PER_BLOCK,p->function));if(total>uint32_t(limit))throw std::runtime_error("KERNEL_WORKGROUP_LIMIT");return p;
    }
    void upload(Buffer& b,size_t off,const void* p,size_t n) override {bounds(b,off,n);if(!n)return;live_buffers.push_back(b.shared_from_this());ck(cuMemcpyHtoDAsync(static_cast<CB&>(b).ptr+off,p,n,stream()));h2d+=n;drain();}
    void download(Buffer& b,size_t off,void* p,size_t n) override {bounds(b,off,n);if(!n)return;live_buffers.push_back(b.shared_from_this());ck(cuMemcpyDtoHAsync(p,static_cast<CB&>(b).ptr+off,n,stream()));d2h+=n;drain();}
    void copy(Buffer& source, Buffer& dest) override {
        bounds(source,0,source.bytes);bounds(dest,0,source.bytes);
        live_buffers.push_back(source.shared_from_this());live_buffers.push_back(dest.shared_from_this());
        ck(cuMemcpyDtoDAsync(static_cast<CB&>(dest).ptr,static_cast<CB&>(source).ptr,source.bytes,stream()));
    }
    void zero(Buffer& b) override {bounds(b,0,b.bytes);live_buffers.push_back(b.shared_from_this());ck(cuMemsetD8Async(static_cast<CB&>(b).ptr,0,b.bytes,stream()));}
    void dispatch(Program& base,const std::vector<Buffer*>& buffers,const std::vector<uint32_t>& q,
                  const std::array<uint32_t,3>& threads,const std::string& name) override {
        validate(base,buffers,q,threads);auto& p=static_cast<CP&>(base);
        uint32_t groups[3];for(int i=0;i<3;i++){groups[i]=(uint64_t(threads[i])+p.spec.local[i]-1)/p.spec.local[i];if(groups[i]>uint32_t(max_grid[i]))throw std::runtime_error("GRID_LIMIT");}
        // load/validate bound the ABI to 32 buffers and 32 scalar words.
        // Stack storage avoids per-dispatch argument-vector allocations.
        std::array<CUdeviceptr,32> pointers;
        std::array<void*,64> args;
        for(size_t i=0;i<buffers.size();i++){auto* b=buffers[i];pointers[i]=static_cast<CB*>(b)->ptr;args[i]=&pointers[i];live_buffers.push_back(b->shared_from_this());}
        for(size_t i=0;i<q.size();i++)args[buffers.size()+i]=const_cast<uint32_t*>(&q[i]);
        Pending e{};e.name=name;e.host=now_ns();e.lane=active_lane;
        if(event_pool.empty()){ck(cuEventCreate(&e.a,CU_EVENT_DEFAULT));ck(cuEventCreate(&e.b,CU_EVENT_DEFAULT));}
        else {auto pair=event_pool.back();event_pool.pop_back();e.a=pair.first;e.b=pair.second;}
        pending.push_back(e);live_programs.push_back(base.shared_from_this());
        ck(cuEventRecord(e.a,stream()));ck(cuLaunchKernel(p.function,groups[0],groups[1],groups[2],p.spec.local[0],p.spec.local[1],p.spec.local[2],0,stream(),args.data(),nullptr));ck(cuEventRecord(e.b,stream()));submits++;
        if(pending.size()>=2048)drain();
    }
    void drain() override {
        if(pending.empty()&&live_buffers.empty())return;
        for(auto s:streams){ck(cuStreamSynchronize(s));syncs++;}auto end=now_ns();
        for(auto& p:pending){float ms,a,b;ck(cuEventElapsedTime(&ms,p.a,p.b));ck(cuEventElapsedTime(&a,origin,p.a));ck(cuEventElapsedTime(&b,origin,p.b));events.push_back({p.name,p.host,end,ms,a,b,p.lane});event_pool.emplace_back(p.a,p.b);}
        pending.clear();live_programs.clear();live_buffers.clear();
    }
};
std::unique_ptr<Backend> make_cuda(const std::string& pci,uint32_t lanes){return std::make_unique<CUDA>(pci,lanes);}
