"""Versioned, workload-neutral DAG compiler. Only standard Python is required.

Graph order follows explicit `after` edges. Unordered accesses to the same
buffer are rejected whenever either node writes. Iterations repeat the whole
ordered DAG on resident buffers; execution is bounded and single-device.
"""
import hashlib
import json
import math
import re
import stat
import struct
from pathlib import Path


def integer(value, low, high):
    if type(value) is not int or not low <= value <= high:
        raise ValueError(f'INTEGER_RANGE:{value}:{low}:{high}')
    return value


def compile_graph(path, backend, destination, *, integrity=None, output_compression=None):
    path = Path(path).resolve()
    graph = json.loads(Path(integrity.file(path).path).read_bytes() if integrity else path.read_bytes())
    transport = graph.get('output_transport', {})
    if not isinstance(transport, dict) or set(transport)-{'compression'}:
        raise ValueError('OUTPUT_TRANSPORT_CONTRACT')
    policy = output_compression if output_compression is not None else transport.get('compression')
    if policy is not None:
        if policy == 'raw':
            for output in graph['outputs'].values(): output.pop('compression', None)
        else:
            if policy == 'qgc1': policy = {'codec':'qgc1'}
            if not isinstance(policy, dict) or policy.get('codec') != 'qgc1':
                raise ValueError('OUTPUT_COMPRESSION_POLICY')
            for output in graph['outputs'].values(): output.setdefault('compression', dict(policy))
        graph['output_transport'] = {'compression':policy}
    if graph.get('version') not in (1, 2):
        raise ValueError('GRAPH_VERSION')
    execution = graph.get('execution', {})
    mode = execution.get('mode', 'serial')
    lanes = integer(execution.get('lanes', 1), 1, 8)
    if mode not in ('serial', 'concurrent') or (graph['version'] == 1 and execution):
        raise ValueError('EXECUTION_CONTRACT')
    if mode == 'concurrent' and lanes < 2:
        raise ValueError('CONCURRENT_LANES_REQUIRED')
    buffers, kernels, nodes = graph['buffers'], graph['kernels'], graph['nodes']
    compressed = any('compression' in o for o in graph['outputs'].values())
    if compressed:
        if '__qgc1_transport' in kernels: raise ValueError('RESERVED_CODEC_PROGRAM')
        root = Path(__file__).resolve().parents[1]
        kernels['__qgc1_transport'] = dict(bindings=4, words=11, local_size=[64,1,1],
            cuda=dict(path=str(root/'build/qgc1.ptx'), entry='qgc_encode'),
            vulkan=dict(path=str(root/'build/qgc1.spv'), entry='main'))
    if not 1 <= len(buffers) <= 1024 or not 1 <= len(kernels) <= 256 or not 1 <= len(nodes) <= 10000:
        raise ValueError('GRAPH_SIZE')
    repetitions = integer(graph.get('iterations', 1), 1, 100000)
    if repetitions * len(nodes) > 100000:
        raise ValueError('DISPATCH_BOUND')
    formats = {'f32': 4, 'f64': 8, 'i32': 4, 'u32': 4}
    sizes = {}
    files = {str(path)}
    buffer_indices = {name: i for i, name in enumerate(buffers)}
    kernel_indices = {name: i for i, name in enumerate(kernels)}
    written_buffers = {b['buffer'] for n in nodes for b in n['bind'] if b['access'] != 'read'}
    resolved = {}
    resolved_sizes = {}

    def resolve(value):
        if value in resolved:
            return resolved[value]
        file = (path.parent / value).resolve()
        try:
            info = file.stat()
        except (FileNotFoundError, NotADirectoryError):
            raise ValueError('FILE_MISSING:' + str(file))
        if not stat.S_ISREG(info.st_mode): raise ValueError('FILE_MISSING:' + str(file))
        files.add(str(file))
        resolved[value] = str(file)
        resolved_sizes[str(file)] = info.st_size
        return resolved[value]

    data = bytearray(b'SCEPLAN4' if compressed else (b'SCEPLAN3' if integrity else (b'SCEPLAN2' if graph['version'] == 2 else b'SCEPLAN1')))
    def u32(v): data.extend(struct.pack('<I', v))
    def u64(v): data.extend(struct.pack('<Q', v))
    def string(v):
        raw = v.encode()
        if len(raw) > 16384 or b'\0' in raw: raise ValueError('STRING_CONTRACT')
        u32(len(raw)); data.extend(raw)

    if compressed: u32(int(bool(integrity)))
    u32(repetitions)
    if compressed or integrity or graph['version'] == 2:
        u32(lanes); u32(int(mode == 'concurrent'))
    u32(len(buffers))
    for name, b in buffers.items():
        if b['dtype'] not in formats or not 1 <= len(b['shape']) <= 8: raise ValueError('BUFFER_TYPE')
        size = formats[b['dtype']] * math.prod(integer(n, 1, 2**32-1) for n in b['shape'])
        if size > 2**34: raise ValueError('BUFFER_SIZE')
        sizes[name] = size
        source = resolve(b['input']) if b.get('input') else ''
        if source and resolved_sizes[source] != size: raise ValueError('INPUT_SIZE:' + name)
        snapshot = integrity.file(source) if integrity and source else None
        string(name); u64(size); string(snapshot.path if snapshot else source)
        if integrity:
            string(snapshot.sha256 if snapshot else '')
            readonly = bool(source) and name not in written_buffers
            u32(int(readonly))
    u32(len(kernels))
    for name, k in kernels.items():
        program = k[backend]
        source = resolve(program['path'])
        snapshot = integrity.file(source) if integrity else None
        string(snapshot.path if snapshot else source)
        if integrity: string(snapshot.sha256)
        string(program.get('entry', 'main'))
        u32(integer(k['bindings'], 1, 32)); u32(integer(k['words'], 0, 32))
        if set(k.get('requires', [])) - {'float64'}: raise ValueError('UNKNOWN_CAPABILITY')
        u32(int('float64' in k.get('requires', [])))
        local = k.get('local_size', [64, 1, 1])
        if len(local) != 3: raise ValueError('LOCAL_DIMENSION')
        for n in local: u32(integer(n, 1, 1024))
    by_id = {node['id']: node for node in nodes}
    if len(by_id) != len(nodes): raise ValueError('DUPLICATE_NODE')
    node_lanes = {n['id']: integer(n.get('lane', 0), 0, lanes-1) for n in nodes}
    if graph['version'] == 1 and any('lane' in n for n in nodes):
        raise ValueError('LANES_REQUIRE_GRAPH_V2')
    for node in nodes:
        for dep in node.get('after', []):
            if dep in node_lanes and node_lanes[dep] != node_lanes[node['id']]:
                raise ValueError('CROSS_LANE_DEPENDENCY_NOT_SUPPORTED')
    # First concurrency contract: completely disjoint buffers between lanes.
    # Shared reads and cross-lane dependencies require a future explicit ABI.
    buffer_lane = {}
    for node in nodes:
        lane = node_lanes[node['id']]
        for binding in node['bind']:
            buf = binding['buffer']
            if buf in buffer_lane and buffer_lane[buf] != lane:
                raise ValueError('CROSS_LANE_BUFFER_NOT_SUPPORTED:' + buf)
            buffer_lane[buf] = lane
    # Preserve the original ready-wave order exactly, using dependency counts
    # instead of repeatedly rescanning/removing the full remaining node list.
    node_indices = {name: i for i, name in enumerate(by_id)}
    if len(nodes) == 1:
        if nodes[0].get('after'): raise ValueError('CYCLE_OR_MISSING_DEPENDENCY')
        ancestors, ordered = {nodes[0]['id']: 0}, nodes
    else:
        dependencies = {name: set(node.get('after', [])) for name, node in by_id.items()}
        dependents = {name: [] for name in by_id}
        counts = {}
        for name, deps in dependencies.items():
            counts[name] = len(deps)
            for dep in deps:
                if dep not in by_id: raise ValueError('CYCLE_OR_MISSING_DEPENDENCY')
                dependents[dep].append(name)
        ancestors, ordered = {}, []
        ready = [name for name in by_id if not counts[name]]
        while ready:
            following = []
            for name in ready:
                mask = 0
                for dep in dependencies[name]:
                    mask |= ancestors[dep] | (1 << node_indices[dep])
                ancestors[name] = mask
                ordered.append(by_id[name])
                for child in dependents[name]:
                    counts[child] -= 1
                    if not counts[child]: following.append(child)
            ready = sorted(following, key=node_indices.__getitem__)
    if len(ordered) != len(nodes): raise ValueError('CYCLE_OR_MISSING_DEPENDENCY')
    # Graph nodes may be reordered by future schedulers only when access allows.
    last_writer, readers = {}, {name: 0 for name in buffers}
    u32(len(ordered))
    for node in ordered:
        name = node['id']; k = kernels[node['kernel']]
        bound, words, threads = node['bind'], node.get('push', []), node['global_size']
        if len(bound) != k['bindings'] or len(words) != k['words'] or len(threads) != 3:
            raise ValueError('KERNEL_ABI:' + name)
        access = {}
        for binding in bound:
            buf, access_mode = binding['buffer'], binding['access']
            if buf not in buffers or access_mode not in ('read', 'write', 'read_write'): raise ValueError('BUFFER_ACCESS')
            access.setdefault(buf, set()).add(access_mode)
        for buf, modes in access.items():
            writes = bool(modes & {'write', 'read_write'})
            required = last_writer.get(buf, 0) | (readers[buf] if writes else 0)
            if (required & ancestors[name]) != required: raise ValueError('UNORDERED_BUFFER_HAZARD:' + name + ':' + buf)
            if writes: last_writer[buf] = 1 << node_indices[name]; readers[buf] = 0
            else: readers[buf] |= 1 << node_indices[name]
        string(name); u32(kernel_indices[node['kernel']]); u32(len(bound))
        for binding in bound: u32(buffer_indices[binding['buffer']])
        u32(len(words))
        for word in words: u32(integer(word, 0, 2**32-1))
        for n in threads: u32(integer(n, 1, 2**32-1))
        if compressed or integrity or graph['version'] == 2: u32(node_lanes[name])
    outputs = graph['outputs']
    if not 1 <= len(outputs) <= 1024: raise ValueError('OUTPUT_COUNT')
    u32(len(outputs))
    output_contracts, transport_nodes = {}, []
    for name, output in outputs.items():
        if not re.fullmatch(r'[A-Za-z0-9_-]+', name): raise ValueError('OUTPUT_NAME')
        buf = output['buffer']; offset = integer(output.get('offset', 0), 0, sizes[buf])
        size = integer(output.get('bytes', sizes[buf]-offset), 1, sizes[buf]-offset)
        if offset % 4 or size % 4: raise ValueError('OUTPUT_ALIGNMENT')
        string(name); u32(buffer_indices[buf]); u64(offset); u64(size)
        config = output.get('compression')
        cap = size
        if config is not None:
            if not isinstance(config, dict) or config.get('codec') != 'qgc1': raise ValueError('OUTPUT_CODEC')
            if set(config) - {'codec','tile_words','stride_words','transform','word_lanes'}: raise ValueError('OUTPUT_CODEC_OPTIONS')
            tile = integer(config.get('tile_words', 1048576), 256, 1048576)
            if tile % 256: raise ValueError('CODEC_TILE_ALIGNMENT')
            stride = integer(config.get('stride_words', 2 if buffers[buf]['dtype']=='f64' else 1), 1, tile)
            transform = config.get('transform', 'xor' if buffers[buf]['dtype'].startswith('f') else 'delta')
            if transform not in ('xor', 'delta'): raise ValueError('CODEC_TRANSFORM')
            word_lanes = integer(config.get('word_lanes', 2 if buffers[buf]['dtype']=='f64' else 1), 1, 2)
            frames = (size//4+tile-1)//tile
            if len(nodes)*repetitions+len(transport_nodes)+3*frames>100000:
                raise ValueError('DISPATCH_BOUND')
            cap += 64*frames
            u32(kernel_indices['__qgc1_transport']); u32(stride); u32(int(transform=='xor')); u32(tile); u32(word_lanes)
            config = dict(codec='qgc1', tile_words=tile, stride_words=stride, transform=transform, word_lanes=word_lanes)
            output['compression'] = config
            transport_nodes.extend(f'__qgc1_{name}_{i}_{phase}' for i in range(frames) for phase in range(3))
        elif compressed:
            u32(2**32-1); u32(0); u32(0); u32(0); u32(0)
        if compressed and 'compression' in output and config is None: raise ValueError('OUTPUT_CODEC')
        output_contracts[name] = dict(raw_bytes=size, max_bytes=cap, compression=config,
                                      suffix='.qgc' if config else '.raw')
    if any(n['id'].startswith('__qgc1_') for n in nodes): raise ValueError('RESERVED_TRANSPORT_NODE')
    if len(nodes)*repetitions+len(transport_nodes)>100000: raise ValueError('DISPATCH_BOUND')
    Path(destination).write_bytes(data)
    return {'graph': graph, 'plan_sha256': hashlib.sha256(data).hexdigest(), 'files': sorted(files),
            'execution': {'mode': mode, 'lanes': lanes},
            'node_order': [n['id'] for n in ordered], 'transport_nodes': transport_nodes,
            'output_contracts': output_contracts,
            'dispatches': len(nodes)*repetitions+len(transport_nodes)}
