#define _GNU_SOURCE 1
#include "backend.hpp"
#include "compression/codec.hpp"
#include <fstream>
#include <filesystem>
#include <iostream>
#include <csignal>
#include <cstdlib>
#include <sys/file.h>
#include <sys/stat.h>
#include <sys/mman.h>
#include <unistd.h>
#include <fcntl.h>
#include <poll.h>
#include <iomanip>
#include <map>
#include <set>
#include <time.h>
#include <openssl/evp.h>
namespace fs=std::filesystem;
static volatile sig_atomic_t interrupted=0;
static void stop(int){interrupted=1;}
struct Reader {
    std::ifstream f;
    explicit Reader(const std::string& path):f(path,std::ios::binary){if(!f)throw std::runtime_error("PLAN_MISSING");}
    void raw(void* p,size_t n){if(!f.read((char*)p,n))throw std::runtime_error("PLAN_TRUNCATED");}
    uint32_t u32(){uint32_t v;raw(&v,4);return v;}
    uint64_t u64(){uint64_t v;raw(&v,8);return v;}
    uint32_t count(uint32_t max){auto n=u32();if(n>max)throw std::runtime_error("PLAN_COUNT_LIMIT");return n;}
    std::string str(){auto n=count(16384);std::string s(n,'\0');raw(s.data(),n);if(s.find('\0')!=std::string::npos)throw std::runtime_error("NUL_STRING");return s;}
    void end(){if(f.peek()!=EOF)throw std::runtime_error("TRAILING_PLAN_DATA");}
};
constexpr int seals=F_SEAL_WRITE|F_SEAL_GROW|F_SEAL_SHRINK|F_SEAL_SEAL;
static uint64_t sealed(const std::string& path){
    int fd=open(path.c_str(),O_RDONLY|O_CLOEXEC);if(fd<0)throw std::runtime_error("SNAPSHOT_OPEN");
    struct stat s{};int flags=fcntl(fd,F_GET_SEALS);int rc=fstat(fd,&s);close(fd);
    if(rc||flags<0||(flags&seals)!=seals||!S_ISREG(s.st_mode)||s.st_size<0)throw std::runtime_error("IMMUTABLE_SNAPSHOT_REQUIRED");
    return s.st_size;
}
static void digest_contract(const std::string& digest){if(digest.size()!=64||digest.find_first_not_of("0123456789abcdef")!=std::string::npos)throw std::runtime_error("SHA256_CONTRACT");}
struct BufferSpec {std::string name,input,digest;uint64_t bytes;bool readonly=false;};
struct Node {std::string name;uint32_t program,lane=0;std::vector<uint32_t> buffers,words;std::array<uint32_t,3> threads;};
struct Output {
    std::string name;uint32_t buffer,codec=UINT32_MAX,stride=0,transform=0,tile=0,word_lanes=0;uint64_t offset,bytes;
    uint64_t frames() const{return codec==UINT32_MAX?0:(bytes/4+tile-1)/tile;}
    uint64_t maximum() const{return bytes+64*frames();}
};
struct Plan {
    uint32_t repetitions,lanes;bool concurrent,immutable;
    std::vector<BufferSpec> buffers;std::vector<ProgramSpec> programs;std::vector<std::string> digests;
    std::vector<Node> nodes;std::vector<Output> outputs;
    explicit Plan(const std::string& path,bool require_immutable=false){
        if(require_immutable)sealed(path);
        Reader r(path);char magic[8];r.raw(magic,8);std::string v(magic,8);bool v4=v=="SCEPLAN4";immutable=v4?r.count(1)==1:v=="SCEPLAN3";
        bool v2=v4||immutable||v=="SCEPLAN2";if(!v2&&v!="SCEPLAN1")throw std::runtime_error("PLAN_VERSION");
        if(require_immutable&&!immutable)throw std::runtime_error("SESSION_REQUIRES_SEALED_PLAN_V3");
        repetitions=r.count(100000);if(!repetitions)throw std::runtime_error("EMPTY_REPEAT");
        lanes=v2?r.count(8):1;concurrent=v2?r.count(1)==1:false;
        if(!lanes||(concurrent&&lanes<2))throw std::runtime_error("LANE_CONTRACT");
        for(uint32_t n=r.count(1024);n;n--){
            BufferSpec b;b.name=r.str();b.bytes=r.u64();b.input=r.str();
            if(!b.bytes||b.bytes%4||b.bytes>(uint64_t(1)<<34))throw std::runtime_error("BUFFER_SIZE");
            if(immutable){b.digest=r.str();b.readonly=r.count(1);if(!b.input.empty()){digest_contract(b.digest);if(sealed(b.input)!=b.bytes)throw std::runtime_error("INPUT_SIZE");}else if(!b.digest.empty()||b.readonly)throw std::runtime_error("INPUT_CONTRACT");}
            buffers.push_back(b);
        }
        for(uint32_t n=r.count(256);n;n--){ProgramSpec p;p.path=r.str();std::string digest;if(immutable){digest=r.str();digest_contract(digest);if(!sealed(p.path))throw std::runtime_error("EMPTY_PROGRAM");}p.entry=r.str();p.bindings=r.count(32);p.words=r.count(32);p.float64=r.count(1);for(auto& v:p.local){v=r.count(1024);if(!v)throw std::runtime_error("LOCAL_SIZE");}programs.push_back(p);digests.push_back(digest);}
        for(uint32_t n=r.count(10000);n;n--){Node node;node.name=r.str();node.program=r.u32();if(node.program>=programs.size())throw std::runtime_error("PROGRAM_INDEX");for(uint32_t k=r.count(32);k;k--){auto i=r.u32();if(i>=buffers.size())throw std::runtime_error("BUFFER_INDEX");node.buffers.push_back(i);}for(uint32_t k=r.count(32);k;k--)node.words.push_back(r.u32());for(auto& t:node.threads){t=r.u32();if(!t)throw std::runtime_error("ZERO_DISPATCH");}if(v2)node.lane=r.count(lanes-1);if(node.buffers.size()!=programs[node.program].bindings||node.words.size()!=programs[node.program].words)throw std::runtime_error("KERNEL_ABI");nodes.push_back(std::move(node));}
        if(nodes.empty()||uint64_t(nodes.size())*repetitions>100000)throw std::runtime_error("DISPATCH_BOUND");
        std::vector<int> owners(buffers.size(),-1);
        for(auto& n:nodes)for(auto b:n.buffers){if(owners[b]>=0&&owners[b]!=int(n.lane))throw std::runtime_error("CROSS_LANE_BUFFER");owners[b]=int(n.lane);}
        std::set<std::string> names;
        for(uint32_t n=r.count(1024);n;n--){Output o;o.name=r.str();o.buffer=r.u32();o.offset=r.u64();o.bytes=r.u64();if(o.buffer>=buffers.size()||o.name.empty()||o.name.find_first_not_of("abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789_-")!=std::string::npos||!names.insert(o.name).second)throw std::runtime_error("OUTPUT_CONTRACT");auto size=buffers[o.buffer].bytes;if(o.offset>size||!o.bytes||o.bytes>size-o.offset)throw std::runtime_error("OUTPUT_BOUNDS");if(o.offset%4||o.bytes%4)throw std::runtime_error("OUTPUT_ALIGNMENT");
            if(v4){o.codec=r.u32();o.stride=r.u32();o.transform=r.u32();o.tile=r.u32();o.word_lanes=r.u32();
                if(o.codec!=UINT32_MAX){
                    if(o.codec>=programs.size())throw std::runtime_error("CODEC_INDEX");
                    auto& spec=programs[o.codec];
                    if(spec.bindings!=4||spec.words!=11||spec.local!=std::array<uint32_t,3>{64,1,1}||spec.float64)throw std::runtime_error("CODEC_ABI");
                    qgc::config(o.bytes/4,0,std::min(uint64_t(o.tile),o.bytes/4),o.stride,o.transform,o.tile,o.word_lanes);
                }else if(o.stride||o.transform||o.tile||o.word_lanes)throw std::runtime_error("CODEC_RAW_CONTRACT");
            }
            outputs.push_back(o);}
        if(outputs.empty())throw std::runtime_error("EMPTY_OUTPUT");
        uint64_t dispatches=nodes.size()*uint64_t(repetitions);for(auto& o:outputs)dispatches+=3*o.frames();
        if(dispatches>100000)throw std::runtime_error("DISPATCH_BOUND");r.end();
    }
};
static double process_cpu(){timespec t{};if(clock_gettime(CLOCK_PROCESS_CPUTIME_ID,&t))throw std::runtime_error("CPU_CLOCK");return t.tv_sec+t.tv_nsec*1e-9;}
struct PhaseCost {double wall=0,cpu=0;};
struct Phase {
    PhaseCost& cost;uint64_t wall=now_ns();double cpu=process_cpu();
    explicit Phase(PhaseCost& c):cost(c){}
    ~Phase(){cost.wall+=(now_ns()-wall)/1e9;cost.cpu+=process_cpu()-cpu;}
};
struct OutputSnapshot {
    int fd=-1;std::string name,digest,encoding="raw";uint64_t bytes=0,raw_bytes=0;
    OutputSnapshot()=default;OutputSnapshot(const OutputSnapshot&)=delete;
    OutputSnapshot(OutputSnapshot&& o):fd(o.fd),name(std::move(o.name)),digest(std::move(o.digest)),encoding(std::move(o.encoding)),bytes(o.bytes),raw_bytes(o.raw_bytes){o.fd=-1;}
    ~OutputSnapshot(){if(fd>=0)close(fd);}
};
static void write_all(int fd,const char* data,size_t n){while(n){auto k=write(fd,data,n);if(k<0&&errno==EINTR)continue;if(k<=0)throw std::runtime_error("OUTPUT_WRITE");data+=k;n-=k;}}
struct EngineSession {
    std::unique_ptr<Backend> gpu;
    std::map<std::string,std::shared_ptr<Buffer>> resident;
    std::map<std::string,std::shared_ptr<Program>> loaded;
    std::vector<std::shared_ptr<Buffer>> arena;
    std::vector<uint64_t> layout;
    std::shared_ptr<Buffer> codec_temp,codec_meta,codec_packet;uint32_t codec_capacity=0;
    const Plan* binding_plan=nullptr;
    std::vector<std::vector<Buffer*>> bound_nodes;
    // Upload/download complete before returning. Reuse one bounded host
    // staging buffer; each transfer overwrites the entire consumed range.
    static constexpr size_t transfer_limit=16*1024*1024;
    std::unique_ptr<char[]> transfer_chunk;
    void prepare_transfer(){if(!transfer_chunk)transfer_chunk.reset(new char[transfer_limit]);}
    uint64_t input_cap,resident_bytes=0,program_hits=0,program_misses=0,input_hits=0,input_misses=0,avoided_h2d=0,d2d=0,evictions=0;
    double init_wall=0,init_cpu=0;
    void close(){
        gpu->drain();
        // Reclaim owned objects while their backend is still valid. Explicit
        // teardown timing includes module unload, allocations and context exit.
        bound_nodes.clear();binding_plan=nullptr;
        arena.clear();resident.clear();loaded.clear();codec_temp.reset();codec_meta.reset();codec_packet.reset();gpu.reset();
        transfer_chunk.reset();
    }
    EngineSession(const std::string& api,const std::string& pci,uint32_t lanes,uint64_t cap):input_cap(cap){auto t=now_ns();auto c=process_cpu();gpu=api=="cuda"?make_cuda(pci,lanes):make_vulkan(pci,lanes);init_wall=(now_ns()-t)/1e9;init_cpu=process_cpu()-c;}
    static std::string input_key(const BufferSpec& b){return b.digest+":"+std::to_string(b.bytes);}
    static std::string program_key(const ProgramSpec& p,const std::string& digest){std::string key=digest+":"+p.entry+":"+std::to_string(p.bindings)+":"+std::to_string(p.words)+":"+std::to_string(p.float64);for(auto v:p.local)key+=":"+std::to_string(v);return key;}
    std::vector<OutputSnapshot> run(const Plan& plan,const fs::path& out,bool snapshots,bool deferred_digest=false){
        fs::create_directories(out);auto start=now_ns();auto cpu_start=process_cpu();std::map<std::string,PhaseCost> phases;
        if(!snapshots){start-=uint64_t(init_wall*1e9);cpu_start-=init_cpu;phases["backend_init"]={init_wall,init_cpu};}
        auto h2d_start=gpu->h2d,d2h_start=gpu->d2h,submit_start=gpu->submits,sync_start=gpu->syncs,alloc_start=gpu->allocs;
        auto hit_start=input_hits,miss_start=input_misses,phit_start=program_hits,pmiss_start=program_misses,avoid_start=avoided_h2d,copy_start=d2d;
        gpu->drain();gpu->events.clear();gpu->select_lane(0);
        // A repeated immutable plan keeps the same arena and resident inputs.
        // Keep its bindings after draining, but invalidate on EVERY plan change
        // before any arena/input can be reclaimed. Arithmetic/reset still runs.
        bool reuse_bindings=binding_plan==&plan;
        if(!reuse_bindings){
            bound_nodes.clear();binding_plan=nullptr;
            for(auto& p:loaded)gpu->reset_bindings(*p.second);
        }
        std::vector<uint64_t> next_layout;for(auto& b:plan.buffers)next_layout.push_back(plan.immutable&&b.readonly?0:b.bytes);
        if(next_layout!=layout){arena.clear();arena.resize(next_layout.size());layout=next_layout;}
        std::set<std::string> needed;uint64_t need_bytes=0;
        if(plan.immutable)for(auto& b:plan.buffers)if(!b.input.empty()&&needed.insert(input_key(b)).second)need_bytes+=b.bytes;
        if(need_bytes>input_cap)throw std::runtime_error("RESIDENT_INPUT_BUDGET_EXHAUSTED");
        // Evict only unused inputs. No opaque driver state or output is reused.
        for(auto it=resident.begin();it!=resident.end();){if(!needed.count(it->first)&&resident_bytes+need_bytes>input_cap){resident_bytes-=it->second->bytes;it=resident.erase(it);evictions++;}else ++it;}
        std::vector<std::shared_ptr<Buffer>> buffers;
        for(size_t i=0;i<plan.buffers.size();i++){
            auto& b=plan.buffers[i];std::shared_ptr<Buffer> source;
            if(plan.immutable&&!b.input.empty()){
                auto key=input_key(b);auto found=resident.find(key);
                if(found!=resident.end()){source=found->second;input_hits++;avoided_h2d+=b.bytes;}
                else {if(resident.size()>=4096||resident_bytes+b.bytes>input_cap)throw std::runtime_error("RESIDENT_INPUT_BUDGET_EXHAUSTED");{Phase t(phases["buffer_allocation"]);source=gpu->allocate(b.bytes);}upload(b,*source,phases);resident.emplace(key,source);resident_bytes+=b.bytes;input_misses++;}
            }
            if(plan.immutable&&b.readonly){buffers.push_back(source);continue;}
            if(!arena[i]){Phase t(phases["buffer_allocation"]);arena[i]=gpu->allocate(b.bytes);}
            auto target=arena[i];
            if(source){Phase t(phases["device_input_restore"]);gpu->copy(*source,*target);d2d+=b.bytes;}
            else if(!b.input.empty())upload(b,*target,phases);
            else {Phase t(phases["zero_enqueue"]);gpu->zero(*target);}
            buffers.push_back(target);
        }
        std::vector<std::shared_ptr<Program>> programs;
        for(size_t i=0;i<plan.programs.size();i++){
            auto& spec=plan.programs[i];auto key=program_key(spec,plan.immutable?plan.digests[i]:spec.path);auto it=loaded.find(key);
            if(it!=loaded.end()){programs.push_back(it->second);program_hits++;}
            else {if(loaded.size()>=256)throw std::runtime_error("PROGRAM_CACHE_BOUND");Phase t(phases["program_load"]);auto p=gpu->load(spec);loaded.emplace(key,p);programs.push_back(p);program_misses++;}
        }
        {Phase t(phases["binding_preparation"]);
            if(!reuse_bindings){
                bound_nodes.reserve(plan.nodes.size());
                for(auto& node:plan.nodes){std::vector<Buffer*> bound;bound.reserve(node.buffers.size());for(auto i:node.buffers)bound.push_back(buffers[i].get());bound_nodes.push_back(std::move(bound));}
                binding_plan=&plan;
            }
        }
        {Phase t(phases["setup_drain"]);gpu->drain();}auto compute_start=now_ns();
        {Phase t(phases["compute_enqueue"]);for(uint32_t repeat=0;repeat<plan.repetitions;repeat++)for(size_t ni=0;ni<plan.nodes.size();ni++){auto& node=plan.nodes[ni];if(interrupted)throw std::runtime_error("INTERRUPTED");gpu->select_lane(plan.concurrent?node.lane:0);gpu->dispatch(*programs[node.program],bound_nodes[ni],node.words,node.threads,node.name);}}
        {Phase t(phases["compute_drain"]);gpu->drain();}auto compute_end=now_ns();gpu->select_lane(0);
        std::vector<OutputSnapshot> result;
        for(auto& o:plan.outputs){
            OutputSnapshot s;s.name=o.name;s.raw_bytes=o.bytes;s.encoding=o.codec==UINT32_MAX?"raw":"qgc1";s.bytes=0;
            std::ofstream file;
            {Phase t(phases["output_allocation"]);
                if(snapshots){s.fd=memfd_create("science-output",MFD_CLOEXEC|MFD_ALLOW_SEALING);if(s.fd<0)throw std::runtime_error("OUTPUT_MEMFD");}
                else {file.open(out/(o.name+(o.codec==UINT32_MAX?".raw":".qgc")),std::ios::binary);if(!file)throw std::runtime_error("OUTPUT_OPEN");}
                prepare_transfer();
            }
            auto ctx=std::unique_ptr<EVP_MD_CTX,decltype(&EVP_MD_CTX_free)>(deferred_digest?nullptr:EVP_MD_CTX_new(),EVP_MD_CTX_free);
            if(!deferred_digest&&(!ctx||EVP_DigestInit_ex(ctx.get(),EVP_sha256(),nullptr)!=1))throw std::runtime_error("SHA256_INIT");
            auto emit=[&](const char* target,size_t n){
                if(!deferred_digest){Phase t(phases["output_sha256"]);if(EVP_DigestUpdate(ctx.get(),target,n)!=1)throw std::runtime_error("SHA256_UPDATE");}
                {Phase t(phases["output_file_write"]);if(snapshots)write_all(s.fd,target,n);else {file.write(target,n);if(!file)throw std::runtime_error("OUTPUT_WRITE");}}
                s.bytes+=n;
            };
            if(o.codec==UINT32_MAX){
                for(uint64_t pos=0;pos<o.bytes;){
                    size_t n=std::min(uint64_t(transfer_limit),o.bytes-pos);char* target=transfer_chunk.get();
                    {Phase t(phases["d2h_api_and_wait"]);gpu->download(*buffers[o.buffer],o.offset+pos,target,n);}
                    emit(target,n);pos+=n;
                }
            }else{
                if(codec_capacity<o.tile){
                    // Drain before replacing buffers referenced by descriptors.
                    gpu->drain();for(auto& p:loaded)gpu->reset_bindings(*p.second);
                    codec_temp.reset();codec_meta.reset();codec_packet.reset();
                    Phase t(phases["compression_allocation"]);
                    codec_temp=gpu->allocate(4ull*o.tile);codec_meta=gpu->allocate(8ull*((o.tile+255)/256));
                    codec_packet=gpu->allocate(4ull*(o.tile+16));codec_capacity=o.tile;
                }
                std::vector<Buffer*> bound{buffers[o.buffer].get(),codec_temp.get(),codec_meta.get(),codec_packet.get()};
                uint64_t total=o.bytes/4;
                for(uint64_t off=0,frame=0;off<total;off+=o.tile,frame++){
                    if(interrupted)throw std::runtime_error("INTERRUPTED");
                    uint32_t n=std::min(uint64_t(o.tile),total-off);
                    std::vector<uint32_t> words{n,o.stride,0,uint32_t(o.offset/4+off),uint32_t(off),uint32_t(off>>32),uint32_t(total),uint32_t(total>>32),o.transform,o.tile,o.word_lanes};
                    {Phase t(phases["compression_enqueue"]);
                        for(uint32_t phase=0;phase<3;phase++){words[2]=phase;gpu->dispatch(*programs[o.codec],bound,words,{phase==1?64u:((n+255)/256)*64,1,1},"__qgc1_"+o.name+"_"+std::to_string(frame)+"_"+std::to_string(phase));}
                    }
                    {Phase t(phases["compression_gpu_wait"]);gpu->drain();}
                    std::array<uint32_t,16> h{};
                    {Phase t(phases["compression_header_d2h"]);gpu->download(*codec_packet,0,h.data(),64);}
                    uint32_t packet_words;
                    {Phase t(phases["compression_header_check"]);packet_words=qgc::check_header(h.data(),total,off,n,o.stride,o.transform,o.tile,o.word_lanes);}
                    // Header is transferred exactly once. The GPU-selected size
                    // is checked against the caller's allocation before payload D2H.
                    emit(reinterpret_cast<const char*>(h.data()),64);
                    size_t bytes=4ull*(packet_words-16);
                    if(bytes){Phase t(phases["d2h_api_and_wait"]);gpu->download(*codec_packet,64,transfer_chunk.get(),bytes);}
                    emit(transfer_chunk.get(),bytes);
                }
            }
            unsigned char digest[EVP_MAX_MD_SIZE];unsigned int length=0;if(!deferred_digest&&(EVP_DigestFinal_ex(ctx.get(),digest,&length)!=1||length!=32))throw std::runtime_error("SHA256_FINAL");
            static const char* hex="0123456789abcdef";for(unsigned int j=0;j<length;j++){s.digest+=hex[digest[j]>>4];s.digest+=hex[digest[j]&15];}
            if(snapshots){Phase t(phases["output_seal"]);if(fcntl(s.fd,F_ADD_SEALS,seals)<0)throw std::runtime_error("OUTPUT_SEAL");}
            result.push_back(std::move(s));
        }
        std::ofstream events(out/"events.tsv");events<<std::setprecision(17);for(auto& e:gpu->events)events<<e.name<<'\t'<<e.host_begin<<'\t'<<e.host_end<<'\t'<<e.gpu_ms<<'\t'<<e.gpu_begin_ms<<'\t'<<e.gpu_end_ms<<'\t'<<e.lane<<'\n';
        std::ofstream stats(out/"native.json");stats<<std::setprecision(17)<<"{\"status\":\"EXECUTED_NOT_DOMAIN_VALIDATED\",\"compute_seconds\":"<<(compute_end-compute_start)/1e9<<",\"setup_seconds\":"<<(compute_start-start)/1e9<<",\"native_envelope_seconds\":"<<(now_ns()-start)/1e9<<",\"parent_cpu_seconds\":"<<process_cpu()-cpu_start<<",\"dispatches\":"<<gpu->events.size()<<",\"submit_calls\":"<<gpu->submits-submit_start<<",\"sync_calls\":"<<gpu->syncs-sync_start<<",\"H2D_API_bytes\":"<<gpu->h2d-h2d_start<<",\"D2H_API_bytes\":"<<gpu->d2h-d2h_start<<",\"gpu_allocated_peak_bytes\":"<<gpu->peak<<",\"allocations\":"<<gpu->allocs-alloc_start<<",\"lane_count\":"<<gpu->lane_count<<",\"queue_family\":"<<gpu->queue_family<<",\"timestamp_domain\":\""<<gpu->timestamp_domain<<"\",\"execution_mode\":\""<<(plan.concurrent?"concurrent":"serial")<<"\",\"cache\":{\"input_hits\":"<<input_hits-hit_start<<",\"input_misses\":"<<input_misses-miss_start<<",\"program_hits\":"<<program_hits-phit_start<<",\"program_misses\":"<<program_misses-pmiss_start<<",\"avoided_H2D_bytes\":"<<avoided_h2d-avoid_start<<",\"device_restore_bytes\":"<<d2d-copy_start<<",\"resident_bytes\":"<<resident_bytes<<",\"evictions_total\":"<<evictions<<",\"binding_plan_reused\":"<<(reuse_bindings?"true":"false")<<",\"binding_nodes_prepared\":"<<(reuse_bindings?0:plan.nodes.size())<<"},\"phase_costs\":{";bool comma=false;for(auto& pair:phases){if(comma)stats<<',';comma=true;stats<<'"'<<pair.first<<"\":{\"wall_seconds\":"<<pair.second.wall<<",\"cpu_seconds\":"<<pair.second.cpu<<'}';}stats<<"},\"output_transport\":[";comma=false;
        for(size_t i=0;i<result.size();i++){
            auto& s=result[i];if(comma)stats<<',';comma=true;
            stats<<"{\"name\":\""<<s.name<<"\",\"encoding\":\""<<s.encoding<<"\",\"raw_bytes\":"<<s.raw_bytes
                 <<",\"transferred_and_stored_bytes\":"<<s.bytes<<",\"frames\":"<<plan.outputs[i].frames()
                 <<",\"compression_dispatches\":"<<3*plan.outputs[i].frames()<<"}";
        }
        stats<<"],\"compression_scratch_bytes\":"<<(codec_capacity?8ull*codec_capacity+8ull*((codec_capacity+255)/256)+64:0)<<"}\n";
        return result;
    }
    void upload(const BufferSpec& b,Buffer& buffer,std::map<std::string,PhaseCost>& phases){
        std::ifstream f(b.input,std::ios::binary|std::ios::ate);if(!f||uint64_t(f.tellg())!=b.bytes)throw std::runtime_error("INPUT_SIZE:"+b.name);f.seekg(0);
        prepare_transfer();
        for(uint64_t pos=0;pos<b.bytes;){size_t n=std::min(uint64_t(transfer_limit),b.bytes-pos);{Phase t(phases["input_file_read"]);if(!f.read(transfer_chunk.get(),n))throw std::runtime_error("INPUT_READ");}{Phase t(phases["h2d_api_and_wait"]);gpu->upload(buffer,pos,transfer_chunk.get(),n);}pos+=n;}
    }
};
static void admission(){const char* lock=getenv("NGC_SHARED_LOCK_FD");if(!lock)throw std::runtime_error("SHARED_LOCK_REQUIRED");struct stat held{},named{};int fd=std::stoi(lock);if(fstat(fd,&held)||stat("/tmp/astro-qfirst-native.lock",&named)||held.st_dev!=named.st_dev||held.st_ino!=named.st_ino||flock(fd,LOCK_EX|LOCK_NB))throw std::runtime_error("SHARED_LOCK_INVALID");}
int main(int argc,char** argv){
    if(argc!=5&&!(argc==6&&std::string(argv[5])=="--session")){std::cerr<<"Use astro.py run or resident session controller\n";return 2;}
    signal(SIGINT,stop);signal(SIGTERM,stop);auto start=now_ns();auto cpu=process_cpu();fs::path out=argv[4];
    try {
        admission();std::string api=argv[1];if(api!="cuda"&&api!="vulkan")throw std::runtime_error("BACKEND_UNKNOWN");
        bool persistent=argc==6,deferred_digest=false;uint32_t lanes=1;uint64_t cap=0,output_cap=0;std::vector<Plan> plans;std::vector<uint32_t> jobs;
        if(persistent){sealed(argv[3]);Reader r(argv[3]);char magic[8];r.raw(magic,8);auto version=std::string(magic,8);if(version!="SCESESS1"&&version!="SCESESS2")throw std::runtime_error("SESSION_VERSION");lanes=r.count(8);cap=r.u64();output_cap=r.u64();if(version=="SCESESS2")deferred_digest=r.count(1);if(!lanes||!cap||!output_cap)throw std::runtime_error("SESSION_CAPS");for(uint32_t n=r.count(64);n;n--)plans.emplace_back(r.str(),true);for(uint32_t n=r.count(1000);n;n--){auto i=r.u32();if(i>=plans.size())throw std::runtime_error("CATALOG_INDEX");jobs.push_back(i);}r.end();}
        else {plans.emplace_back(argv[3]);lanes=plans[0].lanes;jobs.push_back(0);cap=uint64_t(1)<<34;}
        if(jobs.empty())throw std::runtime_error("EMPTY_SESSION");uint64_t dispatches=0;
        for(auto i:jobs){auto& p=plans[i];if(p.lanes!=lanes)throw std::runtime_error("SESSION_LANE_MISMATCH");dispatches+=p.nodes.size()*p.repetitions;uint64_t bytes=0;for(auto& o:p.outputs){bytes+=o.maximum();dispatches+=3*o.frames();}if(persistent&&bytes>output_cap)throw std::runtime_error("OUTPUT_SNAPSHOT_BUDGET");}
        if(dispatches>1000000)throw std::runtime_error("SESSION_DISPATCH_BOUND");
        EngineSession engine(api,argv[2],lanes,cap);PhaseCost ack_cost;
        for(size_t j=0;j<jobs.size();j++){
            if(interrupted)throw std::runtime_error("INTERRUPTED");auto dest=persistent?out/("job-"+std::to_string(j)):out;
            auto outputs=engine.run(plans[jobs[j]],dest,persistent,deferred_digest);
            if(persistent){
                std::cout<<"{\"job\":"<<j<<",\"digest_pending\":"<<(deferred_digest?"true":"false")<<",\"outputs\":[";bool comma=false;for(auto& s:outputs){if(comma)std::cout<<',';comma=true;std::cout<<"{\"name\":\""<<s.name<<"\",\"fd\":"<<s.fd<<",\"bytes\":"<<s.bytes<<",\"raw_bytes\":"<<s.raw_bytes<<",\"encoding\":\""<<s.encoding<<"\",\"sha256\":\""<<s.digest<<"\"}";}std::cout<<"]}"<<std::endl;
                // Parent duplicates sealed descriptors before ACK. At most one
                // native output set plus one parent validation set is live.
                Phase ack_timer(ack_cost);std::string ack;while(true){if(interrupted)throw std::runtime_error("INTERRUPTED");pollfd p{STDIN_FILENO,POLLIN,0};int rc=poll(&p,1,100);if(rc<0&&errno==EINTR)continue;if(rc<0)throw std::runtime_error("ACK_POLL");if(rc){if(!std::getline(std::cin,ack)||ack!="ACK "+std::to_string(j))throw std::runtime_error("OUTPUT_ACK_REQUIRED");break;}}
            }
        }
        auto identity=engine.gpu->identity;auto peak=engine.gpu->peak;auto staging=engine.transfer_chunk?EngineSession::transfer_limit:0;
        auto before_teardown=now_ns();auto cpu_before_teardown=process_cpu();
        engine.close();
        auto teardown_seconds=(now_ns()-before_teardown)/1e9;
        auto teardown_cpu_seconds=process_cpu()-cpu_before_teardown;
        if(persistent){std::ofstream s(out/"session_native.json");s<<std::setprecision(17)
            <<"{\"backend_initializations\":1,\"jobs\":"<<jobs.size()<<",\"dispatches\":"<<dispatches
            <<",\"worker_seconds\":"<<(now_ns()-start)/1e9<<",\"native_cpu_seconds\":"<<process_cpu()-cpu
            <<",\"backend_init_seconds\":"<<engine.init_wall<<",\"backend_init_cpu_seconds\":"<<engine.init_cpu
            <<",\"ack_wait_seconds\":"<<ack_cost.wall<<",\"ack_wait_cpu_seconds\":"<<ack_cost.cpu
            <<",\"teardown_seconds\":"<<teardown_seconds<<",\"teardown_cpu_seconds\":"<<teardown_cpu_seconds
            <<",\"host_transfer_buffer_bytes\":"<<staging
            <<",\"output_digest_location\":\""<<(deferred_digest?"CONTROLLER_SEALED_OUTPUT":"NATIVE_WORKER")<<"\""
            <<",\"worker_scope\":\"including explicit backend teardown, excluding final report write\""
            <<",\"gpu_allocated_peak_bytes\":"<<peak<<",\"identity\":\""<<identity<<"\"}\n";}
        else std::cout<<identity<<"\nEXECUTED_NOT_DOMAIN_VALIDATED\n";
        return 0;
    }catch(const std::exception& e){std::ofstream(out/"FAILURE.txt")<<e.what()<<'\n';std::cerr<<e.what()<<'\n';return 1;}
}
