"""Bounded host I/O without a Python-sized copy of every output block."""
import errno
import hashlib
import mmap
import os
import time
from contextlib import contextmanager
from pathlib import Path


@contextmanager
def host_phase(costs, name):
    start = time.monotonic_ns()
    cpu = time.thread_time_ns()
    try:
        yield
    finally:
        end = time.monotonic_ns()
        costs[name] = dict(wall_seconds=(end-start)/1e9,
                           cpu_seconds=(time.thread_time_ns()-cpu)/1e9,
                           start_monotonic_ns=start, end_monotonic_ns=end,
                           cpu_scope='calling host thread; worker CPU recorded separately')


def copy_fd(source_fd, destination, size):
    """Copy exact bytes from a sealed source, handling partial I/O and fallback.

    Kernel sendfile avoids the read/allocate/write Python loop. No hash is
    substituted or recomputed here; the source's seal/digest is checked by the
    caller. A retained file is complete only after the atomic rename succeeds.
    """
    destination = Path(destination)
    partial = destination.with_name(destination.name + '.partial')
    if destination.exists():
        raise FileExistsError(destination)
    target = os.open(partial, os.O_WRONLY | os.O_CREAT | os.O_EXCL | os.O_CLOEXEC, 0o600)
    pos = 0
    method = 'sendfile'
    try:
        while pos < size:
            try:
                written = os.sendfile(target, source_fd, pos, min(size-pos, 8*1024**2))
                if written == 0:
                    raise RuntimeError('OUTPUT_COPY_TRUNCATED')
                pos += written
            except OSError as error:
                if error.errno == errno.EINTR:
                    continue
                if error.errno not in (errno.ENOSYS, errno.EINVAL, errno.EXDEV, errno.EOPNOTSUPP):
                    raise
                method = 'bounded_pread_write_fallback'
                while pos < size:
                    block = os.pread(source_fd, min(size-pos, 1024**2), pos)
                    if not block:
                        raise RuntimeError('OUTPUT_COPY_TRUNCATED')
                    with memoryview(block) as view:
                        offset = 0
                        while offset < len(view):
                            count = os.write(target, view[offset:])
                            if count <= 0:
                                raise RuntimeError('OUTPUT_COPY_SHORT_WRITE')
                            offset += count
                    pos += len(block)
                break
        if os.fstat(target).st_size != size:
            raise RuntimeError('OUTPUT_COPY_SIZE')
        os.close(target); target = None
        partial.replace(destination)
        return dict(bytes=pos, method=method, durability='OS page cache; no new fsync guarantee')
    finally:
        if target is not None:
            os.close(target)
        if partial.exists():
            partial.unlink()


def sealed_sha256(fd, size):
    """Hash the exact immutable worker bytes without a user-space read copy."""
    from engine.integrity import require_sealed
    require_sealed(fd, size)
    if not size:
        return hashlib.sha256(b'').hexdigest()
    with mmap.mmap(fd, size, access=mmap.ACCESS_READ) as view:
        return hashlib.sha256(view).hexdigest()
