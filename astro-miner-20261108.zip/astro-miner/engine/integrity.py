"""Job-scoped SHA-256 registry and Linux sealed byte snapshots.

The snapshot, rather than mutable pathname metadata, is the execution input.
Metadata guards detect changes to the original; they are not content proofs.
No evidence is reused between registry lifetimes.
"""
import fcntl
import hashlib
import os
import stat
from dataclasses import dataclass
from pathlib import Path

SEALS = fcntl.F_SEAL_WRITE | fcntl.F_SEAL_GROW | fcntl.F_SEAL_SHRINK | fcntl.F_SEAL_SEAL


def signature(st):
    return (st.st_dev, st.st_ino, st.st_size, st.st_mtime_ns, st.st_ctime_ns)


def require_sealed(fd, size):
    if os.fstat(fd).st_size != size or fcntl.fcntl(fd, fcntl.F_GET_SEALS) & SEALS != SEALS:
        raise RuntimeError('IMMUTABLE_SNAPSHOT_REQUIRED')


@dataclass
class Snapshot:
    fd: int
    size: int
    sha256: str

    @property
    def path(self):
        return f'/proc/self/fd/{self.fd}'


class Integrity:
    def __init__(self, max_bytes=1024**3, max_files=4096):
        self.max_bytes = max_bytes
        self.max_files = max_files
        self.entries = {}
        self.fds = []
        self.resident_bytes = 0
        self.hashed_bytes = 0
        self.hash_passes = 0
        self.cache_hits = 0
        self._read_buffer = None

    def __enter__(self):
        return self

    def __exit__(self, *_):
        for fd in self.fds:
            os.close(fd)
        self.fds.clear()
        self._read_buffer = None

    def _reserve(self, size):
        if len(self.fds) >= self.max_files or self.resident_bytes + size > self.max_bytes:
            raise RuntimeError('HOST_SNAPSHOT_BUDGET_EXHAUSTED')

    def _seal(self, fd, size, digest):
        fcntl.fcntl(fd, fcntl.F_ADD_SEALS, SEALS)
        require_sealed(fd, size)
        self.fds.append(fd)
        self.resident_bytes += size
        return Snapshot(fd, size, digest)

    def bytes(self, data, name='plan'):
        self._reserve(len(data))
        fd = os.memfd_create(name, os.MFD_CLOEXEC | os.MFD_ALLOW_SEALING)
        try:
            with os.fdopen(os.dup(fd), 'wb') as stream:
                stream.write(data)
            digest = hashlib.sha256(data).hexdigest()
            self.hashed_bytes += len(data)
            self.hash_passes += 1
            return self._seal(fd, len(data), digest)
        except BaseException:
            os.close(fd)
            raise

    def file(self, path, *, snapshot=True):
        # Keep original spelling absolute: replacing a symlink must be detected.
        path = str(Path(path).absolute())
        old = self.entries.get(path)
        before = os.stat(path)
        if not stat.S_ISREG(before.st_mode):
            raise RuntimeError('REGULAR_FILE_REQUIRED:' + path)
        if old:
            if signature(before) != old['signature']:
                raise RuntimeError('SOURCE_CHANGED:' + path)
            if snapshot and old['snapshot'] is None:
                raise RuntimeError('SNAPSHOT_REQUIRED_ON_FIRST_ACCESS:' + path)
            self.cache_hits += 1
            return old['snapshot'] if snapshot else old['sha256']
        if snapshot:
            self._reserve(before.st_size)
        fd = os.memfd_create('science-input', os.MFD_CLOEXEC | os.MFD_ALLOW_SEALING) if snapshot else None
        try:
            h = hashlib.sha256()
            # Hash-only scans share one bounded scratch area. Snapshot copying
            # retains its measured faster buffered path; both hash every byte.
            with open(path, 'rb', buffering=-1 if snapshot else 0) as source:
                if signature(os.fstat(source.fileno())) != signature(before):
                    raise RuntimeError('SOURCE_REPLACED:' + path)
                sink = os.fdopen(os.dup(fd), 'wb') if snapshot else None
                try:
                    if snapshot:
                        while block := source.read(1024 * 1024):
                            h.update(block)
                            sink.write(block)
                    else:
                        if self._read_buffer is None:
                            self._read_buffer = bytearray(1024 * 1024)
                        with memoryview(self._read_buffer) as buffer:
                            while size := source.readinto(buffer):
                                h.update(buffer[:size])
                finally:
                    if sink:
                        sink.close()
                if signature(os.fstat(source.fileno())) != signature(before):
                    raise RuntimeError('SOURCE_CHANGED_DURING_READ:' + path)
            if signature(os.stat(path)) != signature(before):
                raise RuntimeError('SOURCE_CHANGED_DURING_READ:' + path)
            digest = h.hexdigest()
            sealed = self._seal(fd, before.st_size, digest) if snapshot else None
            self.entries[path] = dict(signature=signature(before), sha256=digest, snapshot=sealed)
            self.hashed_bytes += before.st_size
            self.hash_passes += 1
            return sealed if snapshot else digest
        except BaseException:
            if fd is not None and fd not in self.fds:
                os.close(fd)
            raise

    def sha(self, path):
        return self.file(path, snapshot=False)

    def check_sources(self):
        for path, item in self.entries.items():
            if signature(os.stat(path)) != item['signature']:
                raise RuntimeError('SOURCE_CHANGED:' + path)

    def evidence(self):
        return dict(hash_passes=self.hash_passes, hashed_bytes=self.hashed_bytes,
                    registry_hits=self.cache_hits, sealed_bytes=self.resident_bytes,
                    read_scratch_bytes=len(self._read_buffer) if self._read_buffer is not None else 0,
                    files={p: dict(sha256=e['sha256'], signature=e['signature'],
                                  sealed=e['snapshot'] is not None) for p, e in self.entries.items()},
                    scope='ONE_SESSION; immutable snapshots are authoritative; no cross-session metadata cache')
