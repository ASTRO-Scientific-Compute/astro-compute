"""Bounded, workload-neutral persistent sessions with sealed inputs/outputs.

Validators run in the controller while the worker starts the following job.
The GPU has at most one unacknowledged output set; the controller retains at
most one more. All jobs are explicit, separately accounted and verified.
"""
import collections
import json
import math
import os
import shutil
import struct
import subprocess
import threading
import time
from pathlib import Path
from engine.graph import compile_graph
from engine.host_io import copy_fd, host_phase, sealed_sha256
from engine.integrity import Integrity, require_sealed


class PreparedSession:
    def __init__(self, catalog, schedule, backend, output, *, snapshot_bytes=512*1024**2,
                 resident_bytes=512*1024**2, output_bytes=320*1024**2, deferred_digest=False, output_compression=None):
        self.integrity = Integrity(max_bytes=snapshot_bytes)
        self.catalog, self.schedule = catalog, list(schedule)
        self.output = Path(output)
        self.output.mkdir(parents=True, exist_ok=False)
        self.plans, self.plan_snapshots = [], []
        self.contracts = []
        self.lanes = None
        self.output_bytes = output_bytes
        if type(deferred_digest) is not bool:raise ValueError("DIGEST_POLICY")
        self.deferred_digest = deferred_digest
        if not 1 <= len(catalog) <= 64 or not 1 <= len(self.schedule) <= 1000:
            raise ValueError('SESSION_SIZE_BOUND')
        if any(type(i) is not int or not 0 <= i < len(catalog) for i in self.schedule):
            raise ValueError('CATALOG_INDEX')
        try:
            for i, item in enumerate(catalog):
                if type(item['evaluations']) is not int or item['evaluations'] <= 0:
                    raise ValueError('EXPLICIT_GRAPH_EVALUATION_COUNT_REQUIRED')
                p = self.output / f'catalog-{i}.bin'
                plan = compile_graph(item['graph'], backend, p, integrity=self.integrity,
                                     **({'output_compression':output_compression} if output_compression is not None else {}))
                if plan['graph'].get('iterations', 1) != 1:
                    raise ValueError('SESSION_JOBS_REQUIRE_EXPLICIT_SINGLE_EVALUATIONS')
                lanes = plan['execution']['lanes']
                if self.lanes is not None and self.lanes != lanes:
                    raise ValueError('SESSION_LANE_MISMATCH')
                self.lanes = lanes
                outputs = plan['output_contracts']
                if sum(o['max_bytes'] for o in outputs.values()) > output_bytes:
                    raise ValueError('OUTPUT_SNAPSHOT_BUDGET')
                if any(o['compression'] for o in outputs.values()) and not callable(item.get('validate_compressed')):
                    raise ValueError('COMPRESSED_OUTPUT_CHECKER_REQUIRED')
                self.contracts.append(dict(outputs=outputs,
                    dispatches=collections.Counter(plan['node_order']+plan['transport_nodes']),
                    lanes={**{n['id']: n.get('lane',0) if plan['execution']['mode']=='concurrent' else 0
                              for n in plan['graph']['nodes']},
                           **{name:0 for name in plan['transport_nodes']}}))
                self.plans.append(plan)
                self.plan_snapshots.append(self.integrity.bytes(p.read_bytes(), 'graph-plan'))
            if sum(self.plans[i]['dispatches'] for i in self.schedule) > 1000000:
                raise ValueError('SESSION_DISPATCH_BOUND')
            data = bytearray(b'SCESESS2')
            data.extend(struct.pack('<IQQII', self.lanes, resident_bytes, output_bytes, int(deferred_digest), len(catalog)))
            for snap in self.plan_snapshots:
                raw = snap.path.encode(); data.extend(struct.pack('<I', len(raw))); data.extend(raw)
            data.extend(struct.pack('<I', len(self.schedule)))
            for i in self.schedule: data.extend(struct.pack('<I', i))
            self.session_plan = self.integrity.bytes(data, 'session-plan')
            self.execution_fds = tuple(self.integrity.fds)
            (self.output/'session-plan.bin').write_bytes(data)
            (self.output/'SCHEDULE.json').write_text(json.dumps(dict(
                version=2, deferred_digest=deferred_digest, output_compression=output_compression, schedule=self.schedule, jobs=len(self.schedule),
                graph_evaluations=self.evaluations, lanes=self.lanes,
                catalog=[{k: [str(p) for p in v] if k=='integrity_files' else str(v) if isinstance(v, Path) else v for k, v in x.items()
                          if k not in ('validate', 'validate_compressed', 'bind_integrity')} for x in catalog],
                host_snapshot_bytes=snapshot_bytes, resident_input_bytes=resident_bytes,
                output_bytes_per_job=output_bytes,
                max_live_output_bytes=2*output_bytes,
                counting='Each scheduled job is executed and validated; no hidden warmup or retry.'), indent=2)+'\n')
        except BaseException:
            self.close()
            raise

    @property
    def evaluations(self):
        return sum(self.catalog[i]['evaluations'] for i in self.schedule)

    def close(self):
        self.integrity.__exit__(None, None, None)


def _execute_worker(prepared, executable, backend, pci, lock_fd, *, timeout, env):
    """Internal transport; caller MUST hold admission and charge a real campaign.

    CPU contract fixtures call this with a simulator binary. That evidence is
    labelled CPU_ONLY and cannot authorize or replace a GPU campaign.
    """
    from engine.session import stop_child, process_tree_cpu
    out = prepared.output
    exe = prepared.integrity.file(executable)
    evidence = out/'program_evidence'; evidence.mkdir(exist_ok=True)
    program_records = {}
    for item, plan in zip(prepared.catalog, prepared.plans):
        graph_parent = Path(item['graph']).resolve().parent
        for kernel in plan['graph']['kernels'].values():
            source = (graph_parent/kernel[backend]['path']).resolve()
            snap = prepared.integrity.file(source)
            target = evidence/(snap.sha256 + source.suffix)
            if not target.exists():
                with open(snap.path, 'rb') as f, target.open('xb') as g: shutil.copyfileobj(f, g)
            program_records[str(source)] = dict(sha256=snap.sha256, sealed=True, evidence=str(target), entry=kernel[backend].get('entry','main'))
    (out/'EXECUTION_IDENTITY.json').write_text(json.dumps(dict(
        native_sha256=exe.sha256, session_plan_sha256=prepared.session_plan.sha256,
        programs=program_records, reference_descriptors_inherited=False, cache_scope='One backend/context; program digest plus full ABI/local shape',
        proof='Sealed input/program descriptors, built worker, per-job native dispatch traces and sealed output digests'), indent=2)+'\n')
    prepared.integrity.check_sources()
    command = [exe.path, backend, pci, prepared.session_plan.path, str(out), '--session']
    begin = time.monotonic(); cpu = process_tree_cpu()
    passed_fds = tuple(sorted({lock_fd, exe.fd, *prepared.execution_fds}))
    # Reference/checker snapshots are controller-only and never inherited by worker.
    repeat_hashes = {}
    env = dict(env, NGC_SHARED_LOCK_FD=str(lock_fd))
    # exec via sealed bytes: the build-verified native image cannot change
    # between verification and launch. The same descriptors back every job.
    proc = None; reports = []; timed_out = threading.Event(); timer = None
    session_costs = {}
    with (out/'native.log').open('w') as log:
        try:
            proc = subprocess.Popen(command, pass_fds=passed_fds, env=env, stdin=subprocess.PIPE,
                                    stdout=subprocess.PIPE, stderr=log, text=True,
                                    start_new_session=True, bufsize=1)
            def expired():
                timed_out.set()
                stop_child(proc)
            timer = threading.Timer(timeout, expired); timer.daemon = True; timer.start()
            for job, index in enumerate(prepared.schedule):
                job_costs = {}
                with host_phase(job_costs, 'worker_output_wait'):
                    line = proc.stdout.readline(262145)
                if not line or len(line) > 262144:
                    raise RuntimeError('SESSION_OUTPUT_PROTOCOL_OR_WORKER_EXIT')
                record = json.loads(line)
                if record.get('digest_pending',False) != prepared.deferred_digest:
                    raise RuntimeError('SESSION_DIGEST_POLICY')
                if record.get('job') != job:
                    raise RuntimeError('SESSION_OUTPUT_ORDER')
                plan = prepared.plans[index]
                expected = plan['graph']['outputs']
                contract = prepared.contracts[index]
                if len(record['outputs']) != len(expected) or {x['name'] for x in record['outputs']} != set(expected):
                    raise RuntimeError('SESSION_OUTPUT_SET')
                dest = out/f'job-{job}'
                view = dest/'sealed-check'; view.mkdir()
                held = []
                hashes = {}; descriptors = {}
                validation_start = time.monotonic()
                try:
                    with host_phase(job_costs, 'descriptor_acquisition'):
                        for item in record['outputs']:
                            name = item['name']
                            output_contract = contract['outputs'][name]
                            compressed = output_contract['compression'] is not None
                            size = item['bytes']
                            expected_encoding = 'qgc1' if compressed else 'raw'
                            if (type(size) is not int or size <= 0 or size > output_contract['max_bytes']
                                or (not compressed and size != output_contract['raw_bytes'])
                                or item.get('encoding','raw') != expected_encoding
                                or item.get('raw_bytes',size) != output_contract['raw_bytes']
                                or type(item['fd']) is not int or item['fd'] < 0):
                                raise RuntimeError('SESSION_OUTPUT_SHAPE')
                            digest = item['sha256']
                            if prepared.deferred_digest:
                                if digest != '':raise RuntimeError('SESSION_OUTPUT_DIGEST')
                            elif len(digest) != 64 or set(digest) - set('0123456789abcdef'):
                                raise RuntimeError('SESSION_OUTPUT_DIGEST')
                            fd = os.open(f'/proc/{proc.pid}/fd/{item["fd"]}', os.O_RDONLY|os.O_CLOEXEC)
                            held.append(fd); require_sealed(fd, size)
                            (view/(name+output_contract['suffix'])).symlink_to(f'/proc/{os.getpid()}/fd/{fd}')
                            hashes[name+output_contract['suffix']] = digest
                            descriptors[name+output_contract['suffix']] = (fd,size)
                    # The parent now owns immutable descriptors. ACK allows the
                    # next GPU job while validation and artifact persistence run.
                    proc.stdin.write(f'ACK {job}\n'); proc.stdin.flush()
                    if prepared.deferred_digest:
                        with host_phase(job_costs, 'output_sha256'):
                            hashes = {name:sealed_sha256(fd,size) for name,(fd,size) in descriptors.items()}
                    run = dict(argv=command, job=job, catalog=index, output_sha256=hashes,
                               plan_sha256=prepared.plan_snapshots[index].sha256,
                               output_hash_source=('Controller SHA256 of sealed completed outputs after ACK; next GPU job may run concurrently' if prepared.deferred_digest else 'SHA256 during native D2H write; sealed same bytes passed to checker'))
                    for d in (dest, view):
                        (d/'RUN.json').write_text(json.dumps(run, indent=2)+'\n')
                    with host_phase(job_costs, 'dispatch_audit'):
                        rows = [row.split('\t') for row in (dest/'events.tsv').read_text().splitlines()]
                        observed = collections.Counter(row[0] for row in rows)
                        if observed != contract['dispatches']:
                            raise RuntimeError('DISPATCH_EVIDENCE_MISMATCH')
                        if any(int(row[6]) != contract['lanes'][row[0]] for row in rows):
                            raise RuntimeError('LANE_EVIDENCE_MISMATCH')
                    with host_phase(job_costs, 'scientific_validation'):
                        if any(o['compression'] for o in contract['outputs'].values()):
                            verdict = prepared.catalog[index]['validate_compressed'](view, hashes, contract['outputs'])
                        else:
                            verdict = prepared.catalog[index]['validate'](view, hashes)
                    scientific_ok = bool(verdict) and all(v.get('status') == 'PASS' for v in verdict.values())
                    bit_ok = index not in repeat_hashes or repeat_hashes[index] == hashes
                    repeat_hashes.setdefault(index, hashes)
                    require_bits = prepared.catalog[index].get('repeat_zero_bit_required', True)
                    # Retained artifacts are copied from the checked immutable
                    # bytes; later independent audits rehash the disk artifacts.
                    copies = []
                    with host_phase(job_costs, 'output_persistence'):
                        for name,(fd,size) in descriptors.items():
                            copies.append(copy_fd(fd, dest/name, size))
                    with host_phase(job_costs, 'supplementary_metadata'):
                        for p in view.glob('*.json'):
                            if p.name != 'RUN.json': shutil.copyfile(p, dest/p.name)
                    native = json.loads((dest/'native.json').read_text())
                    report = dict(job=job, catalog=index, name=prepared.catalog[index]['name'],
                                  evaluations=prepared.catalog[index]['evaluations'],
                                  status='PASS' if scientific_ok and (bit_ok or not require_bits) else 'FAIL',
                                  repeat_bit_gate='ZERO_BIT' if bit_ok else 'NOT_ZERO_BIT',
                                  outputs=hashes, scientific=verdict, native=native,
                                  host_phase_costs=job_costs, persistence=copies,
                                  numerical_validation=('COMPRESSED_CHECKER_DECLARED_SCOPE' if any(o['compression'] for o in contract['outputs'].values()) else 'RECOMPUTED_FOR_EVERY_JOB'),
                                  validation_and_persistence_seconds=time.monotonic()-validation_start)
                finally:
                    # No surviving symlinks to recycled process-local FD names.
                    with host_phase(job_costs, 'temporary_view_cleanup'):
                        if view.exists(): shutil.rmtree(view)
                        for fd in held: os.close(fd)
                (dest/'VERIFICATION.json').write_text(json.dumps(report, indent=2)+'\n')
                reports.append(report)
                if report['status'] != 'PASS':
                    raise RuntimeError('SCIENTIFIC_OR_REPEAT_BIT_GATE_FAILED:'+str(dest))
            proc.stdin.close()
            with host_phase(session_costs, 'worker_exit_wait'):
                rc = proc.wait(timeout=max(1, timeout-(time.monotonic()-begin)))
            if rc or timed_out.is_set():
                raise RuntimeError('SESSION_WORKER_FAILED_OR_TIMEOUT')
            with host_phase(session_costs, 'source_identity_check'):
                prepared.integrity.check_sources()
        finally:
            if timer: timer.cancel()
            if proc and proc.poll() is None: stop_child(proc)
            if proc:
                if proc.stdout: proc.stdout.close()
                if proc.stdin and not proc.stdin.closed: proc.stdin.close()
    result = dict(status='PASS', jobs=len(reports), evaluations=prepared.evaluations,
                  worker_envelope_seconds=time.monotonic()-begin,
                  controller_and_reaped_worker_cpu_seconds=process_tree_cpu()-cpu,
                  reports=reports, integrity=prepared.integrity.evidence(), host_phase_costs=session_costs,
                  cpu_scope='Worker launch through reaping plus concurrent controller verification; preparation reported separately')
    (out/'SESSION_RESULT.json').write_text(json.dumps(result, indent=2)+'\n')
    return result


def run_session(catalog, schedule, backend, pci, output, ledger, *, timeout=60,
                snapshot_bytes=512*1024**2, resident_bytes=512*1024**2,
                output_bytes=320*1024**2, deferred_digest=False, output_compression=None):
    """Production entry: no implicit budget amendment, retries or warmups."""
    from engine.session import guarded, environment, charge_start, charge_finish, process_tree_cpu
    from src.build import check_build, ROOT
    from autotune.budget import Budget
    if isinstance(timeout, bool) or not isinstance(timeout, (int, float)) or not math.isfinite(timeout) or not 0 < timeout <= 3600:
        raise ValueError('SESSION_TIMEOUT_RANGE')
    start = time.monotonic(); cpu = process_tree_cpu()
    budget = Budget(ledger)
    # Fail closed before expensive preparation if the requested ledger is shut.
    memory = budget.memory_limit(pci)
    preparation_costs = {}
    with host_phase(preparation_costs, 'graph_and_input_preparation'):
        prepared = PreparedSession(catalog, schedule, backend, output,
                                   snapshot_bytes=snapshot_bytes, resident_bytes=resident_bytes,
                                   output_bytes=output_bytes, deferred_digest=deferred_digest, output_compression=output_compression)
    token = None
    try:
        # Snapshot executable first, so build integrity uses its one cached hash.
        prepared.integrity.file(ROOT/'build/science-engine')
        with host_phase(preparation_costs, 'checker_and_reference_preparation'):
            for item in catalog:
                for path in item.get('integrity_files', []): prepared.integrity.file(path)
                if item.get('bind_integrity'): item['bind_integrity'](prepared.integrity)
        with host_phase(preparation_costs, 'full_build_integrity'):
            check_build(prepared.integrity)
        request = dict(sessions=1, candidate_evaluations=prepared.evaluations,
                       worker_seconds=timeout+30., gpu_seconds=(timeout+30.)*prepared.lanes,
                       memory_bytes=memory)
        budget.preflight(request, pci)
        def execute(fd):
            nonlocal token
            token = budget.reserve(request, pci, str(output))
            charged = False; begin = time.monotonic(); rc = 1
            try:
                charge_start('short_GPU_trials', Path(output), timeout); charged = True
                env = environment(); env['SCIENCE_BUFFER_BUDGET_BYTES'] = str(memory)
                result = _execute_worker(prepared, ROOT/'build/science-engine', backend, pci, fd,
                                         timeout=timeout, env=env)
                rc = 0
                gpu_seconds = 0.
                for job in range(len(schedule)):
                    for row in (Path(output)/f'job-{job}'/'events.tsv').read_text().splitlines():
                        gpu_seconds += float(row.split('\t')[3])/1000
                peak = max(r['native']['gpu_allocated_peak_bytes'] for r in result['reports'])
                budget.settle(token, worker_seconds=time.monotonic()-begin, gpu_seconds=gpu_seconds,
                              peak_bytes=peak, evidence=Path(output)/'SESSION_RESULT.json')
                result.update(preparation_costs=preparation_costs, full_e2e_seconds=time.monotonic()-start,
                              full_process_tree_cpu_seconds=process_tree_cpu()-cpu,
                              gpu_marker_seconds=gpu_seconds, backend_peak_bytes=peak)
                (Path(output)/'SESSION_RESULT.json').write_text(json.dumps(result, indent=2)+'\n')
                return result
            except BaseException as error:
                budget.unknown(token, str(error))
                raise
            finally:
                if charged: charge_finish(Path(output), time.monotonic()-begin, rc)
        return guarded('resident_session', execute)
    finally:
        prepared.close()
