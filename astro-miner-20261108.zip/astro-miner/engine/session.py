"""Independent process admission, bounded campaign accounting and environment."""
import json,os,signal,subprocess,time
from pathlib import Path
from admission import acquire,PROJECT

def save(path,value):
    tmp=path.with_suffix(path.suffix+'.new');tmp.write_text(json.dumps(value,indent=2)+'\n');tmp.replace(path)


def environment():
    env=os.environ.copy()
    env.update(HOME=str(PROJECT/'home'),XDG_CACHE_HOME=str(PROJECT/'cache'),TMPDIR=str(PROJECT/'tmp'),
               CUDA_CACHE_PATH=str(PROJECT/'cache/cuda'),MESA_SHADER_CACHE_DIR=str(PROJECT/'cache/mesa'),
               PYTHONPATH=str(PROJECT/'src'),PYTHONNOUSERSITE='1',PYTHONDONTWRITEBYTECODE='1',
               OMP_NUM_THREADS='1',OPENBLAS_NUM_THREADS='1',MKL_NUM_THREADS='1',NUMEXPR_NUM_THREADS='1')
    return env


def guarded(label,action,*,cpu_only=False):
    t=time.monotonic();fd=None
    try:
        fd=acquire(cpu_only=cpu_only)
        return action(fd)
    except Exception as e:
        save(PROJECT/'logs'/('LAST_'+label.upper()+'.json'),dict(status='FAILED_OR_BLOCKED',error=str(e),elapsed_seconds=time.monotonic()-t,utc_unix_ns=time.time_ns()))
        raise
    finally:
        if fd is not None:os.close(fd)


def cost():
    path=PROJECT/'COST.json'
    if path.exists():return json.loads(path.read_text())
    return dict(full_attempts=0,short_GPU_trials=0,worker_envelope_seconds=0.,attempts=[],limits=dict(full_attempts=18,short_GPU_trials=64,worker_envelope_seconds=7200))


def charge_start(kind,output,limit):
    c=cost()
    if c[kind]>=c['limits'][kind] or c['worker_envelope_seconds']+limit+30>c['limits']['worker_envelope_seconds']:raise RuntimeError('CAMPAIGN_BUDGET_EXHAUSTED')
    if any(a.get('status')=='RUNNING' for a in c['attempts']):raise RuntimeError('PREVIOUS_ATTEMPT_NOT_CLOSED_REVIEW_COST_BEFORE_RESUMING')
    c[kind]+=1;c['attempts'].append(dict(output=str(output),status='RUNNING',reserved_timeout_seconds=limit,utc_unix_ns=time.time_ns()))
    save(PROJECT/'COST.json',c)


def charge_finish(output,seconds,rc):
    c=cost();c['worker_envelope_seconds']+=seconds
    for a in c['attempts']:
        if a['output']==str(output):a.update(status='FINISHED' if rc==0 else 'FAILED',returncode=rc,worker_envelope_seconds=seconds)
    save(PROJECT/'COST.json',c)


def stop_child(proc):
    # Only this freshly created process group; never an ASTRO process.
    if proc.poll() is not None:return
    os.killpg(proc.pid,signal.SIGINT)
    try:proc.wait(timeout=30)
    except subprocess.TimeoutExpired:
        os.killpg(proc.pid,signal.SIGKILL);proc.wait()




def process_tree_cpu():
    """CPU seconds for this process plus reaped descendants (Linux rusage)."""
    import resource
    return sum(r.ru_utime+r.ru_stime for r in (
        resource.getrusage(resource.RUSAGE_SELF), resource.getrusage(resource.RUSAGE_CHILDREN)))


from contextlib import contextmanager


@contextmanager
def measure_phase(phases, name):
    start = time.monotonic(); cpu = process_tree_cpu()
    try:
        yield
    finally:
        phases[name] = dict(wall_seconds=time.monotonic()-start, cpu_seconds=process_tree_cpu()-cpu)
