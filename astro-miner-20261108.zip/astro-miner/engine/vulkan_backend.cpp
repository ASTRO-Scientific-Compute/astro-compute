#include "backend.hpp"
#include <vulkan/vulkan.h>
#include <cstring>
#include <fstream>
#include <map>
#include <sstream>

static void ck(VkResult r){if(r!=VK_SUCCESS)throw std::runtime_error("VULKAN_ERROR:"+std::to_string(r));}
struct Device {
    VkInstance instance{};VkDevice device{};
    ~Device(){if(device){vkDeviceWaitIdle(device);vkDestroyDevice(device,nullptr);}if(instance)vkDestroyInstance(instance,nullptr);}
};
struct VB : Buffer {
    std::shared_ptr<Device> owner_device;VkBuffer b{};VkDeviceMemory m{};
    void* mapped=nullptr;VkDeviceSize reserved=0;
    ~VB(){auto d=owner_device->device;if(mapped)vkUnmapMemory(d,m);if(b)vkDestroyBuffer(d,b,nullptr);if(m)vkFreeMemory(d,m,nullptr);}
};
struct VP : Program {
    std::shared_ptr<Device> owner_device;
    VkDescriptorSetLayout dl{};VkDescriptorPool dp{};VkPipelineLayout pl{};VkPipeline pipeline{};
    // Include every bound buffer identity. No stale descriptor reuse after free.
    std::map<std::vector<uint64_t>,VkDescriptorSet> descriptors;
    ~VP(){auto d=owner_device->device;vkDestroyPipeline(d,pipeline,nullptr);vkDestroyPipelineLayout(d,pl,nullptr);vkDestroyDescriptorPool(d,dp,nullptr);vkDestroyDescriptorSetLayout(d,dl,nullptr);}
};
struct Vulkan : Backend {
    std::shared_ptr<Device> context=std::make_shared<Device>();
    VkPhysicalDevice physical{};VkDevice device{};
    VkPhysicalDeviceMemoryProperties memory{};VkPhysicalDeviceProperties props{};
    uint32_t family=0,timestamp_bits=0;bool float64=false,calibrated=false;
    struct Pending {std::string name;uint64_t host;};
    struct Lane {
        VkQueue queue{};VkCommandPool pool{};VkCommandBuffer cmd{};
        VkFence fence{};VkQueryPool queries{};VkSemaphore timeline{};
        bool recording=false;uint32_t nq=0;uint64_t submitted=0;
        std::vector<Pending> pending;
    };
    std::vector<Lane> lanes;
    Lane& lane(){return lanes.at(active_lane);}
    uint64_t next_id=0;
    std::shared_ptr<VB> staging;
    std::vector<std::weak_ptr<VB>> allocations;
    std::vector<std::shared_ptr<Buffer>> live_buffers;
    std::vector<std::shared_ptr<Program>> live_programs;
    std::vector<uint64_t> descriptor_key;

    std::shared_ptr<VB> raw(size_t bytes,bool host){
        auto b=std::make_shared<VB>();b->owner_device=context;b->owner=this;b->id=++next_id;b->bytes=bytes;
        VkBufferCreateInfo bi{VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO};bi.size=bytes;
        bi.usage=VK_BUFFER_USAGE_STORAGE_BUFFER_BIT|VK_BUFFER_USAGE_TRANSFER_SRC_BIT|VK_BUFFER_USAGE_TRANSFER_DST_BIT;
        bi.sharingMode=VK_SHARING_MODE_EXCLUSIVE;ck(vkCreateBuffer(device,&bi,nullptr,&b->b));
        VkMemoryRequirements req{};vkGetBufferMemoryRequirements(device,b->b,&req);int chosen=-1;
        auto flags=host?(VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT|VK_MEMORY_PROPERTY_HOST_COHERENT_BIT):VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT;
        for(uint32_t i=0;i<memory.memoryTypeCount;i++)if((req.memoryTypeBits&(1u<<i))&&(memory.memoryTypes[i].propertyFlags&flags)==flags){chosen=i;break;}
        if(chosen<0)throw std::runtime_error("VULKAN_MEMORY_TYPE_UNAVAILABLE");
        allocated=0;for(auto it=allocations.begin();it!=allocations.end();){if(auto old=it->lock()){allocated+=old->reserved;++it;}else it=allocations.erase(it);}
        if(req.size>available||allocated>available-req.size)throw std::runtime_error("GPU_MEMORY_BUDGET_EXCEEDED");
        VkMemoryAllocateInfo ai{VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO};ai.allocationSize=req.size;ai.memoryTypeIndex=chosen;
        ck(vkAllocateMemory(device,&ai,nullptr,&b->m));ck(vkBindBufferMemory(device,b->b,b->m,0));b->reserved=req.size;
        if(host)ck(vkMapMemory(device,b->m,0,bytes,0,&b->mapped));
        allocated+=req.size;peak=std::max(peak,allocated);allocs++;allocations.push_back(b);return b;
    }
    explicit Vulkan(const std::string& pci,uint32_t count){
        if(!count||count>8)throw std::runtime_error("LANE_RANGE");lane_count=count;
        VkApplicationInfo app{VK_STRUCTURE_TYPE_APPLICATION_INFO};app.pApplicationName="Independent scientific engine";app.apiVersion=VK_API_VERSION_1_2;
        VkInstanceCreateInfo ci{VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO};ci.pApplicationInfo=&app;ck(vkCreateInstance(&ci,nullptr,&context->instance));
        uint32_t num=0;ck(vkEnumeratePhysicalDevices(context->instance,&num,nullptr));std::vector<VkPhysicalDevice> devices(num);ck(vkEnumeratePhysicalDevices(context->instance,&num,devices.data()));bool budget=false;
        for(auto d:devices){
            uint32_t ne=0;ck(vkEnumerateDeviceExtensionProperties(d,nullptr,&ne,nullptr));std::vector<VkExtensionProperties> ex(ne);ck(vkEnumerateDeviceExtensionProperties(d,nullptr,&ne,ex.data()));
            bool pb=false,mb=false;for(auto& e:ex){pb|=!strcmp(e.extensionName,VK_EXT_PCI_BUS_INFO_EXTENSION_NAME);mb|=!strcmp(e.extensionName,VK_EXT_MEMORY_BUDGET_EXTENSION_NAME);}if(!pb)continue;
            VkPhysicalDevicePCIBusInfoPropertiesEXT p{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PCI_BUS_INFO_PROPERTIES_EXT};VkPhysicalDeviceIDProperties ids{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_ID_PROPERTIES};p.pNext=&ids;
            VkPhysicalDeviceProperties2 pr{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_PROPERTIES_2};pr.pNext=&p;vkGetPhysicalDeviceProperties2(d,&pr);
            char b[32];snprintf(b,32,"%04x:%02x:%02x.%x",p.pciDomain,p.pciBus,p.pciDevice,p.pciFunction);if(pci!=b)continue;
            physical=d;props=pr.properties;budget=mb;
            for(auto& e:ex)calibrated|=!strcmp(e.extensionName,VK_EXT_CALIBRATED_TIMESTAMPS_EXTENSION_NAME);
            std::ostringstream o;o<<props.deviceName<<" pci="<<b<<" uuid=";for(auto u:ids.deviceUUID){char z[3];snprintf(z,3,"%02x",u);o<<z;}o<<" driver="<<props.driverVersion;identity=o.str();break;
        }
        if(!physical||!budget)throw std::runtime_error("VULKAN_PCI_OR_LIVE_MEMORY_BUDGET_UNAVAILABLE");
        VkPhysicalDeviceFeatures features{};vkGetPhysicalDeviceFeatures(physical,&features);float64=features.shaderFloat64;
        VkPhysicalDeviceMemoryBudgetPropertiesEXT b{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_MEMORY_BUDGET_PROPERTIES_EXT};
        VkPhysicalDeviceMemoryProperties2 mp{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_MEMORY_PROPERTIES_2};mp.pNext=&b;vkGetPhysicalDeviceMemoryProperties2(physical,&mp);memory=mp.memoryProperties;
        for(uint32_t i=0;i<memory.memoryHeapCount;i++)if(memory.memoryHeaps[i].flags&VK_MEMORY_HEAP_DEVICE_LOCAL_BIT){auto free=b.heapBudget[i]>b.heapUsage[i]?b.heapBudget[i]-b.heapUsage[i]:0;available=std::max(available,uint64_t(free));}
        available=available>512ull*1024*1024?available-512ull*1024*1024:0;
        available=allocation_cap(available);
        uint32_t nf=0;vkGetPhysicalDeviceQueueFamilyProperties(physical,&nf,nullptr);std::vector<VkQueueFamilyProperties> families(nf);vkGetPhysicalDeviceQueueFamilyProperties(physical,&nf,families.data());bool found=false;
        for(uint32_t i=0;i<nf;i++)if((families[i].queueFlags&VK_QUEUE_COMPUTE_BIT)&&families[i].queueCount>=count&&(count==1||families[i].timestampValidBits)){
            family=i;timestamp_bits=families[i].timestampValidBits;found=true;break;
        }
        if(!found)throw std::runtime_error("COMPUTE_QUEUE_COUNT_OR_TIMESTAMPS_UNAVAILABLE");
        queue_family=int(family);
        // This extension guarantees a common device time domain across queues.
        // Without it, cross-queue timestamp comparisons would be unsupported.
        if(count>1&&!calibrated)throw std::runtime_error("COMMON_QUEUE_TIMESTAMP_DOMAIN_UNAVAILABLE");
        if(calibrated)timestamp_domain="VULKAN_DEVICE_COMMON_EXT_CALIBRATED_TIMESTAMPS";
        VkPhysicalDeviceTimelineSemaphoreFeatures timeline{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_TIMELINE_SEMAPHORE_FEATURES};
        if(count>1){
            if(props.apiVersion<VK_API_VERSION_1_2)throw std::runtime_error("MULTIQUEUE_REQUIRES_VULKAN_1_2");
            VkPhysicalDeviceFeatures2 f2{VK_STRUCTURE_TYPE_PHYSICAL_DEVICE_FEATURES_2};f2.pNext=&timeline;vkGetPhysicalDeviceFeatures2(physical,&f2);
            if(!timeline.timelineSemaphore)throw std::runtime_error("TIMELINE_SEMAPHORE_UNAVAILABLE");
        }
        std::vector<float> priorities(count,1.0f);VkDeviceQueueCreateInfo qi{VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO};qi.queueFamilyIndex=family;qi.queueCount=count;qi.pQueuePriorities=priorities.data();
        VkPhysicalDeviceFeatures enabled{};enabled.shaderFloat64=float64;VkDeviceCreateInfo di{VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO};di.queueCreateInfoCount=1;di.pQueueCreateInfos=&qi;di.pEnabledFeatures=&enabled;
        if(count>1)di.pNext=&timeline;
        const char* timestamp_extension=VK_EXT_CALIBRATED_TIMESTAMPS_EXTENSION_NAME;
        if(calibrated){di.enabledExtensionCount=1;di.ppEnabledExtensionNames=&timestamp_extension;}
        ck(vkCreateDevice(physical,&di,nullptr,&context->device));device=context->device;lanes.resize(count);
        for(uint32_t i=0;i<count;i++){
            auto& l=lanes[i];vkGetDeviceQueue(device,family,i,&l.queue);
            VkCommandPoolCreateInfo pi{VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO};pi.flags=VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT;pi.queueFamilyIndex=family;ck(vkCreateCommandPool(device,&pi,nullptr,&l.pool));
            VkCommandBufferAllocateInfo ca{VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO};ca.commandPool=l.pool;ca.level=VK_COMMAND_BUFFER_LEVEL_PRIMARY;ca.commandBufferCount=1;ck(vkAllocateCommandBuffers(device,&ca,&l.cmd));
            VkFenceCreateInfo fi{VK_STRUCTURE_TYPE_FENCE_CREATE_INFO};ck(vkCreateFence(device,&fi,nullptr,&l.fence));
            if(timestamp_bits){VkQueryPoolCreateInfo qq{VK_STRUCTURE_TYPE_QUERY_POOL_CREATE_INFO};qq.queryType=VK_QUERY_TYPE_TIMESTAMP;qq.queryCount=4096;ck(vkCreateQueryPool(device,&qq,nullptr,&l.queries));}
            if(count>1){VkSemaphoreTypeCreateInfo ty{VK_STRUCTURE_TYPE_SEMAPHORE_TYPE_CREATE_INFO};ty.semaphoreType=VK_SEMAPHORE_TYPE_TIMELINE;VkSemaphoreCreateInfo si{VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO};si.pNext=&ty;ck(vkCreateSemaphore(device,&si,nullptr,&l.timeline));}
        }
        staging=raw(24ull*1024*1024,true);
    }
    ~Vulkan(){if(device){try{drain();}catch(...){}live_programs.clear();live_buffers.clear();staging.reset();for(auto& l:lanes){vkDestroyQueryPool(device,l.queries,nullptr);vkDestroyFence(device,l.fence,nullptr);vkDestroyCommandPool(device,l.pool,nullptr);vkDestroySemaphore(device,l.timeline,nullptr);}}}
    std::shared_ptr<Buffer> allocate(size_t n) override {if(!n||n%4||n>props.limits.maxStorageBufferRange)throw std::runtime_error("STORAGE_BUFFER_RANGE_OR_ALIGNMENT");return raw(n,false);}
    std::shared_ptr<Program> load(const ProgramSpec& spec) override {
        if(spec.float64&&!float64)throw std::runtime_error("WORKLOAD_REQUIRES_FLOAT64");
        uint64_t total=1;for(int i=0;i<3;i++){if(!spec.local[i]||spec.local[i]>props.limits.maxComputeWorkGroupSize[i])throw std::runtime_error("WORKGROUP_LIMIT");total*=spec.local[i];}
        if(total>props.limits.maxComputeWorkGroupInvocations||!spec.bindings||spec.bindings>32||spec.bindings>props.limits.maxPerStageDescriptorStorageBuffers||spec.words>32||spec.words*4>props.limits.maxPushConstantsSize)throw std::runtime_error("PROGRAM_LIMIT");
        auto p=std::make_shared<VP>();p->owner_device=context;p->owner=this;p->spec=spec;
        std::vector<VkDescriptorSetLayoutBinding> binds(spec.bindings);
        for(uint32_t i=0;i<spec.bindings;i++){binds[i].binding=i;binds[i].descriptorType=VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;binds[i].descriptorCount=1;binds[i].stageFlags=VK_SHADER_STAGE_COMPUTE_BIT;}
        VkDescriptorSetLayoutCreateInfo li{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO};li.bindingCount=binds.size();li.pBindings=binds.data();ck(vkCreateDescriptorSetLayout(device,&li,nullptr,&p->dl));
        VkDescriptorPoolSize sz{VK_DESCRIPTOR_TYPE_STORAGE_BUFFER,4096*spec.bindings};VkDescriptorPoolCreateInfo dpi{VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO};dpi.maxSets=4096;dpi.poolSizeCount=1;dpi.pPoolSizes=&sz;ck(vkCreateDescriptorPool(device,&dpi,nullptr,&p->dp));
        VkPushConstantRange pc{VK_SHADER_STAGE_COMPUTE_BIT,0,spec.words*4};VkPipelineLayoutCreateInfo pli{VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO};pli.setLayoutCount=1;pli.pSetLayouts=&p->dl;pli.pushConstantRangeCount=spec.words?1:0;pli.pPushConstantRanges=&pc;ck(vkCreatePipelineLayout(device,&pli,nullptr,&p->pl));
        std::ifstream f(spec.path,std::ios::binary|std::ios::ate);if(!f)throw std::runtime_error("PROGRAM_MISSING");auto len=f.tellg();if(len<=0||len%4||len>64*1024*1024)throw std::runtime_error("SPIRV_SIZE");f.seekg(0);std::vector<uint32_t> code(size_t(len)/4);if(!f.read((char*)code.data(),len))throw std::runtime_error("SPIRV_READ");
        VkShaderModuleCreateInfo sm{VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO};sm.codeSize=size_t(len);sm.pCode=code.data();VkShaderModule module{};ck(vkCreateShaderModule(device,&sm,nullptr,&module));
        VkSpecializationMapEntry entries[]={{0,0,4},{1,4,4},{2,8,4}};VkSpecializationInfo si{3,entries,12,spec.local.data()};
        VkComputePipelineCreateInfo cp{VK_STRUCTURE_TYPE_COMPUTE_PIPELINE_CREATE_INFO};cp.layout=p->pl;cp.stage={VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO};cp.stage.stage=VK_SHADER_STAGE_COMPUTE_BIT;cp.stage.module=module;cp.stage.pName=spec.entry.c_str();cp.stage.pSpecializationInfo=&si;
        auto result=vkCreateComputePipelines(device,VK_NULL_HANDLE,1,&cp,nullptr,&p->pipeline);vkDestroyShaderModule(device,module,nullptr);ck(result);return p;
    }
    void begin(){if(lane().recording)return;ck(vkResetCommandBuffer(lane().cmd,0));VkCommandBufferBeginInfo b{VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO};b.flags=VK_COMMAND_BUFFER_USAGE_ONE_TIME_SUBMIT_BIT;ck(vkBeginCommandBuffer(lane().cmd,&b));if(lane().queries)vkCmdResetQueryPool(lane().cmd,lane().queries,0,4096);lane().recording=true;lane().nq=0;}
    void barrier(){VkMemoryBarrier b{VK_STRUCTURE_TYPE_MEMORY_BARRIER};b.srcAccessMask=VK_ACCESS_SHADER_WRITE_BIT|VK_ACCESS_TRANSFER_WRITE_BIT;b.dstAccessMask=VK_ACCESS_SHADER_READ_BIT|VK_ACCESS_SHADER_WRITE_BIT|VK_ACCESS_TRANSFER_READ_BIT|VK_ACCESS_TRANSFER_WRITE_BIT;auto stages=VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT|VK_PIPELINE_STAGE_TRANSFER_BIT;vkCmdPipelineBarrier(lane().cmd,stages,stages,0,1,&b,0,nullptr,0,nullptr);}
    void transfer_bounds(Buffer& b,size_t off,size_t n){bounds(b,off,n);if(off%4||n%4)throw std::runtime_error("TRANSFER_ALIGNMENT");}
    void upload(Buffer& b,size_t off,const void* ptr,size_t n) override {
        transfer_bounds(b,off,n);for(size_t pos=0;pos<n;){size_t c=std::min(n-pos,staging->bytes);memcpy(staging->mapped,(const char*)ptr+pos,c);begin();barrier();VkBufferCopy cp{0,off+pos,c};vkCmdCopyBuffer(lane().cmd,staging->b,static_cast<VB&>(b).b,1,&cp);drain();pos+=c;}h2d+=n;
    }
    void download(Buffer& b,size_t off,void* ptr,size_t n) override {
        transfer_bounds(b,off,n);for(size_t pos=0;pos<n;){size_t c=std::min(n-pos,staging->bytes);begin();barrier();VkBufferCopy cp{off+pos,0,c};vkCmdCopyBuffer(lane().cmd,static_cast<VB&>(b).b,staging->b,1,&cp);
            VkMemoryBarrier host{VK_STRUCTURE_TYPE_MEMORY_BARRIER};host.srcAccessMask=VK_ACCESS_TRANSFER_WRITE_BIT;host.dstAccessMask=VK_ACCESS_HOST_READ_BIT;
            vkCmdPipelineBarrier(lane().cmd,VK_PIPELINE_STAGE_TRANSFER_BIT,VK_PIPELINE_STAGE_HOST_BIT,0,1,&host,0,nullptr,0,nullptr);
            drain();memcpy((char*)ptr+pos,staging->mapped,c);pos+=c;}d2h+=n;
    }
    void reset_bindings(Program& program) override {
        auto& p=static_cast<VP&>(program);ck(vkResetDescriptorPool(device,p.dp,0));p.descriptors.clear();
    }
    void copy(Buffer& source, Buffer& dest) override {
        bounds(source,0,source.bytes);bounds(dest,0,source.bytes);begin();barrier();
        live_buffers.push_back(source.shared_from_this());live_buffers.push_back(dest.shared_from_this());
        VkBufferCopy region{0,0,source.bytes};
        vkCmdCopyBuffer(lane().cmd,static_cast<VB&>(source).b,static_cast<VB&>(dest).b,1,&region);
    }
    void zero(Buffer& b) override {bounds(b,0,b.bytes);begin();barrier();live_buffers.push_back(b.shared_from_this());vkCmdFillBuffer(lane().cmd,static_cast<VB&>(b).b,0,b.bytes,0);}
    void dispatch(Program& base,const std::vector<Buffer*>& buffers,const std::vector<uint32_t>& q,
                  const std::array<uint32_t,3>& threads,const std::string& name) override {
        validate(base,buffers,q,threads);if(lane().pending.size()>=2048)drain();auto& p=static_cast<VP&>(base);
        uint32_t groups[3];for(int i=0;i<3;i++){groups[i]=(uint64_t(threads[i])+p.spec.local[i]-1)/p.spec.local[i];if(groups[i]>props.limits.maxComputeWorkGroupCount[i])throw std::runtime_error("GRID_LIMIT");}
        descriptor_key.resize(buffers.size());for(size_t i=0;i<buffers.size();i++)descriptor_key[i]=buffers[i]->id;
        auto it=p.descriptors.find(descriptor_key);VkDescriptorSet ds{};
        if(it==p.descriptors.end()){
            if(p.descriptors.size()>=4096)throw std::runtime_error("DESCRIPTOR_CACHE_BOUND");
            VkDescriptorSetAllocateInfo a{VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO};a.descriptorPool=p.dp;a.descriptorSetCount=1;a.pSetLayouts=&p.dl;ck(vkAllocateDescriptorSets(device,&a,&ds));
            std::array<VkDescriptorBufferInfo,32> bs;std::array<VkWriteDescriptorSet,32> ws;
            for(size_t i=0;i<buffers.size();i++){auto& b=static_cast<VB&>(*buffers[i]);bs[i]={b.b,0,b.bytes};ws[i]={VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET};ws[i].dstSet=ds;ws[i].dstBinding=i;ws[i].descriptorCount=1;ws[i].descriptorType=VK_DESCRIPTOR_TYPE_STORAGE_BUFFER;ws[i].pBufferInfo=&bs[i];}
            vkUpdateDescriptorSets(device,buffers.size(),ws.data(),0,nullptr);p.descriptors.emplace(descriptor_key,ds);
        }else ds=it->second;
        begin();barrier();vkCmdBindPipeline(lane().cmd,VK_PIPELINE_BIND_POINT_COMPUTE,p.pipeline);vkCmdBindDescriptorSets(lane().cmd,VK_PIPELINE_BIND_POINT_COMPUTE,p.pl,0,1,&ds,0,nullptr);
        if(!q.empty())vkCmdPushConstants(lane().cmd,p.pl,VK_SHADER_STAGE_COMPUTE_BIT,0,q.size()*4,q.data());
        if(lane().queries)vkCmdWriteTimestamp(lane().cmd,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,lane().queries,lane().nq++);
        vkCmdDispatch(lane().cmd,groups[0],groups[1],groups[2]);if(lane().queries)vkCmdWriteTimestamp(lane().cmd,VK_PIPELINE_STAGE_COMPUTE_SHADER_BIT,lane().queries,lane().nq++);
        lane().pending.push_back({name,now_ns()});live_programs.push_back(base.shared_from_this());for(auto* b:buffers)live_buffers.push_back(b->shared_from_this());
    }
    void drain() override {
        // Every batch waits only on the PREVIOUS completed batch. Lanes in
        // this batch have no mutual waits, so their independent work may overlap.
        // Timeline waits also make setup writes visible on other queues and
        // make every lane's output visible to subsequent download commands.
        std::vector<VkSemaphore> waits;std::vector<uint64_t> values;
        std::vector<VkPipelineStageFlags> stages;
        for(auto& l:lanes)if(l.timeline&&l.submitted){waits.push_back(l.timeline);values.push_back(l.submitted);stages.push_back(VK_PIPELINE_STAGE_ALL_COMMANDS_BIT);}
        std::vector<VkFence> fences;
        for(auto& l:lanes)if(l.recording){
            ck(vkEndCommandBuffer(l.cmd));
            VkSubmitInfo si{VK_STRUCTURE_TYPE_SUBMIT_INFO};si.commandBufferCount=1;si.pCommandBuffers=&l.cmd;
            VkTimelineSemaphoreSubmitInfo ts{VK_STRUCTURE_TYPE_TIMELINE_SEMAPHORE_SUBMIT_INFO};
            uint64_t value=l.submitted+1;
            if(l.timeline){
                ts.waitSemaphoreValueCount=values.size();ts.pWaitSemaphoreValues=values.data();ts.signalSemaphoreValueCount=1;ts.pSignalSemaphoreValues=&value;
                si.pNext=&ts;si.waitSemaphoreCount=waits.size();si.pWaitSemaphores=waits.data();si.pWaitDstStageMask=stages.data();si.signalSemaphoreCount=1;si.pSignalSemaphores=&l.timeline;
            }
            ck(vkQueueSubmit(l.queue,1,&si,l.fence));l.submitted=value;submits++;fences.push_back(l.fence);
        }
        if(fences.empty())return;
        ck(vkWaitForFences(device,fences.size(),fences.data(),VK_TRUE,120000000000ull));syncs++;auto end=now_ns();
        for(uint32_t index=0;index<lanes.size();index++){
            auto& l=lanes[index];if(!l.recording)continue;
            if(l.nq){std::vector<uint64_t> t(l.nq);ck(vkGetQueryPoolResults(device,l.queries,0,l.nq,t.size()*8,t.data(),8,VK_QUERY_RESULT_64_BIT));uint64_t mask=timestamp_bits==64?~uint64_t(0):(uint64_t(1)<<timestamp_bits)-1;
                for(size_t i=0;i<l.pending.size();i++)events.push_back({l.pending[i].name,l.pending[i].host,end,((t[2*i+1]-t[2*i])&mask)*props.limits.timestampPeriod/1e6,(t[2*i]&mask)*props.limits.timestampPeriod/1e6,(t[2*i+1]&mask)*props.limits.timestampPeriod/1e6,index});
            }else for(auto& p:l.pending)events.push_back({p.name,p.host,end,-1,-1,-1,index});
            l.pending.clear();ck(vkResetFences(device,1,&l.fence));l.recording=false;l.nq=0;
        }
        live_programs.clear();live_buffers.clear();
    }
};
std::unique_ptr<Backend> make_vulkan(const std::string& pci,uint32_t lanes){return std::make_unique<Vulkan>(pci,lanes);}
