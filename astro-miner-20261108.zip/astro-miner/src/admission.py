"""Join the canonical campaign flock; inspect foreign ownership read-only."""
import fcntl, json, os, stat
from pathlib import Path
SSD=Path('/mnt/a673a2d9-3c1d-49ee-9c1e-dfd167293b7b')
PROJECT=Path(__file__).resolve().parents[1]
SHARED_LOCK='/tmp/astro-qfirst-native.lock'

def open_shared_lock(path=SHARED_LOCK):
    """Create only if absent, never truncate, replace, chmod or unlink the lock.

    O_CREAT joins the same inode if an ASTRO process creates it concurrently.
    This matches ASTRO's a+ / O_RDWR|O_CREAT protocol after /tmp is cleared.
    """
    fd=os.open(path,os.O_RDWR|os.O_CREAT|os.O_NOFOLLOW|os.O_CLOEXEC|os.O_NONBLOCK,0o600)
    try:
        owned=os.fstat(fd)
        if not stat.S_ISREG(owned.st_mode):raise ValueError('nonregular shared lock')
        fcntl.flock(fd,fcntl.LOCK_EX|fcntl.LOCK_NB)
        named=os.stat(path,follow_symlinks=False)
        if not stat.S_ISREG(named.st_mode) or (owned.st_dev,owned.st_ino)!=(named.st_dev,named.st_ino):
            raise ValueError('shared lock path identity changed')
        return fd
    except BaseException:
        os.close(fd);raise

def acquire(*, cpu_only=False):
    try:fd=open_shared_lock()
    except (OSError,ValueError) as e:raise RuntimeError('BLOCKED_ACTIVE_OR_UNCOORDINATED_OWNER: shared lock unavailable: '+str(e)) from e
    try:
        boot=Path('/proc/sys/kernel/random/boot_id').read_text().strip()
        for p in SSD.glob('ASTRO*/minernode*/runs/device-holds/*.json'):
            h=json.loads(p.read_text())
            if not cpu_only and h.get('boot_id') in (boot,'UNAVAILABLE',None):
                raise RuntimeError('BLOCKED_ACTIVE_OR_UNCOORDINATED_OWNER: current boot hold '+str(p))
        for p in Path('/proc').glob('[0-9]*/cmdline'):
            try: raw=p.read_bytes().replace(b'\0',b' ').decode(errors='replace')
            except (OSError,ProcessLookupError): continue
            if not raw or str(PROJECT) in raw: continue
            if any(v in raw for v in ('csr_worker','fabric-worker','run_full_ngc_bench.py','native_workflow_control.py','resident_graph_control','science_native_r','bench-ngc-')) and not any(v in raw for v in ('exec_command','bash -lc','rg ')):
                raise RuntimeError('BLOCKED_ACTIVE_OR_UNCOORDINATED_OWNER: pid '+p.parent.name+' '+raw[:300])
        return fd
    except BaseException as e:
        os.close(fd)
        message=str(e)
        if not message.startswith('BLOCKED_ACTIVE_OR_UNCOORDINATED_OWNER:'):
            message='BLOCKED_ACTIVE_OR_UNCOORDINATED_OWNER: '+message
        raise RuntimeError(message) from e
