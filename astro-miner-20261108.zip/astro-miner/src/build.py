"""Build the miner and synthetic benchmark; no downloaded scientific files."""
import hashlib
import json
import os
import shutil
import subprocess
import time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]


def sha(path):
    h = hashlib.sha256()
    with Path(path).open('rb') as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b''):
            h.update(block)
    return h.hexdigest()


def build(input_dir=None, core_only=True):
    commands = []
    def run(args):
        args = list(map(str, args))
        begin = time.monotonic()
        with (ROOT / 'logs/build.log').open('a') as log:
            log.write('\n$ ' + ' '.join(args) + '\n')
            log.flush()
            result = subprocess.run(args, cwd=ROOT, stdout=log, stderr=subprocess.STDOUT)
        commands.append(dict(argv=args, seconds=time.monotonic()-begin, returncode=result.returncode))
        if result.returncode:
            raise RuntimeError('BUILD_FAILED: see logs/build.log')

    nvcc = os.environ.get('INDEPENDENT_CUDA_SDK')
    nvcc = str(Path(nvcc) / 'bin/nvcc') if nvcc else shutil.which('nvcc')
    cuda = bool(nvcc and Path(nvcc).is_file())
    if os.environ.get('INDEPENDENT_CUDA_SDK') and not cuda:
        raise RuntimeError('CONFIGURED_CUDA_SDK_NOT_FOUND')
    artifacts = ['science-engine', 'bench.spv', 'qgc1.spv', 'libqgc1.so']
    for name, source in [('bench', 'bench/kernel.comp'), ('qgc1', 'engine/compression/codec.comp')]:
        run(['glslangValidator', '-V', '--target-env', 'vulkan1.1', '-o', ROOT/f'build/{name}.spv', ROOT/source])
        run(['spirv-val', '--target-env', 'vulkan1.1', ROOT/f'build/{name}.spv'])
    run(['g++', '-std=c++17', '-O3', '-fPIC', '-shared', ROOT/'engine/compression/host.cpp', '-lcrypto', '-o', ROOT/'build/libqgc1.so'])
    flags = ['-std=c++17', '-O2', '-ffp-contract=off', '-fno-fast-math', '-Iengine']
    for name in ['graph_runner', 'vulkan_backend']:
        run(['g++', *flags, '-c', ROOT/f'engine/{name}.cpp', '-o', ROOT/f'build/{name}.o'])
    if cuda:
        sdk = Path(nvcc).resolve().parents[1]
        arch = os.environ.get('ASTRO_CUDA_ARCH', 'compute_75')
        for name, source in [('bench', 'bench/kernel.cu'), ('qgc1', 'engine/compression/codec.cu')]:
            run([nvcc, '-std=c++17', '-O2', '-arch='+arch, '--fmad=false', '--ftz=false', '--prec-div=true', '--prec-sqrt=true', '-ptx', ROOT/source, '-o', ROOT/f'build/{name}.ptx'])
            artifacts.append(name+'.ptx')
        run(['g++', *flags, '-I'+str(sdk/'include'), '-c', ROOT/'engine/cuda_backend.cpp', '-o', ROOT/'build/cuda_backend.o'])
        libs = ['-lcuda']
    else:
        stub = ROOT/'build/cuda_unavailable.cpp'
        stub.write_text('#include "backend.hpp"\nstd::unique_ptr<Backend> make_cuda(const std::string&,uint32_t){throw std::runtime_error("CUDA_TOOLCHAIN_UNAVAILABLE_AT_BUILD");}\n')
        run(['g++', *flags, '-c', stub, '-o', ROOT/'build/cuda_backend.o'])
        libs = []
    run(['g++', ROOT/'build/graph_runner.o', ROOT/'build/vulkan_backend.o', ROOT/'build/cuda_backend.o', '-lvulkan', '-lcrypto', *libs, '-o', ROOT/'build/science-engine'])
    sources = [ROOT/'astro.py', ROOT/'bench.py']
    for directory in ['engine', 'autotune', 'src', 'bench']:
        sources += [p for p in (ROOT/directory).rglob('*') if p.is_file() and '__pycache__' not in p.parts]
    system = [Path('/usr/lib/x86_64-linux-gnu')/name for name in ['libvulkan.so.1', 'libcrypto.so.3'] + (['libcuda.so.1'] if cuda else [])]
    manifest = dict(status='BUILT_NOT_NUMERICALLY_VERIFIED', core_only=True, cuda=cuda,
        sources={str(p.relative_to(ROOT)): sha(p) for p in sources}, dependencies={},
        artifacts={f'build/{name}': sha(ROOT/f'build/{name}') for name in artifacts},
        system_dependencies={str(p.resolve()): sha(p) for p in system if p.is_file()}, commands=commands)
    (ROOT/'BUILD_MANIFEST.json').write_text(json.dumps(manifest, indent=2)+'\n')
    print('BUILD_OK; numerical validation is separate; CUDA='+str(cuda))


def check_build(integrity=None):
    digest = integrity.sha if integrity else sha
    path = Path(integrity.file(ROOT/'BUILD_MANIFEST.json').path) if integrity else ROOT/'BUILD_MANIFEST.json'
    manifest = json.loads(path.read_bytes())
    for group in ('sources', 'dependencies', 'artifacts'):
        for relative, expected in manifest[group].items():
            if digest(ROOT/relative) != expected:
                raise RuntimeError('BUILD_INTEGRITY_CHANGED:'+relative)
    for path, expected in manifest.get('system_dependencies', {}).items():
        if digest(path) != expected:
            raise RuntimeError('SYSTEM_LIBRARY_CHANGED:'+path)
    return manifest
